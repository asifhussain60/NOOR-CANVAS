# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e6]:
    - heading "This site can’t be reached" [level=1] [ref=e7]:
      - generic [ref=e8]: This site can’t be reached
    - paragraph [ref=e9]:
      - strong [ref=e10]: localhost
      - text: refused to connect.
    - generic [ref=e11]:
      - paragraph [ref=e12]: "Try:"
      - list [ref=e13]:
        - listitem [ref=e14]: Checking the connection
        - listitem [ref=e15]:
          - link "Checking the proxy and the firewall" [ref=e16] [cursor=pointer]:
            - /url: "#buttons"
    - generic [ref=e17]: ERR_CONNECTION_REFUSED
  - generic [ref=e18]:
    - button "Reload" [ref=e20] [cursor=pointer]
    - button "Details" [ref=e21] [cursor=pointer]
```