#!/usr/bin/env pwsh

Write-Host "🧪 SIGNALCOMM Enhanced HTML Parser Test" -ForegroundColor Cyan
Write-Host "Testing the enhanced HTML parsing service implementation" -ForegroundColor Yellow
Write-Host ""

# Test HTML samples that would cause appendChild errors
$testCases = @(
    @{
        Name = "Simple CSS"
        Html = '<div style="color: red; background: blue;">Test</div>'
        Expected = "Should parse without errors"
    },
    @{
        Name = "Complex CSS with gradients"
        Html = '<div style="background: linear-gradient(45deg, #ff0000, #00ff00); color: rgba(255, 255, 255, 0.8);">Complex styling</div>'
        Expected = "Enhanced parser should handle complex CSS"
    },
    @{
        Name = "Nested quotes in CSS"
        Html = '<div style="font-family: ''Arial'', sans-serif; content: ''"text"'';">Nested quotes</div>'
        Expected = "Enhanced parser should normalize quotes"
    },
    @{
        Name = "Multiple style attributes"
        Html = '<span style="color: #ff0000; background-color: rgba(0, 0, 0, 0.5); border: 1px solid rgb(128, 128, 128);">Multi-style</span>'
        Expected = "Should handle multiple color formats"
    }
)

Write-Host "📋 Test Cases:" -ForegroundColor Green
foreach ($case in $testCases) {
    Write-Host "  • $($case.Name): $($case.Expected)" -ForegroundColor Gray
}

Write-Host ""
Write-Host "🔍 Manual Verification Steps:" -ForegroundColor Magenta
Write-Host "1. Open browser dev tools (F12)"
Write-Host "2. Go to Console tab"
Write-Host "3. Look for 'Enhanced HTML parsing and JavaScript fallback renderer active' message"
Write-Host "4. Test HTML broadcasting using the interface buttons"
Write-Host "5. Watch for '[DEBUG-WORKITEM:signalcomm:PARSER]' messages in server logs"
Write-Host "6. Verify no 'appendChild' errors occur in browser console"

Write-Host ""
Write-Host "✅ Success Criteria:" -ForegroundColor Green
Write-Host "  • No 'Failed to execute appendChild on Node: Invalid or unexpected token' errors"
Write-Host "  • Server logs show [DEBUG-WORKITEM:signalcomm:PARSER] messages"
Write-Host "  • window.NoorCanvas.HtmlRenderer available in browser console"
Write-Host "  • HTML broadcasts render correctly without JavaScript errors"

Write-Host ""
Read-Host "Press Enter to continue monitoring server logs..."