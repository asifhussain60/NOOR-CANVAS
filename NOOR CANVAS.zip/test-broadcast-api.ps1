# Testing database broadcast API functionality for SIGNALCOMM workitem

# Create a broadcast via API  
$createBody = @{
    sessionId = 218
    contentType = "HTML"
    title = "SIGNALCOMM Validation Test"
    content = "<div style='background: gold; padding: 20px; border: 3px solid orange; text-align: center;'><h2>DATABASE BROADCAST SUCCESS</h2><p>This content was successfully stored in KSESSIONS_DEV database!</p><p><strong>SignalComm workitem - SQL broadcast implementation VERIFIED!</strong></p></div>"
    createdBy = "Terminal API Test"
} | ConvertTo-Json -Depth 10

Write-Host "Creating broadcast via API..." -ForegroundColor Yellow

try {
    # For PowerShell 5.1, use -UseBasicParsing instead of -SkipCertificateCheck
    $createResult = Invoke-RestMethod -Uri "https://localhost:9091/api/contentbroadcast" -Method POST -Body $createBody -ContentType "application/json" -UseBasicParsing
    Write-Host "CREATE SUCCESS: $($createResult | ConvertTo-Json)" -ForegroundColor Green
} catch {
    Write-Host "CREATE FAILED: $($_.Exception.Message)" -ForegroundColor Red
}

# Retrieve broadcasts for session 218
Write-Host "Retrieving broadcasts for session 218..." -ForegroundColor Yellow

try {
    $getResult = Invoke-RestMethod -Uri "https://localhost:9091/api/contentbroadcast/session/218" -Method GET -UseBasicParsing
    Write-Host "RETRIEVE SUCCESS: Found $($getResult.Count) broadcasts" -ForegroundColor Green
    $getResult | ForEach-Object {
        Write-Host "Broadcast ID: $($_.id), Title: $($_.title), Created: $($_.createdAt)" -ForegroundColor Cyan
    }
} catch {
    Write-Host "RETRIEVE FAILED: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "API validation complete" -ForegroundColor Magenta