# Playwright Config
## Instructions
- Extract from real Playwright config file in repo.
- Sync must refresh this file to reflect reality.
