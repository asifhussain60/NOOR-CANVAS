# API Contract Validation
## Instructions
- Extract schemas/contracts from API source.
- Sync must update to ensure contracts are current.
