# Noor Canvas Architecture
## Instructions
- Describe system modules and services.
- Sync must update from project structure.
