# Playwright Test Paths
## Instructions
- Scan tests folder for Playwright tests.
- Sync must update this file with discovered paths.
