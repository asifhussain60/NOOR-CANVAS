# Analyzer Config
## Instructions
- Extract analyzer and Roslynator settings from project csproj files.
- Keep synchronized via sync agent.
