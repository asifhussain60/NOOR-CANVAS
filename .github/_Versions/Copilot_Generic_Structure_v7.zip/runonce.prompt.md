# runonce.prompt.md
**Purpose:**  
Initializes Copilot for a new application environment.

**Instruction:**  
1. Review the full application architecture, including UI, API, SQL schema, tables, stored procedures, and configuration layers.  
2. Populate `SelfAwareness.md`, files in the `Links` folder, and any instruction or grounding Markdown files with contextual intelligence.  
3. Validate schema alignment, dependency structure, and cross-module references.  
4. Update lifecycle, keys, and analyzer metadata automatically based on findings.

**Execution Mode:** One-time setup (run once after new deployment).  
