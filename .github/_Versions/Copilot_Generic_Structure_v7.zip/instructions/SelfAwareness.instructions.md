# Selfawareness.Instructions

<!-- Placeholder structure. To be populated by runonce.prompt.md -->
