# sync.md

## Role
You are responsible for synchronizing and maintaining the Copilot prompts, links, and configurations.  
Follow the same parameter rules and Keylock lifecycle as `task.md`.  

This includes:  
- Ensuring all prompt files are current.  
- Creating, updating, or deleting prompt/link/config files as needed.  
- Removing obsolete or replaced prompts.  
- Updating the `keys` folder and regenerating the dashboard.  

Use the same Execution Steps (Plan, Execute, Validate, Confirm, Summary + Key Management).  
