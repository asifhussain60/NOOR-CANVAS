# Prompt Enhancement Libraries Reference

**Version**: 1.0.0  
**Last Updated**: 2025-10-13  
**Purpose**: Catalog of external libraries and frameworks for prompt engineering, optimization, and orchestration  
**Audience**: Development team evaluating prompt enhancement tools  

---

## Overview

This document catalogs established prompt engineering libraries that can enhance AI agent capabilities through structured prompting, optimization, testing, and orchestration. These are **optional enhancement tools** - the NOOR Canvas prompt system is functional without them.

---

## 🎯 Prompt Optimization Frameworks

### DSPy (Stanford NLP)
**Repository**: https://github.com/stanfordnlp/dspy  
**Language**: Python  
**License**: MIT  

**Purpose**: Algorithmic prompt optimization through compilation and tuning.

**Key Features**:
- Automatic prompt optimization using few-shot learning
- Compile prompts into optimized versions based on training data
- Signature-based prompt declaration (inputs → outputs)
- Support for multiple LLM backends (OpenAI, Anthropic, local models)
- Metric-driven optimization (accuracy, latency, cost)

**Use Cases**:
- Optimizing task.prompt.md for specific workload patterns
- A/B testing prompt variations
- Reducing token usage while maintaining quality
- Fine-tuning prompts for different model families

**Example**:
```python
import dspy

# Define prompt signature
class CodeReview(dspy.Signature):
    code: str = dspy.InputField()
    issues: list[str] = dspy.OutputField()

# Compile optimized prompt
optimized = dspy.ChainOfThought(CodeReview)
result = optimized(code="function example() { ... }")
```

**Integration Considerations**:
- Requires Python runtime alongside .NET stack
- Training data needed for optimization
- Could optimize `.github/prompts/` files through iterative training

---

### Guidance (Microsoft Research)
**Repository**: https://github.com/microsoft/guidance  
**Language**: Python  
**License**: MIT  

**Purpose**: Constrained generation and structured prompting with control flow.

**Key Features**:
- Handlebars-like template syntax for prompts
- Constrained generation (regex patterns, JSON schemas)
- Control flow (loops, conditionals) within prompts
- Token healing (fix partial token issues)
- Stateful prompt execution

**Use Cases**:
- Enforcing JSON output formats for API responses
- Structured code generation with syntax guarantees
- Multi-step reasoning with intermediate checkpoints
- Template-based prompt generation

**Example**:
```python
from guidance import models, gen

lm = models.OpenAI("gpt-4")

prompt = lm + f"""
Analyze this code:
{{code}}

Issues found:
{{#each issues}}
- {{this}}
{{/each}}
""" + gen(name="issues", list_append=True, stop="\n")
```

**Integration Considerations**:
- Strong fit for structured output requirements (DTOs, API contracts)
- Could enforce API-Contract-Validation.md rules in prompts
- Template system could standardize agent prompt generation

---

## 🔗 Prompt Orchestration Platforms

### LangChain
**Repository**: https://github.com/langchain-ai/langchain  
**Language**: Python (+ JavaScript/TypeScript)  
**License**: MIT  

**Purpose**: Framework for chaining LLM calls, managing context, and building AI applications.

**Key Features**:
- Prompt templates with variable substitution
- Chain multiple LLM calls with intermediate processing
- Memory management (conversation history, context windows)
- Tool integration (search, calculators, APIs)
- Vector store integration for retrieval-augmented generation (RAG)
- Agent framework with tool selection

**Use Cases**:
- Multi-step agent workflows (task → refactor → validate)
- Context management across agent calls
- Integration with vector stores for codebase search
- Building interactive debugging assistants

**Example**:
```python
from langchain import PromptTemplate, LLMChain

template = PromptTemplate(
    input_variables=["key", "task"],
    template="Execute task '{task}' for key '{key}':\n{context}"
)

chain = LLMChain(llm=openai_llm, prompt=template)
result = chain.run(key="user-auth", task="Add 2FA")
```

**Integration Considerations**:
- Heavy framework - may be overkill for current needs
- Could replace custom key data stream management
- Strong candidate for multi-agent orchestration
- Vector store could power semantic_search improvements

---

### Semantic Kernel (Microsoft)
**Repository**: https://github.com/microsoft/semantic-kernel  
**Language**: C#, Python, Java  
**License**: MIT  

**Purpose**: Enterprise-grade SDK for integrating LLMs into applications with plugins and planners.

**Key Features**:
- **Native C# support** (aligns with NOOR Canvas stack)
- Plugin system for extending LLM capabilities
- Planners for multi-step task decomposition
- Memory stores (short-term, long-term, semantic)
- Prompt templating with Handlebars syntax
- Token management and cost optimization

**Use Cases**:
- Native integration with .NET/Blazor stack
- Plugin-based agent architecture
- Enterprise-grade prompt management
- Automated planning for complex tasks

**Example**:
```csharp
var kernel = Kernel.Builder.Build();
kernel.Config.AddOpenAITextCompletion("gpt-4", apiKey);

var prompt = @"
Analyze the code in {{$input}} and suggest improvements.
Focus on:
1. Performance
2. Security
3. Maintainability
";

var function = kernel.CreateSemanticFunction(prompt);
var result = await function.InvokeAsync("MyCode.cs");
```

**Integration Considerations**:
- **HIGHEST COMPATIBILITY** - native C# integration
- Could replace current prompt parsing logic
- Plugin system could modularize agent capabilities
- Planner could handle task.prompt.md execution workflow
- Memory stores could enhance key data stream

---

## 🧪 Prompt Testing & Evaluation

### PromptTools
**Repository**: https://github.com/hegelai/prompttools  
**Language**: Python  
**License**: Apache 2.0  

**Purpose**: Testing, evaluation, and experimentation framework for prompts.

**Key Features**:
- A/B testing for prompt variations
- Automated prompt evaluation with metrics
- Experiment tracking and versioning
- Cost analysis across prompt variants
- Latency benchmarking
- Support for multiple LLM providers

**Use Cases**:
- Testing `.github/prompts/` variations
- Measuring agent performance metrics
- Cost optimization experiments
- Regression testing for prompt changes

**Example**:
```python
from prompttools.experiment import OpenAIChatExperiment

prompts = [
    "Analyze code: {code}",
    "Review code for issues: {code}"
]

experiment = OpenAIChatExperiment(
    model=["gpt-4"],
    messages=[prompts],
    temperature=[0.0, 0.5]
)

experiment.run()
experiment.visualize()  # Compare results
```

**Integration Considerations**:
- Could establish CI/CD for prompt quality
- Measure agent success rates over time
- Optimize prompt token usage
- Validate prompt changes before deployment

---

### PromptFoo
**Repository**: https://github.com/promptfoo/promptfoo  
**Language**: TypeScript/JavaScript  
**License**: MIT  

**Purpose**: Command-line tool for prompt testing and comparison.

**Key Features**:
- YAML-based test configuration
- Automated prompt testing pipeline
- Red team testing (adversarial prompts)
- Cost tracking per test run
- Regression testing
- CI/CD integration

**Use Cases**:
- Automated testing of agent prompts
- Red team validation (security, jailbreaks)
- Cost monitoring for prompt changes
- GitHub Actions integration

**Example**:
```yaml
# promptfooconfig.yaml
prompts:
  - task.prompt.md
  - refactor.prompt.md

providers:
  - openai:gpt-4

tests:
  - vars:
      key: user-auth
      task: Add login
    assert:
      - type: contains
        value: "Step 1: Checkpoint"
```

**Integration Considerations**:
- Could add to `.github/workflows/` for prompt validation
- Test suite for all `.github/prompts/` files
- Catch prompt regressions before deployment

---

## 🏗️ Development & Debugging Tools

### LangSmith (LangChain)
**Repository**: https://smith.langchain.com  
**Language**: Platform (API + SDKs)  
**License**: Commercial (free tier available)  

**Purpose**: Observability, debugging, and monitoring for LLM applications.

**Key Features**:
- Trace LLM calls with full context
- Debug multi-step agent workflows
- Monitor token usage and costs
- Evaluate prompt performance
- Dataset management for testing
- Feedback collection

**Use Cases**:
- Debugging task.prompt.md execution failures
- Tracing agent workflow across steps
- Monitoring production agent usage
- Collecting user feedback on agent quality

**Integration Considerations**:
- Requires external service (cloud-hosted)
- Strong observability for agent debugging
- Cost tracking across all agents
- Could replace custom logging in prompts

---

### Langfuse
**Repository**: https://github.com/langfuse/langfuse  
**Language**: TypeScript (self-hostable)  
**License**: MIT  

**Purpose**: Open-source LLM engineering platform (observability + analytics).

**Key Features**:
- Self-hosted or cloud
- Trace entire LLM workflows
- Cost analysis and budgeting
- User feedback integration
- Prompt versioning and management
- Team collaboration features

**Use Cases**:
- Internal observability for agent system
- Cost control and budgeting
- Prompt version management
- Team coordination on prompt development

**Integration Considerations**:
- **SELF-HOSTABLE** - fits infrastructure requirements
- Could integrate with existing logging
- Unified dashboard for all agents
- Prompt versioning could enhance `.github/prompts/` management

---

## 📊 Comparison Matrix

| Library | Language | Primary Use Case | C# Support | Self-Hostable | License |
|---------|----------|-----------------|------------|---------------|---------|
| **DSPy** | Python | Prompt Optimization | ❌ | ✅ | MIT |
| **Guidance** | Python | Constrained Generation | ❌ | ✅ | MIT |
| **LangChain** | Python/JS | Orchestration | ❌ | ✅ | MIT |
| **Semantic Kernel** | **C#**/Python/Java | Enterprise Orchestration | ✅ | ✅ | MIT |
| **PromptTools** | Python | Testing & Evaluation | ❌ | ✅ | Apache 2.0 |
| **PromptFoo** | TypeScript | CLI Testing | ❌ | ✅ | MIT |
| **LangSmith** | Platform | Observability | ✅ (SDK) | ❌ | Commercial |
| **Langfuse** | TypeScript | Observability | ✅ (SDK) | ✅ | MIT |

---

## 💡 Recommendations for NOOR Canvas

### Immediate Opportunities (High Value, Low Effort)

1. **Semantic Kernel (C#)**
   - **Why**: Native C# support, enterprise-grade, Microsoft-backed
   - **Use Case**: Replace custom prompt parsing, add plugin system for agents
   - **Effort**: 2-3 weeks integration
   - **Impact**: Standardized prompt management, better token handling

2. **PromptFoo (TypeScript)**
   - **Why**: Automated testing, CI/CD integration, regression prevention
   - **Use Case**: Test all `.github/prompts/` files on every commit
   - **Effort**: 1 week setup
   - **Impact**: Catch prompt regressions early, quality assurance

### Medium-Term Enhancements (Strategic Value)

3. **Langfuse (Self-Hosted)**
   - **Why**: Open-source observability, self-hostable, cost tracking
   - **Use Case**: Monitor agent performance, debug failures, track costs
   - **Effort**: 1-2 weeks deployment + integration
   - **Impact**: Better agent debugging, cost optimization

4. **Guidance (Python)**
   - **Why**: Structured output, API contract enforcement
   - **Use Case**: Enforce JSON schemas for API responses, validate DTOs
   - **Effort**: 2 weeks integration (requires Python service)
   - **Impact**: Stronger API-Contract-Validation.md compliance

### Long-Term Considerations (Research & Experimentation)

5. **DSPy (Python)**
   - **Why**: Algorithmic prompt optimization
   - **Use Case**: Optimize frequently-used prompts (task.prompt.md)
   - **Effort**: 3-4 weeks (requires training data collection)
   - **Impact**: Reduced token usage, faster agent execution

6. **LangChain (Python)**
   - **Why**: Multi-agent orchestration, RAG for codebase search
   - **Use Case**: Replace manual agent coordination, enhance semantic_search
   - **Effort**: 4-6 weeks (significant architecture change)
   - **Impact**: Smarter agent workflows, better context management

---

## 🚀 Getting Started

### Semantic Kernel (Recommended First Step)

1. **Install NuGet Package**:
   ```bash
   dotnet add package Microsoft.SemanticKernel --version 1.0.0
   ```

2. **Basic Integration**:
   ```csharp
   using Microsoft.SemanticKernel;
   
   var kernel = Kernel.Builder
       .WithOpenAIChatCompletionService("gpt-4", apiKey)
       .Build();
   
   var prompt = @"
   Execute task: {{$task}}
   Key: {{$key}}
   Debug Level: {{$debugLevel}}
   ";
   
   var function = kernel.CreateSemanticFunction(prompt);
   var result = await function.InvokeAsync(new ContextVariables
   {
       ["task"] = "Add user authentication",
       ["key"] = "user-auth",
       ["debugLevel"] = "trace"
   });
   ```

3. **Integration Points**:
   - Replace prompt parsing in agent executors
   - Add plugin system for agent capabilities
   - Integrate with existing SimplifiedTokenService
   - Use memory stores for key data stream

### PromptFoo (Recommended Testing)

1. **Install CLI**:
   ```bash
   npm install -g promptfoo
   ```

2. **Create Config** (`.github/promptfooconfig.yaml`):
   ```yaml
   description: NOOR Canvas Agent Prompt Tests
   
   prompts:
     - file://.github/prompts/task.prompt.md
     - file://.github/prompts/refactor.prompt.md
   
   providers:
     - openai:gpt-4
   
   tests:
     - description: Task prompt includes all steps
       vars:
         key: test-key
         tasks: Test implementation
       assert:
         - type: contains
           value: "Step 1: Checkpoint"
         - type: contains
           value: "Step 2: Key Data Stream"
   ```

3. **Run Tests**:
   ```bash
   promptfoo eval
   promptfoo view  # Launch web UI to review results
   ```

4. **CI/CD Integration** (`.github/workflows/test-prompts.yml`):
   ```yaml
   name: Test Prompts
   on: [push, pull_request]
   jobs:
     test:
       runs-on: ubuntu-latest
       steps:
         - uses: actions/checkout@v3
         - run: npm install -g promptfoo
         - run: promptfoo eval --no-cache
   ```

---

## 📚 Additional Resources

### Learning Materials
- **Prompt Engineering Guide**: https://www.promptingguide.ai
- **OpenAI Best Practices**: https://platform.openai.com/docs/guides/prompt-engineering
- **Microsoft Semantic Kernel Docs**: https://learn.microsoft.com/semantic-kernel

### Community
- **LangChain Discord**: https://discord.gg/langchain
- **Semantic Kernel GitHub Discussions**: https://github.com/microsoft/semantic-kernel/discussions
- **PromptFoo Slack**: https://promptfoo.dev/slack

### Research Papers
- **DSPy Paper**: "DSPy: Compiling Declarative Language Model Calls into Self-Improving Pipelines"
- **Chain-of-Thought Prompting**: "Chain-of-Thought Prompting Elicits Reasoning in Large Language Models"
- **ReAct**: "ReAct: Synergizing Reasoning and Acting in Language Models"

---

## 🔄 Maintenance

**Update Frequency**: Quarterly (or when major library updates occur)  
**Owner**: Development Team  
**Review Process**: Evaluate new libraries, test integrations, update recommendations  

**Last Review**: 2025-10-13  
**Next Review**: 2026-01-13  

---

## Related Documentation

- `.github/prompts/task.prompt.md` - References this file in Core Mandates
- `.github/instructions/Links/Architecture.md` - System architecture overview
- `.github/instructions/Links/SystemIndex.md` - Agent coordination patterns
- `.github/instructions/Links/ValidationFramework.md` - Validation standards

---

**Version History**:
- **1.0.0** (2025-10-13): Initial documentation with 8 libraries, comparison matrix, integration recommendations
