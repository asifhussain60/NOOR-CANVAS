# Reference Index

Always consult these files for grounding decisions:

- AnalyzerConfig.MD
- API-Contract-Validation.md
- PlaywrightConfig.MD
- PlaywrightTestPaths.MD
- SystemStructureSummary.md
