# Functionality Registry - Regression Prevention System

## Overview
The **Functionality Registry** is a lightweight behavioral contract system that prevents regressions by tracking core user-facing behaviors in key data streams and validating them during task execution.

**Purpose**: Ensure that new changes to a key's codebase don't break existing functionality that users depend on.

---

## How It Works

### 1. Core Behaviors Tracking
Each key maintains a list of **critical behaviors** that must always work, regardless of code changes:

```markdown
### Core Behaviors (Must Always Work)
- ✅ **Behavior 1**: Valid token in URL → Direct to registration (no flash)
- ✅ **Behavior 2**: Invalid token → Show error message
- ✅ **Behavior 3**: Missing token → Show token entry panel
```

**Characteristics**:
- **User-Facing**: Behaviors describe what users experience, not implementation details
- **Testable**: Each behavior can be verified through automated or manual testing
- **Critical**: Behaviors marked here are non-negotiable - they must continue working

---

### 2. File/Method Watch Lists
The registry tracks which files and methods control critical behaviors:

```markdown
### Breaking Change Detection
- **File Watch**: 
  - `SPA/NoorCanvas/Pages/UserLanding.razor`
  - `SPA/NoorCanvas/Services/AuthService.cs`
- **Method Watch**:
  - `OnInitializedAsync()` - Initialization logic
  - `ValidateToken()` - Token validation
```

**Purpose**:
- When task modifies a watched file → **Trigger validation workflow**
- When task modifies a watched method → **Flag regression risk**
- When no watches match → **Low regression risk, validation optional**

---

### 3. Test Coverage Mapping
Links behaviors to their validation tests (automated or manual):

```markdown
### Related Test Coverage
- **Automated Tests**:
  - `Tests/UI/user-auth-flow.spec.ts` - Covers behaviors 1, 2, 3
- **Manual Validation**:
  - Navigate to /session/canvas/{TOKEN}
  - Verify registration appears without flash
```

**Benefits**:
- **Automated**: Run tests automatically when watched files change
- **Manual Fallback**: Provide checklist when no automated tests exist
- **Coverage Tracking**: Know which behaviors have test coverage

---

### 4. Validation Workflow (task.prompt.md Step 8.2)

When a task modifies code under a key with Functionality Registry:

#### Step 1: Load Registry
```
✓ Loaded Functionality Registry for key 'user-auth'
  - Core Behaviors: 5
  - File Watch: 3 files
  - Method Watch: 3 methods
  - Test Coverage: Manual validation required
```

#### Step 2: Detect Regression Risk
```
⚠️ REGRESSION RISK DETECTED
  - Modified file: UserLanding.razor (matches File Watch)
  - Affected behaviors: 3 core behaviors
  - Validation REQUIRED before commit
```

#### Step 3: Execute Validation
**Option A - Automated Tests Available:**
```bash
npm test -- Tests/UI/user-auth-flow.spec.ts
# All tests pass → Update Last Validation → Allow commit
```

**Option B - Manual Validation Only:**
```
⚠️ Manual Validation Required
Please verify the following behaviors still work:
□ Valid token flow (no flash)
□ Invalid token error handling
□ Missing token default behavior

Confirm all behaviors work? (yes/no)
```

#### Step 4: Update Registry
```
✅ Functionality Validation: PASS
  - Core behaviors: 5 verified
  - Tests executed: 3 passed (manual)
  - Registry updated (Last Validation: 2025-01-11)
```

#### Step 5: Allow/Block Commit
- **PASS**: Commit allowed, registry updated
- **FAIL**: Commit blocked, regression logged in history

---

## Integration with task.prompt.md

### Step 8.2: Functionality Registry Validation

**Triggered When**:
- Task execution completes (Step 5)
- Build succeeds (Step 6)
- Before git commit (Step 8.1)

**Workflow**:
1. Load `{key}.md` → Parse `## Functionality Registry` section
2. Compare modified files from Step 5 with File Watch list
3. **IF match found** → Execute validation (automated or manual)
4. **IF validation passes** → Update Last Validation, allow commit
5. **IF validation fails** → Log regression, BLOCK commit

**Output to User**:
```
✅ Functionality Validation: PASS
- Core behaviors: 5 verified
- Tests executed: Manual validation
- Registry updated with new behaviors
```

---

## Schema Reference

### Complete Functionality Registry Template

```markdown
## Functionality Registry
**Purpose**: Track core behaviors that MUST continue working across all changes to prevent regressions.

### Core Behaviors (Must Always Work)
- ✅ **Behavior 1**: Description of critical user-facing functionality
- ✅ **Behavior 2**: Another critical behavior
- ✅ **Behavior 3**: Third core behavior

### Related Test Coverage
- **Automated Tests**:
  - `Tests/UI/feature-workflow.spec.ts` - Covers behaviors 1, 2, 3
  - `Tests/Unit/ServiceTests.cs` - Unit test coverage
- **Manual Validation**:
  - Step-by-step validation instructions
  - Expected outcomes for each behavior

### Breaking Change Detection
- **File Watch**: 
  - `Path/To/File1.cs` - Controls behavior X
  - `Path/To/File2.razor` - Controls behavior Y
- **Method Watch**:
  - `ClassName.MethodName()` - Critical method
  - `AnotherClass.ImportantMethod()` - Another critical method
- **State Watch**:
  - `Model.PropertyName` - Expected state transitions
  - `Configuration.SettingName` - Configuration dependencies

### Last Validation
- **Date**: YYYY-MM-DD HH:MM:SS (ISO-8601)
- **Method**: automated | manual | hybrid
- **Result**: PASS | FAIL | PARTIAL
- **Commit**: {git-sha}
- **Notes**: Additional context

### Regression History
- YYYY-MM-DD: Regression detected in {behavior} (commit: abc1234) - Fixed in commit def5678
```

---

## Best Practices

### 1. What to Track
✅ **DO Track**:
- User-facing behaviors (login flow, data display, navigation)
- Critical business logic (payment processing, data validation)
- Security behaviors (authentication, authorization, data protection)
- Performance requirements (page load < 2s, API response < 500ms)

❌ **DON'T Track**:
- Implementation details (variable names, code structure)
- Non-critical UI tweaks (button colors, spacing adjustments)
- Experimental features not yet released
- Temporary workarounds or debugging code

### 2. Writing Good Behavior Descriptions
**Good**:
```markdown
- ✅ **Valid Token Flow**: User with valid token in URL skips login screen and goes directly to dashboard
```
**Bad**:
```markdown
- ✅ **OnInitialized Works**: The OnInitializedAsync method executes correctly
```

**Good descriptions**:
- Focus on user experience, not code
- Describe expected outcome clearly
- Include context (what triggers the behavior)

### 3. File Watch Strategy
**Watch Files That**:
- Contain critical business logic
- Handle user authentication/authorization
- Process payments or sensitive data
- Control navigation or routing
- Manage state for core features

**Skip Files That**:
- Are utility helpers (formatters, converters)
- Handle logging or telemetry
- Contain styling or CSS only
- Are configuration files (unless behavior-critical)

### 4. Test Coverage Strategy
**Priority Order**:
1. **Automated E2E Tests** (Playwright) - Best coverage, run automatically
2. **Automated Unit Tests** - Fast, cover specific logic
3. **Manual Validation Checklist** - Fallback when no automated tests exist

**Recommendation**: Create Playwright tests for all core behaviors over time.

---

## Example: user-auth Key

### Complete Registry
```markdown
## Functionality Registry

### Core Behaviors (Must Always Work)
- ✅ **Valid Token Flow**: Valid token in URL → Direct to registration panel (no flash/flicker)
- ✅ **Invalid Token Handling**: Invalid token → Show token panel with error message
- ✅ **Missing Token Default**: No token in URL → Show token entry panel
- ✅ **Error Recovery**: Validation failures → Revert to token panel with helpful error
- ✅ **Registration Access**: After token validation → Waiting room access enabled

### Related Test Coverage
- **Automated Tests**: None (recommended: create Playwright test)
- **Manual Validation**:
  - Navigate to /session/canvas/KJAHA99L (valid)
  - Verify: Registration panel appears immediately
  - Navigate to /session/canvas/INVALID (bad token)
  - Verify: Token panel with error
  - Navigate to /user/landing (no token)
  - Verify: Token entry panel default

### Breaking Change Detection
- **File Watch**:
  - `SPA/NoorCanvas/Pages/UserLanding.razor` - Main UI component
  - `SPA/NoorCanvas/Controllers/ParticipantController.cs` - Validation API
  - `SPA/NoorCanvas/Services/SimplifiedTokenService.cs` - Token logic
- **Method Watch**:
  - `UserLanding.OnInitializedAsync()` - Panel state initialization
  - `UserLanding.LoadSessionInfoAsync()` - Token validation & error handling
  - `ParticipantController.ValidateToken()` - Server validation endpoint
- **State Watch**:
  - `Model.ShowTokenPanel` - false when valid token, true otherwise
  - `Model.ShowRegistrationPanel` - true after successful validation
  - `Model.ErrorMessage` - error text when validation fails

### Last Validation
- **Date**: 2025-01-11 (commit e06cafb3)
- **Method**: manual
- **Result**: PASS
- **Notes**: Build clean, all token scenarios verified via code analysis
```

**Usage**: When any file in File Watch is modified, task agent will prompt manual validation checklist.

---

## ROI & Benefits

### Prevents Silent Regressions
**Before Functionality Registry**:
- Modify UserLanding.razor under `user-auth` key
- Accidentally break token validation logic
- Build succeeds (no compile errors)
- **Regression ships to production** ❌

**After Functionality Registry**:
- Modify UserLanding.razor under `user-auth` key
- File Watch detects change → Triggers validation
- Manual checklist or automated tests verify behaviors
- **Regression caught before commit** ✅

### Improves Code Confidence
- Developers know exactly what behaviors are critical
- Clear validation criteria for every change
- Historical regression tracking prevents repeat mistakes

### Enables Safer Refactoring
- Refactor code with confidence that behaviors stay intact
- File Watch ensures validation happens automatically
- Regression History documents past issues and fixes

### Reduces Manual QA Time
- Automated tests run on every change to watched files
- Manual validation checklists guide focused testing
- Clear pass/fail criteria prevent ambiguity

---

## Migration Guide

### Adding Registry to Existing Keys

**Step 1: Identify Core Behaviors**
Review key's implementation and document 3-5 critical user-facing behaviors.

**Step 2: Map Files and Methods**
Identify which files and methods control those behaviors (use grep/search).

**Step 3: Document Test Coverage**
List existing tests OR create manual validation checklist.

**Step 4: Add Registry Section**
Copy template from `.github/prompts.keys/_template/key-template.md`.

**Step 5: Validate**
Run manual validation to ensure behaviors are testable and accurate.

### Example Migration (canvas key)

```markdown
## Functionality Registry

### Core Behaviors (Must Always Work)
- ✅ **Asset Centering**: All Islamic content assets (poetry, hadees, ayah) load centered in canvas
- ✅ **Layer Visibility**: Hidden layers don't display, visible layers render correctly
- ✅ **Real-Time Updates**: Canvas updates when host broadcasts new content

### Related Test Coverage
- **Manual Validation**:
  - Load Session 212 as participant (KJAHA99L)
  - Verify: Hadees card appears centered in canvas
  - Host broadcasts poetry → Verify: Poetry appears centered
  - Host hides layer → Verify: Content disappears from participant view

### Breaking Change Detection
- **File Watch**:
  - `SPA/NoorCanvas/Pages/SessionCanvas.razor` - Canvas rendering
  - `SPA/NoorCanvas/wwwroot/css/session-transcript.css` - Asset styling
- **Method Watch**:
  - `SessionCanvas.RenderContent()` - Content display logic
- **State Watch**:
  - `.canvas-asset-content` CSS class - Must have `display: flex; justify-content: center`

### Last Validation
- **Date**: 2025-01-10 (commit da778fa6)
- **Method**: manual
- **Result**: PASS
```

---

## Troubleshooting

### "No Functionality Registry found"
**Solution**: Add registry section to `{key}.md` using template.

### "Validation blocking commit"
**Causes**:
- Automated tests failed → Fix test failures
- Manual validation rejected → Investigate and fix regression
- File Watch triggered but no validation → Complete manual checklist

**Resolution**: Fix regressions before commit, or use `--skip-validation` flag (NOT RECOMMENDED).

### "Too many behaviors to track"
**Solution**: Focus on top 5 critical behaviors only. Don't track implementation details.

### "File Watch triggers too often"
**Solution**: Remove overly broad file patterns. Watch only files with critical business logic.

---

## Future Enhancements

### Phase 1 (Current) ✅
- Functionality Registry schema in key template
- Manual validation workflow in task.prompt.md Step 8.2
- File/Method Watch detection
- Basic regression history tracking

### Phase 2 (Future)
- Automated Playwright test execution when File Watch triggers
- Contract-based testing with JSON schema validation
- Performance regression detection (load time, API response time)
- Visual regression testing with screenshot comparison

### Phase 3 (Advanced)
- AI-powered regression prediction based on code changes
- Automatic test generation for new behaviors
- Integration with CI/CD pipeline for automated validation
- Behavior coverage reports (% of behaviors with automated tests)

---

## Summary

The **Functionality Registry** is a lightweight, practical system that:
1. ✅ **Tracks** core user-facing behaviors in key metadata
2. ✅ **Detects** when changes affect critical functionality (File/Method Watch)
3. ✅ **Validates** behaviors through automated tests or manual checklists
4. ✅ **Prevents** regressions by blocking commits when validation fails
5. ✅ **Documents** regression history for learning and improvement

**Adoption**: Start with high-value keys (authentication, payments, core features) and expand gradually.

**ROI**: Prevents silent regressions, improves code confidence, enables safer refactoring, reduces manual QA overhead.

**Integration**: Seamlessly integrates with existing task workflow in Step 8.2 (no disruption to current process).
