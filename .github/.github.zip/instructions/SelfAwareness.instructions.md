# SelfAwareness - Global Operating Guardrails (2.4.0)

> Canonical operating rules for all agents. Keep **.github/prompts/** as the source of truth.
> Everything else lives under **Workspaces/Copilot/**.

## Scope
Governs `/workitem`, `/continue`, `/pwtest`, `/cleanup`, `/retrosync`, `/imgreq`, `/refactor`, `/migrate`.

## Core Principles
- **Deterministic rails**: follow these rules exactly; do not invent new flows.
- **Single source of truth**: prompts here; configs and state under `Workspaces/Copilot/`.
- **Evidence-first**: factor terminal logs, analyzers, and artifacts into analysis and summaries.
- **Small steps**: change one thing at a time, accumulate tests, and stabilize before moving on.

## Absolute Runtime Rules
- **Never** launch with `dotnet run` or any variant.
- Launch only via PowerShell scripts:
  - `./Workspaces/Copilot/Global/nc.ps1`  (launch only)
  - `./Workspaces/Copilot/Global/ncb.ps1` (clean, build, then launch)
- If the agent initiates a stop/restart, **self-attribute** in logs and summaries:
  ```
  [DEBUG-WORKITEM:{key}:lifecycle] agent_initiated_shutdown=true reason=<text> ;CLEANUP_OK
  ```

## Analyzer & Linter Enforcement (Sept 27, 2025)
All agents must enforce **industry-standard analyzers and linters** before declaring success.

### .NET Analyzer Integration
- **NuGet Packages**:
  - Microsoft.CodeAnalysis.NetAnalyzers v8.0.0
  - StyleCop.Analyzers v1.2.0-beta.507
- **Configuration**: `Directory.Build.props` at repo root:
  ```xml
  <Project>
    <PropertyGroup>
      <AnalysisLevel>latest</AnalysisLevel>
      <EnforceCodeStyleInBuild>true</EnforceCodeStyleInBuild>
      <TreatWarningsAsErrors>true</TreatWarningsAsErrors>
    </PropertyGroup>
  </Project>
  ```
- **Command**: `dotnet build --no-restore --warnaserror` must succeed with **zero warnings**.

### Playwright Linting Integration
- **NPM Packages**:
  - eslint v9.36.0
  - prettier v3.6.2
  - typescript v5.9.2
  - @typescript-eslint/parser v8.44.1
  - @typescript-eslint/eslint-plugin v8.44.1
  - eslint-config-prettier v10.1.8
  - eslint-plugin-playwright v2.2.2
- **Configuration**:
  - `eslint.config.js` at repo root
  - `.prettierrc` for formatting
- **Scripts in package.json**:
  ```json
  "lint": "eslint 'PlayWright/**/*.{ts,tsx}' --max-warnings=0",
  "format": "prettier --write 'PlayWright/**/*.{ts,tsx}'",
  "format:check": "prettier --check 'PlayWright/**/*.{ts,tsx}'"
  ```
- **Commands**:
  - `npm run lint` must pass with 0 warnings
  - `npm run format:check` must pass with 0 formatting violations

### CI/CD
- GitHub Actions pipeline `.github/workflows/build.yml` validates:
  - .NET build with analyzers (`dotnet build --warnaserror`)
  - ESLint validation (`npm run lint`)
  - Prettier format check (`npm run format:check`)

### Enforcement
- Agents must **fail early** if analyzers or linting report issues.
- Refactor, Workitem, Continue, and Pwtest must **fix violations before proceeding**.
- Cleanup cannot commit code if analyzers/lints fail.

## Enhanced Processor for DOM Issues (Blazor appendChild Fix)
- **Use enhanced processor approach** for large HTML content rendering in Blazor Server.
- **Never use Blazor RenderTreeBuilder.AddMarkupContent()** for large HTML (>20KB).
- **Bypass appendChild errors** with pure JavaScript innerHTML assignment:
  - Log with `[DEBUG-WORKITEM:{key}:bypass] Enhanced processor activated ;CLEANUP_OK`
  - Use `container.innerHTML = content`
  - Implement fallback text-only mode for DOM constraints
- **Enhanced processor tags**: `[ENHANCED-PROCESSOR]` for console logs and error handling
