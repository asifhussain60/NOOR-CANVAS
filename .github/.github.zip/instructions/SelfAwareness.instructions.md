# SelfAwareness – Global Operating Guardrails (2.5.0)

> Canonical operating rules for all agents. Keep **.github/prompts/** as the source of truth.  
> Everything else lives under **Workspaces/Copilot/**.

## Scope
Governs `/workitem`, `/continue`, `/pwtest`, `/cleanup`, `/retrosync`, `/imgreq`, `/refactor`, `/migrate`, `/promptsync`.

## Required Reading
**CRITICAL:** Before making any architectural decisions, implementing new features, or modifying existing code, agents **MUST** consult:
- **`.github/instructions/Links/SystemIndex.md`** - Central navigation hub for all architectural references, agent coordination, and system snapshots
- **`.github/instructions/Links/InfrastructureQuickRef.md`** - **MANDATORY** for database operations - contains KSESSIONS_DEV connection details and schema access rules
- **`.github/instructions/Links/Architecture.md`** - Comprehensive application architecture documentation including:
  - Complete API endpoint catalog (52 endpoints across 11 controllers)
  - Razor pages and component inventory (15+ pages, 10+ components)
  - Service architecture (15+ services with responsibilities)
  - SignalR hub documentation (4 hubs with methods and events)
  - Data model catalog and database schemas
  - Authentication flows and security patterns
  - Integration patterns and common workflows

**Purpose:** This prevents duplication of existing functionality and ensures new implementations follow established architectural patterns.

## 🗄️ Database Access Rules (MANDATORY)

**PRIMARY DATABASE: KSESSIONS_DEV**
- When user mentions "database", assume **KSESSIONS_DEV** unless specified otherwise
- Server: AHHOME
- Connection: Always use `_configuration.GetConnectionString("DefaultConnection")`

**SCHEMA ACCESS CONTROL**:
- ✅ **`canvas.*` schema**: READ-WRITE allowed
  - canvas.Questions, canvas.QuestionVotes, canvas.Participants, canvas.AssetLookup, canvas.Sessions
  
- ❌ **`dbo.*` schema**: **READ-ONLY ONLY** - NO INSERT, UPDATE, DELETE allowed
  - dbo.Groups (Albums), dbo.Categories, dbo.Sessions (LEGACY), dbo.Speakers, dbo.SessionTranscripts
  - dbo.GetAllGroups (stored procedure), dbo.GetCategoriesForGroup (stored procedure)
  
  > **Verified 2025-10-12**: Only dbo tables with EF models or direct SQL usage are listed.
  > NOOR CANVAS does NOT use dbo.Members, dbo.SessionTokens, dbo.Users, or dbo.Tokens.
  
- ❌ **All other schemas**: **READ-ONLY**

**VIOLATION CONSEQUENCES**:
- Any attempt to modify `dbo.*` or other READ-ONLY schemas will result in:
  - Immediate task failure
  - Rollback to checkpoint
  - User notification of violation

**See**: `.github/instructions/Links/InfrastructureQuickRef.md` for complete database documentation

## Core Principles
- **Deterministic rails**: follow these rules exactly; do not invent new flows.  
- **Single source of truth**: prompts here; configs and state under `Workspaces/Copilot/`.  
- **Evidence-first**: factor terminal logs, analyzers, and artifacts into analysis and summaries.  
- **Small steps**: change one thing at a time, accumulate tests, and stabilize before moving on.

## Phase Prompt Processing
All agents must handle `---` delimited input as separate todo items:

### Phase Recognition
- **Delimiter**: `---` on its own line indicates phase separation
- **Parsing**: Split user input into individual phases for sequential processing
- **Identification**: Each phase gets a unique identifier: `phase_{number}` where number starts at 1

### Phase Processing Workflow
For each phase, agents must:
1. **Implementation**: Make the required change for this specific phase
2. **Test Generation**: Create headless, silent Playwright test in `Workspaces/TEMP/`
   - Naming: `{agent}-phase-{phase_number}-{key}-{RUN_ID}.spec.ts`
   - Must be headless and silent (no browser UI)
   - Must validate the specific change made in this phase
3. **Test Validation**: Ensure test passes (retry up to 3 times if needed)
4. **Phase Completion**: Mark complete with debug log
5. **Next Phase**: Move to subsequent phase only after current phase is fully complete

### Temporary Test Management
- **Location**: All phase tests go in `Workspaces/TEMP/` directory
- **Cleanup**: Remove temporary phase tests after all phases complete (unless `commit:false`)
- **Distinction**: Permanent tests follow proper structure as per config files in `config/testing/`
- **Isolation**: Each phase test should be independent and not depend on previous phase tests

### Phase Completion Logging
- **Format**: `[DEBUG-WORKITEM:{key}:impl:{RUN_ID}] phase_{number}_complete status=success/failure ;CLEANUP_OK`
- **Required**: Each phase must log completion before proceeding to next phase
- **Failure Handling**: If phase fails, stop processing and report failure with specific phase number  

## File Organization Rules
**CRITICAL**: Never create analysis, summary, or documentation files in the project root.

### Documentation & Analysis File Placement
All agent-generated documentation must be placed in the designated directory structure:

```
Workspaces/Copilot/
├── _DOCS/                    # All analysis and summary documents
│   ├── summaries/           # Work completion summaries
│   ├── analysis/            # Technical analysis documents
│   ├── configs/             # Configuration documentation
│   └── migrations/          # Migration and reorganization docs
├── artifacts/               # Build and test artifacts
├── config/                  # Agent configurations
└── prompts.keys/           # Key-based prompt storage
```

### Code Quality Analysis - Roslynator Organization
**MANDATORY**: All Roslynator code analysis data is strictly organized under `Workspaces/CodeQuality/` with documentation stored in `Workspaces/Documentation/ROSLYNATOR DOCS/`:

```
Workspaces/CodeQuality/
├── README.md                         # Comprehensive usage documentation
├── run-roslynator.ps1               # Automated analysis execution script
├── CONFIGURATION_COMPLETE.md        # Setup completion status
└── Roslynator/
    ├── Config/
    │   └── roslynator.config        # Main Roslynator configuration
    ├── Reports/
    │   ├── baseline-analysis.json   # Initial baseline for comparison
    │   ├── latest-analysis.json     # Most recent analysis (GitLab format)
    │   └── analysis_*.json          # Timestamped historical reports
    └── Logs/
        ├── latest-analysis.log      # Most recent execution log
        └── analysis_*.log           # Timestamped historical logs

Workspaces/Documentation/ROSLYNATOR DOCS/
├── latest-roslynator-documentation.md    # Most recent analysis documentation
└── roslynator-documentation_*.md         # Timestamped historical documentation
```

**Roslynator Documentation Features:**
- **Automatic Generation**: Enhanced markdown documentation with executive summaries
- **Health Scoring**: Project health scores calculated from diagnostic patterns
- **Severity Analysis**: Issues grouped by Error, Warning, Info, and Suggestion levels
- **File Rankings**: Identification of files requiring the most attention
- **Actionable Recommendations**: Specific improvement suggestions based on analysis
- **Dual Format Output**: Both technical JSON reports and user-friendly documentation

**Roslynator Execution Rules:**
- **NEVER** run `roslynator` commands directly in project root
- **ALWAYS** use: `.\Workspaces\CodeQuality\run-roslynator.ps1`
- **VS Code Integration**: Use tasks "run-roslynator-analysis" or "run-roslynator-analysis-and-open"
- **Report Access**: Latest results always at `Workspaces/CodeQuality/Roslynator/Reports/latest-analysis.json`
- **Documentation Access**: Latest user-friendly docs at `Workspaces/Documentation/ROSLYNATOR DOCS/latest-roslynator-documentation.md`
- **No Root Pollution**: All analysis artifacts are contained in the organized structure

**Enforcement:**
- **Summaries**: `Workspaces/Copilot/_DOCS/summaries/`
- **Analysis**: `Workspaces/Copilot/_DOCS/analysis/`
- **Config Documentation**: `Workspaces/Copilot/_DOCS/configs/`
- **Migration Reports**: `Workspaces/Copilot/_DOCS/migrations/`
- **Code Quality**: `Workspaces/CodeQuality/Roslynator/`
- **Never use project root** for any temporary or analysis files

## Absolute Runtime Rules

### For .NET Application Development
- **Never** launch with `dotnet run` or any variant.  
- Launch only via PowerShell scripts:  
  - `./Workspaces/Global/nc.ps1`  (launch only)  
  - `./Workspaces/Global/ncb.ps1` (clean, build, then launch)  
- If the agent initiates a stop/restart, **self-attribute** in logs and summaries.

### For Database Access Architecture
- **CRITICAL RULE**: Database data MUST ONLY be accessed via HTTP APIs, NEVER directly through DbContext injection in UI components
- **UI Layer Prohibition**: Razor pages and components must NOT inject `SimplifiedCanvasDbContext` or `KSessionsDbContext`
- **Required Pattern**: UI → HTTP API → Controller → DbContext → Database
- **API-First**: All database operations must go through properly designed API endpoints with DTOs
- **No Direct Queries**: Never use Entity Framework queries directly in UI layer (Pages/, Components/)
- **Enforcement**: Controllers may use DbContext internally, but UI components must use HttpClientFactory for all data access

### For Playwright Testing
- **Never** use PowerShell scripts (`nc.ps1`/`ncb.ps1`) for test execution
- Playwright manages application lifecycle via `webServer` configuration in `config/testing/playwright.config.cjs`
- Use `PW_MODE=standalone` to enable automatic app startup and shutdown
- Tests run entirely in Node.js context with Playwright managing the .NET app as a subprocess

#### ✅ Multi-Browser Isolation Success (Oct 1, 2025)
**Proven Solution**: API-based participant identification eliminates "same name on multiple browsers" issue
- **Working Tokens**: Session 212 - KJAHA99L (user) / PQ9N5YWW (host)
- **Test Suite**: `PlayWright/tests/multi-browser-participant-isolation.spec.ts` (ALL TESTS PASS ✅)
- **Key Pattern**: Direct `/session/canvas/{token}` navigation with API-based loading
- **Reference**: See `Links/PlaywrightTestPaths.MD` for comprehensive API-based testing patterns

## Debug Logging Rules
- All debug lines must use the consistent marker:  
  `[DEBUG-WORKITEM:{key}:{layer}:{RUN_ID}] message ;CLEANUP_OK`  
- `{layer}` values: `impl`, `tests`, `pwtest`, `retrosync`, `refactor`, `cleanup`, `lifecycle`.  
- `RUN_ID` is a short unique id (timestamp + random suffix).  
- Behavior by mode:  
  - **none**: do not insert debug lines.  
  - **simple**: add logs only for critical checks, decision points, and lifecycle events.  
  - **trace**: log every step of the flow, including intermediate calculations, branching decisions, and results.  

## Analyzer & Linter Enforcement (Post-Cleanup – Sept 27, 2025)
All agents must enforce **industry-standard analyzers and linters** before declaring success.

### .NET Analyzer Integration
- **NuGet Packages**:
  - Microsoft.CodeAnalysis.NetAnalyzers v8.0.0  
  - StyleCop.Analyzers v1.2.0-beta.507  
- **Configuration**: `Directory.Build.props` at repo root ensures:  
  - `<AnalysisLevel>latest</AnalysisLevel>`  
  - `<EnforceCodeStyleInBuild>true</EnforceCodeStyleInBuild>`  
  - `<TreatWarningsAsErrors>true</TreatWarningsAsErrors>`  
- **Suppressions**: 36 StyleCop rules intentionally suppressed (e.g., SA1200, SA1208, SA1633).  
- **Invariant**: Do **not** attempt to reintroduce suppressed rules unless explicitly instructed.

### ESLint Integration
- Main config: `config/testing/eslint.config.js` (centralized configuration)  
- Legacy configs in PlayWright/ (`.eslintrc.js`, `.eslintrc.cleanup.js`) for specific patterns like SignalR globals, Playwright contexts.  
- **Baseline Debt (Accepted)**:  
  - SignalR Browser Globals (20 errors) – acceptable.  
  - Playwright Dynamic Contexts (10 errors) – acceptable.  
  - Fixture Inheritance (6 errors) – acceptable.  
  - Catch Block Patterns (3 errors) – acceptable.  
- Agents must **not** attempt to eliminate these debts unless explicitly instructed.

### npm Script Enforcement (Updated Sept 27, 2025)
All agents must use the centralized npm scripts for linting, formatting, and testing:

- **Linting**: `npm run lint` (uses `config/testing/eslint.config.js`)
- **Formatting Check**: `npm run format:check` (uses `config/testing/.prettierrc`)
- **Formatting Fix**: `npm run format` (uses `config/testing/.prettierrc`)
- **TypeScript Check**: `npm run build:tests` (uses `config/testing/tsconfig.json`)
- **Playwright Tests**: All test commands use `config/testing/playwright.config.cjs`

**Enforcement Rules:**
- Run from repository root directory
- All scripts automatically reference centralized config files
- **Zero tolerance**: All linting and formatting must pass before declaring success
- **Error Interpretation**: Distinguish between config issues vs. actual code problems

## Modernization Guardrails
- **Imports**: All new code must use ES6 `import` syntax. Never reintroduce `require()`.  
- **Typing**: Prefer explicit types over `any`. If unavoidable, document why.  
- **Error Handling**: Use null coalescing (`??`) and safe defaults for resilience.  
- **Code Hygiene**: Delete unused functions/variables instead of prefixing with `_`.  
- **Formatting**: Always format with Prettier using `config/testing/.prettierrc`. Respect case sensitivity (`Tests` → `tests`).  

## Memory of Failures & Prohibited Retries
Agents must **record and respect failed approaches**:  
- Do not retry typing refactors of SignalR globals.  
- Do not force Playwright fixture rewrites when context inheritance is involved.  
- Do not attempt to "fix" suppressed StyleCop rules.  

## Test Strategy Rules
- Always generate Playwright tests incrementally:  
  1. Begin with simple hardcoded render checks.  
  2. Progress to integration with fixtures.  
  3. Only at the final stage use live browser contexts with SignalR.  
- If a test hangs, agents must self-recover and retry with reduced scope.  

## Logging for Success/Failure Memory
- On success: append `;SUCCESS_PATH` to debug logs.  
- On failure: append `;FAIL_PATH:{reason}` and mark prohibited retries.  
- Summaries must include both successes and failures so future generations don’t repeat mistakes.

## Version Control Rules
- Always operate within Git.  
- On completion: ensure `git status` is clean.  
- Commits must include RUN_ID in the message for traceability.

---

## Key Infrastructure (Migrated from IssueTracker)

### Configuration File Organization (Updated Sept 27, 2025)
All JavaScript/JSON configuration files have been centralized for better organization:

```
config/
└── testing/
    ├── eslint.config.js          # ESLint configuration for TypeScript/Playwright tests
    ├── playwright.config.cjs     # Playwright test configuration (CommonJS format)
    ├── tsconfig.json            # TypeScript configuration for tests
    └── .prettierrc             # Prettier formatting configuration
```

**Key Points:**
- **Centralized Location**: All configs in `config/testing/` directory
- **npm Scripts**: All package.json scripts reference the centralized config locations
- **Backward Compatibility**: Legacy configs in PlayWright/ maintained for specific use cases
- **CommonJS Format**: Playwright config uses `.cjs` extension for ES module compatibility
- **Path Updates**: All relative paths correctly updated for new directory structure

### Port Management & Launch

### Database Connectivity

#### KSESSIONS_DEV SQL Connection String
```
Data Source=AHHOME;Initial Catalog=KSESSIONS_DEV;User Id=sa;Password=adf4961glo;Connection Timeout=3600;MultipleActiveResultSets=true;TrustServerCertificate=true;Encrypt=false
```

**Never use localdb for any database operations.**
All agents and scripts must connect only to the specified SQL Server instance above. LocalDB is strictly prohibited for development, testing, or production workflows.

#### IIS Express & Port Management
- Default app port: 9091 (avoid system reserved)
- **For Development**: Use nc.ps1/ncb.ps1 for port cleanup and dynamic assignment
- **For Playwright Tests**: Use webServer configuration (`PW_MODE=standalone`) for automatic management
- Always check for orphaned IIS Express processes before launch (development only)

#### Entity Framework
- Use retry logic for DbContext initialization
- Connection string must match above for all .NET apps

#### Playwright Test Infrastructure
- Centralized under PlayWright/ (tests, reports, results, artifacts)
- **Main config**: `config/testing/playwright.config.cjs` (centralized configuration)
- **webServer Configuration**: Handles automatic .NET app startup/shutdown for tests
- **Usage Context**:
  - **Development/Implementation**: Use PowerShell scripts (nc.ps1/ncb.ps1)
  - **Playwright Testing**: Use webServer (`PW_MODE=standalone`) - never PowerShell scripts
- Legacy configs: PlayWright/config/ and root (for backward compatibility)
- All npm scripts reference the centralized config location

#### SignalR
- Handle InvalidDataException during message parsing
- Use resilient serialization formats for real-time updates

#### API Endpoints
- Token validation: `/api/host/token/{token}/validate` for friendly tokens
- **Connection String Standard**: Always use identical connection strings across all applications
- **Timeout Configuration**: Use Connection Timeout=3600 for long-running operations
- **Route Conflicts**: Always check for ambiguous route patterns during development
- **Token Validation**: Use correct API endpoints: `/api/host/token/{token}/validate` for friendly tokens
- **SignalR Integration**: Handle InvalidDataException during data parsing; verify message serialization
- **Authentication Flows**: Validate token formats match expected endpoint requirements

### Playwright Test Infrastructure
- **Centralized Structure**: All test artifacts under PlayWright/ directory
- **Artifact Management**: Organized into tests/, reports/, results/, artifacts/, config/
- **Configuration**: Proxy config at root, main config in PlayWright/config/
- **Path Resolution**: All paths relative to project root for consistency

## Key Requirements (Migrated from IssueTracker)

### Authentication & Session Management
- **Token Consistency**: Host-SessionOpener workflow must maintain token validation throughout
- **Session Name Display**: Support both KSESSIONS database lookup and fallback display patterns
- **Multi-route Support**: Components must handle multiple route patterns (/, /host, /host/{token})
- **Error Handling**: Authentication failures must show user-friendly messages, not technical errors

### UI/UX Standards
- **Responsive Design**: All authentication cards must be properly centered and sized
- **Visual Consistency**: Maintain purple theme, Tailwind CSS, and consistent padding/spacing
- **Logo Placement**: Large, prominent logo display in headers
- **Animation Support**: Landing pages should support smooth transitions and animations

### API Integration Requirements
- **KSESSIONS Integration**: Support both KSESSIONS_DEV and production database contexts
- **Host Provisioner**: Single GUID per session ID with proper foreign key constraints
- **Validation Logic**: Implement comprehensive SessionTranscripts validation
- **Real-time Updates**: SignalR must handle participant updates without connection drops
- **UI-Database Mapping**: In UI layer, `albumID` corresponds to `GroupID` in SQL table `dbo.Sessions.Groups`

### Data Management
- **Album & Category Data**: Support dynamic loading from KSESSIONS database
- **Session Transcripts**: Proper validation and storage with token-based access
- **Participant Management**: Real-time participant list updates via SignalR
- **Flag Display**: ISO2 country code mapping for participant countries

---

**Version:** 2.8.0  
**Last Updated:** Documentation Organization & File Placement Rules – Sept 27, 2025  

```

---

## Reference: System Index
This instruction set references the central `SystemIndex.md`. Any structural changes must be reflected there.


## Git Backup & Rollback Discipline
- Every /workitem and /continue must begin by creating a backup commit.
- Undo logs must store commit hashes for rollback.
- Rollback uses `git reset --hard <hash>`.
- On /keylock, squash backup commits into one final commit.