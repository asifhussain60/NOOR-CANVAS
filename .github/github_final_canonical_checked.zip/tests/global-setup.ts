import { request } from '@playwright/test';

async function globalSetup() {
  const healthUrl = 'http://localhost:9091/health';
  const requestContext = await request.newContext();

  try {
    const response = await requestContext.get(healthUrl);
    if (response.status() !== 200) {
      throw new Error('Application not running or unhealthy');
    }
  } catch (e) {
    console.error('❌ Pre-flight healthcheck failed:', e.message);
    process.exit(1);
  } finally {
    await requestContext.dispose();
  }
}

export default globalSetup;
