# prompts-sync.plan.md — Synchronize Portable Prompts → KSESSIONS Structure

Key: prompts-sync
Owner: platform-tooling
Created: 2025-10-23
Branch: development

## Context
- Goal: Bring the portable prompt set under `Workspaces/CodeQuality/noorcanvas_github/prompts` into `.github/prompts`, customized to KSESSIONS and aligned to the repo’s structure and guardrails.
- Direction: Follow the structure in `.github/prompts` (top-level topic folders: comm, knowledge, ops, quality, util) and integrate missing shared guidance.
- Constraints: Keep chat outputs concise; write full technical details into files; preserve portability.

## Detected Delta (High-Level)
- Missing folder in repo: `.github/prompts/shared/` (portable has many shared docs used by prompts)
- Location difference: `continue.prompt.md` at portable root vs. repo uses `comm/continue.prompt.md`
- Additional portable folders: `workitems/`, `prompts.keys/`, `README.md` (repo lacks equivalents under `.github/prompts/`)
- Cross-reference paths in prompts reference `.github/prompts/shared/...` — repo must provide these files
- Ensure "Next" options standardization: A. Continue | B. Review | C. Modify | D. Cancel across prompts

## Phases

### Phase 1 — Scaffold Shared Guidance
Context: Provide shared documents referenced by prompts to avoid broken links and centralize mandate files.
Tasks (@task):
- Create `.github/prompts/shared/`
- Add at minimum:
  - `CONCISE-MANDATE.md`
  - `output-style-mandate.md`
  - `commit-checkpoint-protocol.md`
  - `agent-handoff-protocol.md`
  - `execution-flow.md`
  - `UserDictionary.md`
- Update any absolute references if needed (keep under `.github/prompts/shared/`).
Tests (@test-generation):
- Lint/validate presence of files and ensure references resolve in `create-plan`, `handoff`, `task`, `test-generation`.
Exit criteria:
- All referenced shared docs exist and are accessible at `.github/prompts/shared/*`.

### Phase 2 — Harmonize Continue Semantics
Context: Ensure consistent “Continue” control and options across prompts.
Tasks (@task):
- Ensure `handoff.prompt.md` Summary → Next shows: A. Continue | B. Review | C. Modify | D. Cancel.
- Ensure `Execution` sections recognize “continue” or “proceed”.
- Confirm `task.prompt.md` resume commands document "continue" triggers and recovery paths.
- Either:
  - Keep `comm/continue.prompt.md` as canonical, and create a stub `continue.prompt.md` at root pointing readers to `comm/continue.prompt.md`, OR
  - Update portable-style references to the comm path.
Tests (@test-generation):
- Prompt content checks for the exact Next line.
- Reference checks that point to the correct continue prompt location.
Exit criteria:
- Continue semantics are consistent; no stale “Execute” phrasing remains.

### Phase 3 — Map Portable Internal → Repo Structure
Context: Portable uses `internal/{comm,knowledge,ops,quality,util}`; repo uses top-level subfolders.
Tasks (@task):
- Verify each file under portable `internal/comm|knowledge|ops|quality|util` has an equivalent in `.github/prompts/<topic>/`.
- For any missing prompt:
  - Add a KSESSIONS-customized version under the repo structure.
  - Normalize headings/metadata to current repo conventions.
- Do not copy `workitems/` now; track as optional.
Tests (@test-generation):
- Presence tests for each expected prompt filename in the repo structure.
Exit criteria:
- All internal prompts from portable have equivalents in repo locations with KSESSIONS context.

### Phase 4 — Standardize Prompt Headers and Style
Context: Uniform top-matter and output mandates across all prompts.
Tasks (@task):
- Ensure each prompt has an up-to-date header block (mode/purpose/inputs/outputs/lastUpdated).
- Ensure references to `.github/prompts/shared/*` exist and are correct.
- Replace any "noorcanvas" naming with "KSESSIONS" where applicable.
Tests (@test-generation):
- Style lint: scan for missing headers and broken `.github/prompts/shared/` references.
Exit criteria:
- Headers present and consistent; references valid; KSESSIONS naming applied.

### Phase 5 — README and Developer Guidance
Context: Document how to use the prompts in this repo.
Tasks (@task):
- Add `.github/prompts/README.md` describing structure, key prompts, and how Continue behaves.
- Add `.github/prompts/CHANGELOG.md` for prompt evolution.
- Optionally add `.github/prompts/.keep` in empty folders.
Tests (@test-generation):
- Ensure README includes quick-start and links to shared docs.
Exit criteria:
- Developer guidance available and accurate.

### Phase 6 — Validation & Healthcheck
Context: Validate prompt set integrity before adoption.
Tasks (@task):
- Run “Lint Validation (Prompts)” task.
- Perform a lightweight @healthcheck with scope=prompts.
- Fix critical/high issues immediately; log medium/low in plan.
Tests (@test-generation):
- Simple checks for presence of required prompts and shared docs.
Exit criteria:
- No critical/high issues; medium/low documented.

## Risks and Mitigations
- Broken references: Mitigate by adding missing shared docs first.
- Divergent folder structures: Resolve via mapping internal → topic folders.
- Naming inconsistencies: Standardize via Phase 4 header/style pass.

## Execution Protocol
- Auto-execute phases sequentially unless user replies "review"/"cancel".
- Immediate continue: reply "continue" (or "proceed").
- Checkpoint commit after each phase with `ckpt(prompts-sync): Phase {N} - {summary}`.

## Next
- A. Continue — Begin Phase 1 now
- B. Review — Pause and open the plan
- C. Modify — Provide edits to the phases or scope
- D. Cancel — Stop without executing
