# Database Cleanup Plan: Post-Hub Infrastructure Removal

**Key**: `cleanup`  
**Branch**: `cleanup`  
**Created**: 2025-10-24  
**Status**: Planning Complete - Ready for Implementation  
**Auto-Invoke**: `false` (requires explicit user permission)

---

## Executive Summary

Remove unused database objects from `KSESSIONS_CLEANUP` after successful hub infrastructure cleanup. Generate production-safe migration script (`ProdCleanup.sql`) for eventual deployment to production database.

**Critical Constraint**: This cleanup targets the `KSESSIONS_CLEANUP` database for testing and the `KSESSIONS` database for production. The script automatically detects the target environment and applies appropriate safety measures. The `KQUR` database has NO hub infrastructure and requires NO changes.

---

## Scope

### Objects to Remove (KSESSIONS_CLEANUP only)

#### Hub Infrastructure Tables (5)
1. `HubPreloader` - Session preloader data (21 records archived)
2. `HubSessionData` - Hub session tracking
3. `HubUserQuestions` - User questions from hub sessions
4. `ZHubFeedbackQuestions` - Hub feedback questions
5. `ZHubFeedbackTypes` - Hub feedback type lookup

#### Hub Infrastructure Stored Procedures (4)
1. `AddUpdateHubPreloaderData` - Manage preloader data
2. `CreateHubSessionData` - Initialize hub sessions
3. `GetHubProfileForSession` - Retrieve session config
4. `SaveHubUserQuestion` - Persist user questions

#### Session Feedback System - ACTIVELY USED (DO NOT DELETE)
The following objects are part of the active session feedback feature and MUST be preserved:
- ❌ `SessionFeedback` table - KEEP
- ❌ `SessionFeedbackScores` table - KEEP
- ❌ `GetFeedbackQuestions` procedure - KEEP
- ❌ `SaveUserFeedback` procedure - KEEP
- ❌ `DeleteSessionFeedback` procedure - KEEP
- ❌ `AddUpdateSessionFeedbackScore` procedure - KEEP

**Note**: These were initially flagged for investigation but are confirmed ACTIVE in production code.

#### Backup/System Tables (2)
1. `__EFMigrationsHistory` - Entity Framework metadata (safe if EF not used)
2. `Groups_ImageBackup` - Obsolete backup table

#### Administrative Utility - KEPT BY REQUEST
- ✅ `Admin_ResetHubSessionData` - KEEP (user requested retention)

---

## Phases

### Phase 1: Generate ProdCleanup.sql Script

**Objective**: Create production-ready SQL cleanup script with comprehensive safety checks

**Script Location**: `Database/ProdCleanup.sql`

**Script Structure**:
```sql
-- ============================================================================
-- KSESSIONS Cleanup Script
-- Purpose: Remove hub infrastructure after frontend/backend cleanup
-- Target: KSESSIONS_CLEANUP (testing) or KSESSIONS (production)
-- Branch: cleanup
-- Created: 2025-10-24
-- SAFETY: Mandatory database verification, explicit user confirmation required
-- ============================================================================

USE master;
GO

-- ============================================================================
-- MANDATORY SAFETY CHECK #1: Database Name Verification
-- ============================================================================
DECLARE @currentDb NVARCHAR(128) = DB_NAME();
DECLARE @isProduction BIT = 0;

-- Verify we're on a valid cleanup target
IF @currentDb = 'KSESSIONS'
BEGIN
    SET @isProduction = 1;
    PRINT '⚠️  PRODUCTION DATABASE DETECTED: KSESSIONS';
    PRINT '⚠️  This script will modify the PRODUCTION database!';
END
ELSE IF @currentDb = 'KSESSIONS_CLEANUP'
BEGIN
    PRINT '✓ Testing environment detected: KSESSIONS_CLEANUP';
END
ELSE
BEGIN
    RAISERROR('ERROR: This script must run against KSESSIONS or KSESSIONS_CLEANUP only!', 16, 1);
    RAISERROR('Current database: %s', 16, 1, @currentDb);
    RAISERROR('Script execution ABORTED for safety.', 16, 1);
    RETURN;
END

-- Production environment requires explicit acknowledgment
IF @isProduction = 1
BEGIN
    PRINT '';
    PRINT '╔════════════════════════════════════════════════════════════════╗';
    PRINT '║                    ⚠️  PRODUCTION WARNING ⚠️                    ║';
    PRINT '╠════════════════════════════════════════════════════════════════╣';
    PRINT '║  You are about to modify the PRODUCTION database!             ║';
    PRINT '║  This operation will PERMANENTLY DELETE database objects.     ║';
    PRINT '║                                                                ║';
    PRINT '║  STOP NOW if:                                                  ║';
    PRINT '║  • You do not have explicit approval to proceed                ║';
    PRINT '║  • Production backup has not been verified                     ║';
    PRINT '║  • This script has not been tested on KSESSIONS_CLEANUP        ║';
    PRINT '║                                                                ║';
    PRINT '║  To proceed, you must manually continue script execution.     ║';
    PRINT '╚════════════════════════════════════════════════════════════════╝';
    PRINT '';
    
    -- Force 10-second pause for production to allow manual review
    WAITFOR DELAY '00:00:10';
END

GO

-- ============================================================================
-- MANDATORY SAFETY CHECK #2: Backup Verification (Manual)
-- ============================================================================
PRINT '============================================================================';
PRINT 'PRE-EXECUTION CHECKLIST (MANDATORY)';
PRINT '============================================================================';
PRINT '';
PRINT '[ ] 1. Database backup created and verified';
PRINT '[ ] 2. Hub data archived in Hub_Cleanup_Archive folder';
PRINT '[ ] 3. Frontend hub code removed and tested';
PRINT '[ ] 4. Backend hub code removed and tested';
PRINT '[ ] 5. Git branch = cleanup (confirmed)';
PRINT '[ ] 6. Application tested without hub functionality';
PRINT '[ ] 7. Script tested successfully on KSESSIONS_CLEANUP (if production)';
PRINT '[ ] 8. Explicit approval obtained (if production)';
PRINT '';
PRINT '============================================================================';
PRINT 'CRITICAL: Verify ALL checklist items before proceeding';
PRINT 'If ANY item is unchecked, STOP NOW and complete it first.';
PRINT '============================================================================';
PRINT '';

-- Force manual confirmation pause (longer for production)
DECLARE @pauseSeconds INT = CASE WHEN DB_NAME() = 'KSESSIONS' THEN 10 ELSE 5 END;
DECLARE @pauseDelay VARCHAR(8) = '00:00:' + RIGHT('0' + CAST(@pauseSeconds AS VARCHAR(2)), 2);
PRINT 'Pausing for ' + CAST(@pauseSeconds AS VARCHAR(2)) + ' seconds to review checklist...';
WAITFOR DELAY @pauseDelay;
PRINT 'Proceeding with cleanup...';
PRINT '';
GO

-- ============================================================================
-- EXECUTION START
-- ============================================================================
DECLARE @targetDb NVARCHAR(128) = DB_NAME();
DECLARE @environment VARCHAR(20) = CASE WHEN @targetDb = 'KSESSIONS' THEN 'PRODUCTION' ELSE 'TESTING' END;

PRINT '';
PRINT '============================================================================';
PRINT 'KSESSIONS Hub Infrastructure Cleanup';
PRINT 'Target Database: ' + @targetDb;
PRINT 'Environment: ' + @environment;
PRINT 'Execution Date: ' + CONVERT(VARCHAR, GETDATE(), 120);
PRINT '============================================================================';
PRINT '';
GO

-- Switch to target database (works for both KSESSIONS and KSESSIONS_CLEANUP)
DECLARE @targetDb NVARCHAR(128);
DECLARE @sql NVARCHAR(500);

-- Determine target database
IF EXISTS (SELECT 1 FROM sys.databases WHERE name = 'KSESSIONS' AND DB_NAME() = 'KSESSIONS')
    SET @targetDb = 'KSESSIONS';
ELSE IF EXISTS (SELECT 1 FROM sys.databases WHERE name = 'KSESSIONS_CLEANUP' AND DB_NAME() = 'KSESSIONS_CLEANUP')
    SET @targetDb = 'KSESSIONS_CLEANUP';
ELSE
BEGIN
    RAISERROR('ERROR: Cannot determine target database. Aborting.', 16, 1);
    RETURN;
END

-- Switch to target database
SET @sql = 'USE [' + @targetDb + ']';
EXEC sp_executesql @sql;

PRINT '✓ Connected to ' + @targetDb;
PRINT '';
GO

-- ============================================================================
-- STEP 1: Drop Stored Procedures (No Dependencies)
-- ============================================================================
PRINT 'STEP 1: Removing hub stored procedures...';
PRINT '';

IF EXISTS (SELECT 1 FROM sys.procedures WHERE name = 'AddUpdateHubPreloaderData')
BEGIN
    DROP PROCEDURE [dbo].[AddUpdateHubPreloaderData];
    PRINT '  ✓ Dropped AddUpdateHubPreloaderData';
END
ELSE
    PRINT '  ⊘ AddUpdateHubPreloaderData not found (already removed)';

IF EXISTS (SELECT 1 FROM sys.procedures WHERE name = 'CreateHubSessionData')
BEGIN
    DROP PROCEDURE [dbo].[CreateHubSessionData];
    PRINT '  ✓ Dropped CreateHubSessionData';
END
ELSE
    PRINT '  ⊘ CreateHubSessionData not found (already removed)';

IF EXISTS (SELECT 1 FROM sys.procedures WHERE name = 'GetHubProfileForSession')
BEGIN
    DROP PROCEDURE [dbo].[GetHubProfileForSession];
    PRINT '  ✓ Dropped GetHubProfileForSession';
END
ELSE
    PRINT '  ⊘ GetHubProfileForSession not found (already removed)';

IF EXISTS (SELECT 1 FROM sys.procedures WHERE name = 'SaveHubUserQuestion')
BEGIN
    DROP PROCEDURE [dbo].[SaveHubUserQuestion];
    PRINT '  ✓ Dropped SaveHubUserQuestion';
END
ELSE
    PRINT '  ⊘ SaveHubUserQuestion not found (already removed)';

PRINT '';
PRINT 'Hub stored procedures removal complete.';
PRINT '';
GO

-- ============================================================================
-- STEP 2: Drop Hub Tables (Dependency Order)
-- ============================================================================
PRINT 'STEP 2: Removing hub tables (dependency order)...';
PRINT '';

-- Child tables first
IF EXISTS (SELECT 1 FROM sys.tables WHERE name = 'HubUserQuestions')
BEGIN
    DROP TABLE [dbo].[HubUserQuestions];
    PRINT '  ✓ Dropped HubUserQuestions';
END
ELSE
    PRINT '  ⊘ HubUserQuestions not found (already removed)';

IF EXISTS (SELECT 1 FROM sys.tables WHERE name = 'HubSessionData')
BEGIN
    DROP TABLE [dbo].[HubSessionData];
    PRINT '  ✓ Dropped HubSessionData';
END
ELSE
    PRINT '  ⊘ HubSessionData not found (already removed)';

IF EXISTS (SELECT 1 FROM sys.tables WHERE name = 'HubPreloader')
BEGIN
    DROP TABLE [dbo].[HubPreloader];
    PRINT '  ✓ Dropped HubPreloader';
END
ELSE
    PRINT '  ⊘ HubPreloader not found (already removed)';

-- Lookup tables (no dependencies)
IF EXISTS (SELECT 1 FROM sys.tables WHERE name = 'ZHubFeedbackQuestions')
BEGIN
    DROP TABLE [dbo].[ZHubFeedbackQuestions];
    PRINT '  ✓ Dropped ZHubFeedbackQuestions';
END
ELSE
    PRINT '  ⊘ ZHubFeedbackQuestions not found (already removed)';

IF EXISTS (SELECT 1 FROM sys.tables WHERE name = 'ZHubFeedbackTypes')
BEGIN
    DROP TABLE [dbo].[ZHubFeedbackTypes];
    PRINT '  ✓ Dropped ZHubFeedbackTypes';
END
ELSE
    PRINT '  ⊘ ZHubFeedbackTypes not found (already removed)';

PRINT '';
PRINT 'Hub tables removal complete.';
PRINT '';
GO

-- ============================================================================
-- STEP 3: Drop Backup/System Tables (Optional)
-- ============================================================================
PRINT 'STEP 3: Removing backup/system tables...';
PRINT '';

IF EXISTS (SELECT 1 FROM sys.tables WHERE name = 'Groups_ImageBackup')
BEGIN
    DROP TABLE [dbo].[Groups_ImageBackup];
    PRINT '  ✓ Dropped Groups_ImageBackup (obsolete backup)';
END
ELSE
    PRINT '  ⊘ Groups_ImageBackup not found (already removed)';

IF EXISTS (SELECT 1 FROM sys.tables WHERE name = '__EFMigrationsHistory')
BEGIN
    DROP TABLE [dbo].[__EFMigrationsHistory];
    PRINT '  ✓ Dropped __EFMigrationsHistory (EF metadata)';
END
ELSE
    PRINT '  ⊘ __EFMigrationsHistory not found (already removed)';

PRINT '';
PRINT 'Backup/system tables removal complete.';
PRINT '';
GO

-- ============================================================================
-- FINAL VERIFICATION
-- ============================================================================
PRINT '============================================================================';
PRINT 'FINAL VERIFICATION';
PRINT '============================================================================';
PRINT '';

-- Check for remaining hub objects
DECLARE @hubTableCount INT;
DECLARE @hubProcCount INT;

SELECT @hubTableCount = COUNT(*) 
FROM sys.tables 
WHERE name IN ('HubPreloader', 'HubSessionData', 'HubUserQuestions', 
               'ZHubFeedbackQuestions', 'ZHubFeedbackTypes');

SELECT @hubProcCount = COUNT(*) 
FROM sys.procedures 
WHERE name IN ('AddUpdateHubPreloaderData', 'CreateHubSessionData', 
               'GetHubProfileForSession', 'SaveHubUserQuestion');

PRINT 'Hub Tables Remaining: ' + CAST(@hubTableCount AS VARCHAR(5));
PRINT 'Hub Procedures Remaining: ' + CAST(@hubProcCount AS VARCHAR(5));
PRINT '';

IF @hubTableCount = 0 AND @hubProcCount = 0
BEGIN
    PRINT '✅ SUCCESS: All hub infrastructure objects removed';
    PRINT '✅ Database cleanup complete';
END
ELSE
BEGIN
    PRINT '⚠️ WARNING: Some hub objects still exist - manual review required';
END

PRINT '';
PRINT '============================================================================';
PRINT 'CLEANUP COMPLETE';
PRINT 'Database: ' + DB_NAME();
PRINT 'Completion Time: ' + CONVERT(VARCHAR, GETDATE(), 120);
PRINT '============================================================================';
PRINT '';
PRINT 'IMPORTANT: Session Feedback tables/procedures were PRESERVED (active feature)';
PRINT 'IMPORTANT: Admin_ResetHubSessionData procedure was PRESERVED (user request)';
PRINT '';
GO
```

**Deliverables**:
- `Database/ProdCleanup.sql` - Production-ready cleanup script
- Idempotent design (safe to run multiple times)
- Clear console output with ✓/⊘ status indicators
- Mandatory safety checks and verification

---

### Phase 2: Validate on KSESSIONS_CLEANUP

**Objective**: Test cleanup script in isolated environment before production

**Actions**:
1. Execute `ProdCleanup.sql` against `KSESSIONS_CLEANUP` database
2. Verify all 5 hub tables removed
3. Verify all 4 hub procedures removed
4. Verify 2 backup tables removed
5. Confirm no orphaned foreign keys or dependencies
6. Document execution output and verification results

**Expected Results**:
```
Hub Tables Remaining: 0
Hub Procedures Remaining: 0
✅ SUCCESS: All hub infrastructure objects removed
```

**Validation Queries**:
```sql
-- Check for any remaining hub objects
SELECT name, type_desc FROM sys.objects 
WHERE name LIKE '%Hub%' 
ORDER BY type_desc, name;

-- Verify Session Feedback system intact
SELECT name FROM sys.tables 
WHERE name IN ('SessionFeedback', 'SessionFeedbackScores');
-- Should return 2 rows

SELECT name FROM sys.procedures 
WHERE name IN ('GetFeedbackQuestions', 'SaveUserFeedback', 
               'DeleteSessionFeedback', 'AddUpdateSessionFeedbackScore');
-- Should return 4 rows
```

**Deliverables**:
- `Database/Hub_Cleanup_Archive/ProdCleanup_Validation.md` - Test results
- Console output log from script execution
- Before/after object count comparison

---

### Phase 3: Production Readiness Review

**Objective**: Final review and approval gate before production deployment

**Review Checklist**:
- [ ] Script tested successfully on KSESSIONS_CLEANUP
- [ ] All safety checks verified working
- [ ] Session Feedback system confirmed intact
- [ ] Frontend hub code removed from production branch
- [ ] Backend hub code removed from production branch
- [ ] Production database backup created and verified
- [ ] Git tag created: `pre-database-cleanup`
- [ ] Deployment window scheduled (if required)
- [ ] Rollback plan documented
- [ ] DBA/stakeholder approval obtained

**Deliverables**:
- Production execution plan document
- Rollback procedure (restore from backup)
- Sign-off checklist (to be completed before execution)

---

## Safety Guardrails

### Mandatory Requirements

1. **Database Name Verification** ✅
   - Script MUST verify target database is KSESSIONS or KSESSIONS_CLEANUP
   - Exit immediately if ANY other database detected
   - Implemented via `IF @currentDb = 'KSESSIONS' OR @currentDb = 'KSESSIONS_CLEANUP'` check
   - Automatic environment detection (PRODUCTION vs TESTING)

2. **Pre-Execution Checklist** ✅
   - Manual checklist displayed at script start
   - 5-second pause to review checklist
   - User must complete all items before proceeding

3. **User Confirmation Required** ✅
   - This plan has `auto_invoke: false`
   - **TESTING**: 5-second pause to review checklist before execution
   - **PRODUCTION**: 10-second pause + explicit warning banner
   - Production requires documented approval before execution
   - No manual script changes needed - script auto-detects environment

4. **Git Branch Verification** ✅
   - All work performed on `cleanup` branch
   - Production deployment only after merge approval

5. **Backup Verification** ✅
   - Script includes backup reminder in checklist
   - Cannot proceed without backup confirmation

6. **Idempotent Design** ✅
   - Script uses `IF EXISTS` checks before drops
   - Safe to run multiple times
   - Provides clear feedback on already-removed objects

### Recommended Practices

1. **Test First** - Always test on KSESSIONS_CLEANUP before production
2. **Off-Hours Deployment** - Schedule during low-traffic window
3. **Monitor Application** - Watch for errors after deployment
4. **Staged Rollout** - Consider testing with subset of users first
5. **Communication** - Notify stakeholders before/after deployment

---

## Rollback Strategy

### If Issues Detected After Cleanup

**Option 1: Restore from Backup** (Recommended)
```sql
USE master;
GO

-- Set database to single user mode
ALTER DATABASE KSESSIONS SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO

-- Restore from backup
RESTORE DATABASE KSESSIONS
FROM DISK = 'D:\BACKUPS\KSESSIONS_PreCleanup_20251024.bak'
WITH REPLACE, RECOVERY;
GO

-- Set back to multi-user mode
ALTER DATABASE KSESSIONS SET MULTI_USER;
GO
```

**Option 2: Recreate Objects** (If backup unavailable)
- Use archived SQL scripts from `Hub_Cleanup_Archive/Hub_StoredProcedures_Backup.sql`
- Restore table data from JSON archives in `Hub_Cleanup_Archive/`
- Note: This is more complex and time-consuming

---

## Excluded Objects (DO NOT DELETE)

### Active Session Feedback System
These objects are part of an actively-used feature and MUST remain:

**Tables**:
- `SessionFeedback` - Stores user feedback responses
- `SessionFeedbackScores` - Stores aggregated feedback scores

**Stored Procedures**:
- `GetFeedbackQuestions` - Retrieves feedback questions for session
- `SaveUserFeedback` - Persists user feedback responses
- `DeleteSessionFeedback` - Removes feedback for session/member
- `AddUpdateSessionFeedbackScore` - Updates feedback score

**Code References**:
- Frontend: `zuFeedback.js`, `feedback.js`, `session.js`
- Backend: `SessionController.GetFeedbackQuestionForSession()`
- API Endpoint: `GET /api/sessions/{sessionId}/feedback-questions`

### Administrative Utility (Kept by Request)
- `Admin_ResetHubSessionData` - User requested retention for admin purposes

---

## Success Criteria

### Phase 1 Success
- [x] `ProdCleanup.sql` script created
- [x] Script includes all safety checks
- [x] Script is idempotent
- [x] Script targets correct objects only

### Phase 2 Success
- [ ] Script executes without errors on KSESSIONS_CLEANUP
- [ ] All 5 hub tables removed
- [ ] All 4 hub procedures removed
- [ ] 2 backup tables removed
- [ ] Session Feedback system verified intact
- [ ] No orphaned dependencies found

### Phase 3 Success
- [ ] Production review checklist completed
- [ ] Backup verified
- [ ] Stakeholder approval obtained
- [ ] Deployment plan documented

### Production Deployment Success
- [ ] Script executes without errors on KSESSIONS
- [ ] Application functions normally after cleanup
- [ ] No error logs related to missing database objects
- [ ] Git tag created: `post-database-cleanup`
- [ ] Cleanup documented in production migration log

---

## Risk Assessment

### Low Risk Items ✅
- Hub tables removal (archived, code removed)
- Hub procedures removal (no active references)
- Backup tables removal (obsolete)
- Script safety checks (comprehensive)

### Medium Risk Items ⚠️
- EF Migrations table removal (verify EF not in use)
- Production timing (coordinate deployment window)

### High Risk Items ❌
- **NONE** - Session Feedback excluded from cleanup

---

## Timeline Estimate

**Phase 1** (Script Generation): 30 minutes  
**Phase 2** (Validation Testing): 1 hour  
**Phase 3** (Production Review): 2-4 hours (depends on approval process)  
**Production Deployment**: 15 minutes (+ monitoring time)

**Total**: 4-6 hours from start to production deployment

---

## Dependencies

**Prerequisites**:
- ✅ Hub frontend code removed (Phases 2-4 of hub cleanup)
- ✅ Hub backend code removed (Phase 4 of hub cleanup)
- ✅ Hub data archived in `Hub_Cleanup_Archive`
- ✅ Application tested without hub functionality
- ✅ Git branch `cleanup` active

**Blocks**:
- None - ready to proceed

---

## Notes

1. **KQUR Database**: No cleanup required - confirmed to have zero hub infrastructure
2. **Session Feedback**: Investigation confirmed this is an ACTIVE feature, not hub-related
3. **Script Design**: Idempotent and safe for multiple executions
4. **Testing Environment**: KSESSIONS_CLEANUP provides isolated test environment
5. **Production Migration**: Manual execution only, no automated deployment

---

## Implementation Team

**Planning**: GitHub Copilot (Feature Planning Agent)  
**Execution**: User approval required for each phase  
**Validation**: User/DBA verification of test results  
**Production Deployment**: DBA/Admin with explicit approval

---

## References

- Original cleanup plan: `Workspaces/CONTEXT/COPILOT/CopilotChats.md`
- Hub data archive: `Database/Hub_Cleanup_Archive/`
- Hub procedures backup: `Database/Hub_Cleanup_Archive/Hub_StoredProcedures_Backup.sql`
- Phase 0 summary: `Database/Hub_Cleanup_Archive/Phase0B_Summary.md`
- Database creation script: `Database/Phase0_Create_KSESSIONS_CLEANUP.sql`

---

**Plan Status**: ✅ Ready for Handoff  
**Next Step**: User approval to begin Phase 1 implementation
