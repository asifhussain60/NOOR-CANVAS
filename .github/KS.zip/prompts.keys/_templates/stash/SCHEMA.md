# Stash Schema Documentation

## Overview

The stash system uses two JSON schema types:
1. **Individual Stash** - Full state snapshot at a specific point
2. **Consolidated Archive** - Lightweight summaries of multiple stashes

---

## Directory Structure

```
.github/prompts.keys/{key}/
├── stash/
│   ├── 2025-10-24T14-30-00.json    ← Individual stash (newest)
│   ├── 2025-10-24T12-15-00.json    ← Individual stash
│   └── archive-2025-10-23.json     ← Consolidated archive (3 older stashes)
├── work-log.md
├── {key}.plan.md
└── {key}.plan.json
```

**Naming Convention**:
- Individual: `YYYY-MM-DDTHH-MM-SS.json` (ISO 8601 format)
- Archive: `archive-YYYY-MM-DD.json` (date of consolidation)

---

## Individual Stash Schema

### Purpose
Capture complete plan state for full restoration capability.

### Required Fields
- `key` - Plan identifier (lowercase-with-dashes)
- `timestamp` - ISO 8601 datetime when stashed
- `git_ref` - Commit hash (7-40 chars hex)
- `branch` - Git branch name
- `current_phase` - Phase just completed/in-progress
- `next_phase` - Phase to execute on resume

### Optional Fields
- `reason` - User explanation for stashing
- `phase_status` - "completed" | "in-progress" | "blocked"
- `pending_tasks` - Array of task descriptions
- `work_log_snapshot` - Full work-log.md contents
- `plan_json_snapshot` - Full plan.json contents
- `metadata` - Build status, file counts, etc.

### Example
```json
{
  "key": "cleanup",
  "timestamp": "2025-10-24T14:30:00Z",
  "reason": "Working on prompt enhancements",
  "git_ref": "ae98b5b9",
  "branch": "cleanup",
  "current_phase": 3,
  "next_phase": 5,
  "phase_status": "completed",
  "pending_tasks": [
    "AdminUtilityController refactor",
    "SignalR package removal"
  ],
  "metadata": {
    "files_modified": 22,
    "build_status": "success"
  }
}
```

---

## Consolidated Archive Schema

### Purpose
Reduce file count by merging old stashes into single archive with lightweight metadata.

### Required Fields
- `key` - Plan identifier
- `consolidated_at` - ISO 8601 datetime of consolidation
- `stash_count` - Number of stashes merged (typically 3)
- `stashes` - Array of stash summaries

### Stash Summary Object
- `timestamp` - When stash was created
- `phase` - Phase number at time of stash
- `git_ref` - Commit hash
- `reason` - User-provided reason (optional)
- `branch` - Git branch name (optional)

### Example
```json
{
  "key": "cleanup",
  "consolidated_at": "2025-10-24T16:30:00Z",
  "stash_count": 3,
  "stashes": [
    {
      "timestamp": "2025-10-24T12:00:00Z",
      "phase": 2,
      "git_ref": "a1b2c3d4",
      "reason": "First pause"
    },
    {
      "timestamp": "2025-10-24T13:00:00Z",
      "phase": 2,
      "git_ref": "e5f6g7h8",
      "reason": "Second pause"
    },
    {
      "timestamp": "2025-10-24T14:00:00Z",
      "phase": 3,
      "git_ref": "i9j0k1l2",
      "reason": "Third pause"
    }
  ]
}
```

---

## Auto-Consolidation Logic

### Trigger
When 4th individual stash is created for the same key.

### Process
1. List all JSON files in `stash/` directory (exclude `archive-*.json`)
2. Sort by timestamp (oldest first)
3. Take 3 oldest stashes
4. Extract summary metadata from each:
   - timestamp
   - phase (current_phase)
   - git_ref
   - reason (if present)
   - branch (if present)
5. Create new `archive-{today}.json` with summaries
6. Delete 3 oldest individual stash files
7. Keep newest stash as individual file

### Consolidation Date Handling
- If archive already exists for today: Append to existing stashes array
- If archive exists for different date: Create new archive for today
- Archive filename uses UTC date

### User Experience
```
User creates 4th stash:

Agent:
✓ Stash saved: 2025-10-24T16-45-00.json
ℹ️ Auto-consolidated 3 older stashes → archive-2025-10-24.json
✓ Ready to work on new task
```

---

## Metadata Capture Functions

### Git Metadata
```bash
# Current commit hash
git rev-parse HEAD

# Current branch
git rev-parse --abbrev-ref HEAD

# Modified files
git diff --name-only HEAD

# Commit count since plan start
git rev-list $(cat .github/prompts.keys/{key}/.start-ref)..HEAD --count
```

### Plan Metadata
```bash
# Current phase from plan.json
jq '.current_phase' .github/prompts.keys/{key}/{key}.plan.json

# Next phase from plan.json
jq '.phases[] | select(.status == "pending") | .id' | head -1

# Pending tasks from plan.json
jq '.phases[] | select(.status == "pending") | .tasks[]'
```

### Build Metadata
```bash
# Last build status (from CI or manual build)
# Implementation depends on build system
# For KSESSIONS: Check MSBuild exit code or output parsing
```

---

## Validation Rules

### On Stash Save
1. Verify `key` matches pattern `^[a-z0-9-]+$`
2. Verify `git_ref` exists in repository
3. Verify `current_phase` ≤ total phases in plan
4. Verify `next_phase` > current_phase
5. Verify work-log.md and plan.json exist

### On Stash Resume
1. Verify stash file is valid JSON
2. Verify required fields present
3. Verify git_ref still exists (or handle orphaned ref)
4. Verify branch still exists (or warn user)
5. Verify work-log and plan snapshots are valid

### On Consolidation
1. Verify ≥3 individual stashes exist
2. Verify all stash files are valid JSON
3. Verify archive doesn't exceed 1MB (reasonable limit)
4. Create backup of individual stashes before deletion

---

## Error Handling

### Invalid JSON
```json
❌ Stash file corrupted: cleanup/2025-10-24T14-30-00.json
Parse error: Unexpected token at line 15

[A] Delete corrupted stash
[B] Show raw file content
[C] Cancel
```

### Missing Required Field
```json
❌ Invalid stash: cleanup/2025-10-24T14-30-00.json
Missing required field: git_ref

[A] Delete invalid stash
[B] Attempt repair
[C] Cancel
```

### Git Ref Not Found
```json
⚠️ Git ref ae98b5b9 no longer exists
Stash may be from rebased or deleted branch

[A] Force resume with current HEAD
[B] Delete stash
[C] Cancel
```

---

## Schema Evolution

### Versioning
Future schema changes should include version field:
```json
{
  "schema_version": "1.0.0",
  "key": "cleanup",
  ...
}
```

### Backward Compatibility
- Version 1.0: Initial schema (this document)
- Future versions: Add optional fields only
- Never remove required fields
- Provide migration tool if breaking changes needed

---

## Performance Considerations

### File Size
- Individual stash: ~10-50 KB (with snapshots)
- Archive: ~5-15 KB (summaries only)
- After consolidation: 50% disk space savings

### Read Performance
- List stashes: O(n) directory scan
- Load stash: O(1) direct file read
- Consolidation: O(n) for 3 stash reads + 1 write

### Recommended Limits
- Max individual stashes per key: 10 (before manual cleanup warning)
- Max archive size: 1 MB (before split warning)
- Max stash age: 30 days (before expiry warning)

---

## Templates Location

Schema templates and examples:
- `.github/prompts.keys/_templates/stash/stash-template.json`
- `.github/prompts.keys/_templates/stash/archive-template.json`

See `stash.prompt.md` for usage documentation.
