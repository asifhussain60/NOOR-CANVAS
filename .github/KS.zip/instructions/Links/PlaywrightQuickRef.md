# Generic Template — Configured by total-recall

> **NOTE**: This is a TEMPLATE file. To configure for your project:
> 1. Run: `@workspace /total-recall`
> 2. Review generated files in `.github/_Portable/_Configured/`
> 3. Copy to `.github/` when satisfied

**Template Variables Used:**
- `{{PROJECT_NAME}}`
- `{{REALTIME_TECH}}`
- `{{RUN_COMMAND}}`
- `{{SOURCE_PATH}}`
- `{{TEST_FRAMEWORK}}`
- `{{TEST_PATH}}`

---
# {{TEST_FRAMEWORK}} Testing Quick Reference

**Version**: 2.0.0  
**Last Updated**: 2025-10-16  
**Purpose**: Authoritative {{TEST_FRAMEWORK}} testing reference - eliminates ambiguity in test creation and execution

---

## ⚠️ CRITICAL: Server Management Rules

**{{TEST_FRAMEWORK}} MANAGES THE SERVER AUTOMATICALLY - DO NOT START IT MANUALLY!**

Port policy: The application must bind only to HTTPS on 9091. Do not bind to 9090.

### ❌ NEVER Do This for {{TEST_FRAMEWORK}} Tests:
```powershell
# WRONG - Don't manually start the app
{{RUN_COMMAND}}
./Workspaces/Global/nc.ps1
./Workspaces/Global/ncb.ps1
Start-Process powershell -ArgumentList "{{RUN_COMMAND}}"
```

### ✅ ALWAYS Do This:
```bash
# RIGHT - Let {{TEST_FRAMEWORK}} manage everything
PW_MODE=standalone npx {{TEST_FRAMEWORK}} test

# {{TEST_FRAMEWORK}} automatically:
# 1. Starts {{RUN_COMMAND}} (background subprocess)
# 2. Waits for port 9091 to be ready
# 3. Runs all tests
# 4. Stops the server
# 5. Cleans up processes
```

### How webServer Works:
- **Not a separate window**: Server runs as invisible Node.js subprocess
- **Automatic lifecycle**: Start → Wait → Test → Stop
- **Port monitoring**: Waits for port 9091 to respond before testing
- **Process cleanup**: Kills server process when tests complete
- **Error handling**: Stops server even if tests fail

### Manual Server Launch is ONLY for:
- **Browser Development**: Manual testing in browser (use `nc.ps1`)
- **Debugging**: Visual Studio/VS Code debugger
- **Demo Pages**: Showing features to stakeholders
- **NEVER**: For running automated {{TEST_FRAMEWORK}} tests

---

## 📝 CRITICAL: Code Style Rules

### Emoji Usage in Test Scripts
**❌ NEVER use emojis in console.log statements or test code**

```typescript
// WRONG - Contains emojis
console.log('📱 Loading Host Control Panel...');
console.log('✅ Test passed');
console.log('🖱️ Clicking button...');

// RIGHT - ASCII only
console.log('[INFO] Loading Host Control Panel...');
console.log('[PASS] Test passed');
console.log('[ACTION] Clicking button...');
```

**Rationale:**
- Emojis cause encoding issues in CI/CD pipelines
- PowerShell terminals may not render emojis correctly
- Log files become unreadable with special characters
- ASCII ensures cross-platform compatibility

### Console Logging Standards
```typescript
// Use structured ASCII prefixes
console.log('[STEP] Navigate to page');       // Test steps
console.log('[VERIFY] Element is visible');   // Verification
console.log('[PASS] Test completed');         // Success
console.log('[WARN] Non-critical error');     // Warnings
console.log('[ERROR] Critical failure');      // Errors
console.log('[INFO] Additional context');     // Information
```

---

## 🖥️ CRITICAL: Application Management for Manual Testing

**When YOU (Copilot) need to run tests that require manual app startup:**

### Step 1: Launch Application in Separate PowerShell Window
```powershell
# Start app in NEW window (not background process)
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd 'D:\PROJECTS\{{PROJECT_NAME}}\SPA\{{PROJECT_NAME}}'; $env:ASPNETCORE_URLS='https://localhost:9091'; {{RUN_COMMAND}}" -WindowStyle Normal

# Store the process info
# The app will run in its own window, visible to user
```

### Step 2: Wait for Application to be Ready
```powershell
# Wait for app startup (15-20 seconds typical)
Start-Sleep -Seconds 20

# Verify app is listening
netstat -ano | findstr "LISTENING" | findstr ":9091"
```

### Step 3: Run Tests in Current Terminal
```powershell
# Run {{TEST_FRAMEWORK}} tests in the CURRENT terminal window
npx {{TEST_FRAMEWORK}} test path/to/test.spec.ts --headed --reporter=list
```

### Step 4: Clean Up After Tests Complete
```powershell
# Find and kill the app PowerShell window process
$appProcess = Get-Process powershell | Where-Object { 
    $_.MainWindowTitle -like "*{{RUN_COMMAND}}*" -or 
    $_.CommandLine -like "*{{PROJECT_NAME}}*{{RUN_COMMAND}}*" 
}

if ($appProcess) {
    Stop-Process -Id $appProcess.Id -Force
    Write-Host "[CLEANUP] Killed application process: $($appProcess.Id)"
} else {
    Write-Host "[WARN] Could not find application process to clean up"
}

# Alternative: Kill by port
$portProcess = netstat -ano | findstr ":9091" | findstr "LISTENING"
if ($portProcess -match '\s+(\d+)$') {
    $pid = $matches[1]
    Stop-Process -Id $pid -Force
    Write-Host "[CLEANUP] Killed process on port 9091: $pid"
}
```

### Complete Workflow Example
```powershell
# 1. Launch app
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd 'D:\PROJECTS\{{PROJECT_NAME}}\SPA\{{PROJECT_NAME}}'; $env:ASPNETCORE_URLS='https://localhost:9091'; {{RUN_COMMAND}}" -WindowStyle Normal

# 2. Wait for startup
Start-Sleep -Seconds 20

# 3. Run tests
npx {{TEST_FRAMEWORK}} test Workspaces/TEMP/share-transcript-navigation.spec.ts --headed

# 4. Cleanup
$pid = (netstat -ano | findstr ":9091" | findstr "LISTENING" | Select-String -Pattern '\s+(\d+)$').Matches.Groups[1].Value
if ($pid) { Stop-Process -Id $pid -Force }
```

### When to Use This Approach
- **✅ Use when**: Test file is in `Workspaces/TEMP/` (temporary test)
- **✅ Use when**: Debugging specific issues that need visual app window
- **✅ Use when**: Percy visual regression tests need manual verification
- **❌ NEVER use**: For standard CI/CD tests in `{{TEST_FRAMEWORK}}/{{TEST_PATH}}`
- **❌ NEVER use**: When `webServer` configuration is available in `{{TEST_FRAMEWORK}}.config.cjs`

---

## 🎯 Testing Strategy Overview

**{{PROJECT_NAME}} uses three complementary testing approaches:**

### 1. **Functional E2E Tests** ({{TEST_FRAMEWORK}} - Standard)
- **Purpose**: Verify user interactions and business logic
- **When**: User flows, API integration, multi-user scenarios, {{REALTIME_TECH}} broadcasts
- **Tools**: {{TEST_FRAMEWORK}} `@{{TEST_FRAMEWORK}}/test`
- **Example**: Submit question, vote on question, participant registration

### 2. **Visual Regression Tests** (Percy + {{TEST_FRAMEWORK}})
- **Purpose**: Catch visual/CSS rendering issues
- **When**: CSS changes, layout modifications, responsive design, color scheme updates
- **Tools**: Percy `@percy/{{TEST_FRAMEWORK}}` + {{TEST_FRAMEWORK}}
- **Example**: Question card styling, vote badge positioning, modal layouts

### 3. **CSS Quality Tests** (Stylelint - Pre-commit)
- **Purpose**: Prevent CSS conflicts and bad patterns
- **When**: Before every commit, automated in CI/CD
- **Tools**: Stylelint `stylelint`
- **Example**: Duplicate properties, named colors, class naming violations

**See Decision Matrix below for when to use each approach.**

---

## 🎯 When User Says "{{TEST_FRAMEWORK}} Test" or "pwtest"

**Copilot Should Know**:
1. **Test Location**: `{{TEST_FRAMEWORK}}/{{TEST_PATH}}` or `{{TEST_PATH}}UI/` or `Workspaces/TEMP/` (for temporary tests)
2. **Configuration**: `config/testing/{{TEST_FRAMEWORK}}.config.cjs`
3. **Test Data**: Session 212 with tokens KJAHA99L (user) / PQ9N5YWW (host)
4. **Base URL**: `https://localhost:9091`
5. **Execution Modes**: standalone, temp, CI, **percy** (visual regression)
6. **Browser**: Chromium (default), Firefox, WebKit available
7. **Visual Testing**: Percy integration available for visual regression

---

## 📁 Test File Structure

### Standard Test Template
```typescript
import { test, expect } from '@{{TEST_FRAMEWORK}}/test';

test.describe('Feature Name', () => {
  test('should do something specific', async ({ page }) => {
    // Navigate
    await page.goto('https://localhost:9091/route');
    
    // Interact
    await page.click('selector');
    
    // Assert
    await expect(page.locator('selector')).toBeVisible();
  });
});
```

### Test File Naming Convention
- **Pattern**: `{feature}-{test-type}.spec.ts`
- **Examples**:
  - `session-canvas-loading.spec.ts`
  - `user-registration-flow.spec.ts`
  - `host-control-panel-navigation.spec.ts`

### Test Location Rules
1. **Permanent Tests**: `{{TEST_FRAMEWORK}}/{{TEST_PATH}}` or `{{TEST_PATH}}UI/`
2. **Temporary Tests**: `Workspaces/TEMP/` (auto-cleanup after task completion)
3. **Phase Tests**: `Workspaces/TEMP/` with naming: `{agent}-phase-{n}-{key}-{RUN_ID}.spec.ts`

---

## 🎯 Testing Approach Decision Matrix

**Use this matrix to choose the right testing tool for your change:**

| Change Type | Testing Tool | Why | Example |
|------------|--------------|-----|---------|
| **User Workflow/Behavior** | {{TEST_FRAMEWORK}} (Functional E2E) | Tests actual user interactions, API calls, {{REALTIME_TECH}} updates | User joins session, submits question, votes |
| **Visual/Styling Changes** | Percy (Visual Regression) | Pixel-perfect comparison across viewports, catches unintended CSS changes | Orange card rendering, button styles, layout shifts |
| **CSS Code Quality** | Stylelint (Pre-commit) | Prevents CSS conflicts before they reach the browser | Class naming conventions, duplicate properties, color formats |
| **Component Refactor** | Percy + {{TEST_FRAMEWORK}} | Percy validates visual consistency, {{TEST_FRAMEWORK}} validates behavior | Refactoring question card component |
| **API Change** | {{TEST_FRAMEWORK}} (Functional E2E) | Tests API contract, response format, error handling | New participant endpoint, {{REALTIME_TECH}} hub changes |
| **Responsive Design** | Percy (Multi-viewport) | Tests layout across 375px/768px/1280px viewports | Mobile-first design, tablet layout, desktop grid |
| **Theme Changes** | Percy + Stylelint | Percy validates visual output, Stylelint validates CSS quality | Dark mode, color scheme updates, Blazor theme |
| **Accessibility Fix** | {{TEST_FRAMEWORK}} (Functional E2E) | Tests ARIA attributes, keyboard navigation, screen reader support | ARIA labels, focus management, semantic HTML |

### Decision Flowchart

```
Did you change...
│
├─ User flows/interactions? → {{TEST_FRAMEWORK}} Functional Test
│  ├─ Examples: Login, navigation, form submission, voting
│  └─ File: {{TEST_PATH}}UI/*-functional.spec.ts
│
├─ Visual appearance/CSS? → Percy Visual Test + Stylelint
│  ├─ Examples: Button colors, card layouts, spacing, themes
│  ├─ Visual Test: {{TEST_PATH}}UI/*-visual.spec.ts (Percy)
│  └─ CSS Quality: npm run lint:css (Stylelint)
│
├─ API/{{REALTIME_TECH}} contract? → {{TEST_FRAMEWORK}} Functional Test
│  ├─ Examples: New endpoints, hub methods, response format
│  └─ File: {{TEST_PATH}}UI/*-api.spec.ts
│
├─ Component internals (no UI change)? → {{TEST_FRAMEWORK}} Functional Test
│  ├─ Examples: Refactoring, performance optimization
│  └─ Validate behavior remains unchanged
│
└─ Multi-viewport responsive design? → Percy Multi-viewport Test
   ├─ Examples: Mobile layout, tablet breakpoints, grid systems
   └─ File: {{TEST_PATH}}UI/*-responsive.spec.ts
```

### Quick Reference Commands

```bash
# Functional E2E Tests ({{TEST_FRAMEWORK}})
npx {{TEST_FRAMEWORK}} test {{TEST_PATH}}UI/feature-name-functional.spec.ts --headed

# Visual Regression Tests (Percy + {{TEST_FRAMEWORK}})
npm run test:percy:visual -- {{TEST_PATH}}UI/feature-name-visual.spec.ts

# CSS Quality Check (Stylelint)
npm run lint:css -- {{SOURCE_PATH}}/Components/**/*.razor

# Full Test Suite (All 3 Approaches)
npx {{TEST_FRAMEWORK}} test && npm run test:percy && npm run lint:css
```

### Percy Visual Test Template

```typescript
import { test, expect } from '@{{TEST_FRAMEWORK}}/test';
import percySnapshot from '@percy/{{TEST_FRAMEWORK}}';

test.describe('Visual Regression: Feature Name', () => {
  test('should render component correctly across viewports', async ({ page }) => {
    // Navigate to the component
    await page.goto('https://localhost:9091/session/canvas/KJAHA99L');
    
    // Wait for component to load
    await page.waitForSelector('[data-testid="component"]');
    
    // Take Percy snapshot (tests 375px, 768px, 1280px viewports)
    await percySnapshot(page, 'Component Name - Initial State', {
      widths: [375, 768, 1280],
      minHeight: 1024
    });
    
    // Interact with component
    await page.click('[data-testid="toggle-button"]');
    await page.waitForTimeout(500); // Wait for animation
    
    // Take another snapshot showing changed state
    await percySnapshot(page, 'Component Name - Active State');
  });
});
```

**Percy Configuration**: See `.percy.yml` for viewport settings and ignored elements.

---

## 🔧 Configuration Files

### Primary Config: `config/testing/{{TEST_FRAMEWORK}}.config.cjs`

**Core Settings**:
```javascript
{
  timeout: 30000,
  testDir: '../../',
  testMatch: [
    '**/{{TEST_FRAMEWORK}}/{{TEST_PATH}}**/*.{test,spec}.{js,ts,jsx,tsx}',
    '**/{{TEST_PATH}}UI/**/*.{test,spec}.{js,ts,jsx,tsx}',
    '**/Workspaces/TEMP/**/*.{test,spec}.{js,ts,jsx,tsx}'
  ],
  retries: 0,
  use: {
    baseURL: 'https://localhost:9091',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    ignoreHTTPSErrors: true
  }
}
```

### Environment Modes

#### 1. Standalone Mode (`PW_MODE=standalone`)
**Purpose**: Automatic .NET app lifecycle management

**Usage**:
```bash
$env:PW_MODE='standalone'; npx {{TEST_FRAMEWORK}} test
```

**Features**:
- Starts .NET app automatically (`{{RUN_COMMAND}}` in `{{SOURCE_PATH}}`)
- Port: 9091
- Timeout: 60000ms for app startup
- Workers: 1 (sequential execution)
- Headless: false (visible browser)
- Viewport: 1280x720
- Video/Trace: retain-on-failure
- Report: `Workspaces/TEMP/{{TEST_FRAMEWORK}}-report/standalone-html`

**When to Use**:
- Manual test execution
- Debugging tests
- Local development

#### 2. Temp Mode (`PW_MODE=temp`)
**Purpose**: Enhanced artifact collection

**Usage**:
```bash
$env:PW_MODE='temp'; npx {{TEST_FRAMEWORK}} test
```

**Features**:
- Video: on (always)
- Trace: on (always)
- Workers: 1
- Retries: 0

**When to Use**:
- Debugging failures
- Capturing full test execution
- Temporary test runs

#### 3. CI Mode (default)
**Purpose**: Continuous Integration

**Features**:
- Headless: true
- Workers: multiple (parallel)
- Video: retain-on-failure
- Trace: on-first-retry

**When to Use**:
- Automated CI/CD pipelines
- Pre-commit hooks
- Batch test execution

---

## 🧪 Test Data (Session 212)

### Canonical Test Session
**Session ID**: `212`

**Why Session 212?**:
- Has complete transcript data
- Multiple participants registered
- Known stable state
- Used across all test documentation

### Test Tokens

#### User Token: `KJAHA99L`
**Purpose**: Participant/user testing

**API Response** (`/api/participant/session/KJAHA99L/me`):
```json
{
  "name": "Peter Parker",
  "userGuid": "b59e3dca-9330-40f5-9de8-9a5350fd2d6a",
  "email": "peter.parker@test.com",
  "country": "Bahrain",
  "joinedAt": "2025-10-01T14:28:43.523333"
}
```

**Test URLs**:
- Session Canvas: `https://localhost:9091/session/canvas/KJAHA99L`
- User Info: API-based participant loading

#### Host Token: `PQ9N5YWW`
**Purpose**: Host control panel testing

**Behavior**:
- Shows registration panel after authentication
- Different content/behavior than user token

**Test URLs**:
- Host Control Panel: `https://localhost:9091/host/control-panel/PQ9N5YWW`
- Registration: `https://localhost:9091/session/join/PQ9N5YWW`
- Session Canvas (Host): `https://localhost:9091/session/canvas/PQ9N5YWW`

### Other Test Data
- **Base URL**: `https://localhost:9091`
- **API Base**: `https://localhost:9091/api`
- **{{REALTIME_TECH}} Hubs**: 
  - `/hub/session`
  - `/hub/qa`
  - `/hub/annotation`

---

## 🚀 Test Execution Commands

### Run All Tests
```bash
npx {{TEST_FRAMEWORK}} test
```

### Run Specific Test File
```bash
npx {{TEST_FRAMEWORK}} test {{TEST_PATH}}UI/session-canvas.spec.ts
```

### Run Tests in Headed Mode
```bash
npx {{TEST_FRAMEWORK}} test --headed
```

### Run Tests with UI Mode (Interactive)
```bash
npx {{TEST_FRAMEWORK}} test --ui
```

### Run in Standalone Mode
```bash
$env:PW_MODE='standalone'; npx {{TEST_FRAMEWORK}} test
```

### Run Specific Browser
```bash
npx {{TEST_FRAMEWORK}} test --project=chromium
npx {{TEST_FRAMEWORK}} test --project=firefox
npx {{TEST_FRAMEWORK}} test --project=webkit
```

### Debug Mode
```bash
npx {{TEST_FRAMEWORK}} test --debug
```

### Generate Report
```bash
npx {{TEST_FRAMEWORK}} show-report
```

---

## 📝 Test Writing Patterns

### API-Based Approach (Preferred)
**Pattern**: Load data from API, not localStorage

```typescript
test('should load participant from API', async ({ page }) => {
  await page.goto('https://localhost:9091/session/canvas/KJAHA99L');
  
  // API call happens automatically in component
  await page.waitForSelector('[data-testid="participant-name"]');
  
  const name = await page.locator('[data-testid="participant-name"]').textContent();
  expect(name).toBe('Peter Parker');
});
```

**Why?**: Eliminates localStorage dependency, more reliable

### Multi-Browser Isolation
**Pattern**: Each test starts fresh, no shared state

```typescript
test.describe('Feature Tests', () => {
  test.beforeEach(async ({ page }) => {
    // Each test gets fresh browser context
    await page.goto('https://localhost:9091');
  });

  test('test 1', async ({ page }) => {
    // Isolated
  });

  test('test 2', async ({ page }) => {
    // Isolated
  });
});
```

### Waiting Strategies

#### Wait for Selector
```typescript
await page.waitForSelector('[data-testid="element"]', { timeout: 10000 });
```

#### Wait for URL
```typescript
await page.waitForURL('**/expected-route');
```

#### Wait for API Response
```typescript
const response = await page.waitForResponse(
  response => response.url().includes('/api/endpoint')
);
```

#### Wait for Network Idle
```typescript
await page.waitForLoadState('networkidle');
```

### Assertion Patterns

#### Visibility
```typescript
await expect(page.locator('selector')).toBeVisible();
await expect(page.locator('selector')).toBeHidden();
```

#### Text Content
```typescript
await expect(page.locator('selector')).toHaveText('Expected Text');
await expect(page.locator('selector')).toContainText('Partial');
```

#### Count
```typescript
await expect(page.locator('selector')).toHaveCount(5);
```

#### URL
```typescript
await expect(page).toHaveURL('https://localhost:9091/expected-route');
```

#### Attribute
```typescript
await expect(page.locator('selector')).toHaveAttribute('attr', 'value');
```

---

## 🎯 Common Test Scenarios

### 1. Navigation Test
```typescript
test('should navigate to session canvas', async ({ page }) => {
  await page.goto('https://localhost:9091/session/canvas/KJAHA99L');
  await expect(page).toHaveURL(/session\/canvas/);
  await expect(page.locator('h1')).toBeVisible();
});
```

### 2. Form Submission Test
```typescript
test('should submit question', async ({ page }) => {
  await page.goto('https://localhost:9091/session/canvas/KJAHA99L');
  
  await page.fill('[data-testid="question-input"]', 'Test question');
  await page.click('[data-testid="submit-button"]');
  
  await expect(page.locator('[data-testid="question-submitted"]')).toBeVisible();
});
```

### 3. API Response Test
```typescript
test('should load data from API', async ({ page }) => {
  const responsePromise = page.waitForResponse(
    response => response.url().includes('/api/participant/session/KJAHA99L/me')
  );
  
  await page.goto('https://localhost:9091/session/canvas/KJAHA99L');
  
  const response = await responsePromise;
  const data = await response.json();
  
  expect(data.name).toBe('Peter Parker');
});
```

### 4. {{REALTIME_TECH}} Real-Time Test
```typescript
test('should receive {{REALTIME_TECH}} updates', async ({ page }) => {
  await page.goto('https://localhost:9091/session/canvas/KJAHA99L');
  
  // Trigger action that should broadcast
  await page.click('[data-testid="vote-button"]');
  
  // Wait for {{REALTIME_TECH}} update to reflect
  await page.waitForSelector('[data-testid="vote-count-updated"]');
  
  const count = await page.locator('[data-testid="vote-count"]').textContent();
  expect(parseInt(count!)).toBeGreaterThan(0);
});
```

---

## 🐛 Debugging Tips

### 1. Slow Motion
```typescript
test.use({ 
  launchOptions: { 
    slowMo: 500  // Slows down by 500ms per action
  } 
});
```

### 2. Screenshots on Failure (Automatic)
- Configured in `{{TEST_FRAMEWORK}}.config.cjs`
- Location: `test-results/` folder

### 3. Video Recording
- Standalone mode: Always on
- Temp mode: Always on
- Default: Only on failure

### 4. Trace Viewer
```bash
npx {{TEST_FRAMEWORK}} show-trace test-results/trace.zip
```

### 5. Console Logs
```typescript
page.on('console', msg => console.log('Browser:', msg.text()));
```

---

## ⚙️ TypeScript Configuration

**File**: `config/testing/tsconfig.json`

```json
{
  "compilerOptions": {
    "target": "ES2020",
    "module": "commonjs",
    "moduleResolution": "node",
    "esModuleInterop": true,
    "skipLibCheck": true,
    "strict": true,
    "types": ["node", "@{{TEST_FRAMEWORK}}/test"]
  },
  "include": [
    "../../{{TEST_FRAMEWORK}}/**/*.ts",
    "../../{{TEST_PATH}}UI/**/*.ts",
    "../../Workspaces/TEMP/**/*.ts"
  ]
}
```

---

## 🧹 Cleanup Rules

### Temporary Test Cleanup
**When**: After task completion (in key data stream update)

**Pattern**:
```powershell
Remove-Item "Workspaces/TEMP/*-phase-*.spec.ts" -Force
Remove-Item "Workspaces/TEMP/{{TEST_FRAMEWORK}}-artifacts/*" -Recurse -Force
```

**Exceptions**: 
- Keep tests if `commit:false` flag used
- Keep tests marked for preservation in key metadata

---

## 📊 Test Reporting

### HTML Report (Default)
```bash
npx {{TEST_FRAMEWORK}} show-report
```

**Location**: `{{TEST_FRAMEWORK}}-report/` or mode-specific folder

### JSON Report
```bash
npx {{TEST_FRAMEWORK}} test --reporter=json
```

### Custom Reporter
Configured in `{{TEST_FRAMEWORK}}.config.cjs` per mode

---

## 🔗 Integration Points

### With Task Agent
- **Step 6.1**: Automatic {{TEST_FRAMEWORK}} test generation for UI tasks
- **Test Location**: `Workspaces/TEMP/` for phase tests
- **Cleanup**: After successful task completion

### With Test-Generation Agent
- Uses Session 212 canonical patterns
- Multi-browser testing support
- API-based test approaches

### With Validation Framework
- Level 5: E2E Testing with {{TEST_FRAMEWORK}}
- Required for UI feature tasks
- Optional for backend-only tasks

---

## 📚 Related Documentation

- **{{TEST_FRAMEWORK}}Config.MD** - Detailed configuration reference
- **{{TEST_FRAMEWORK}}TestPaths.MD** - Canonical test patterns and Session 212 data
- **InfrastructureQuickRef.md** - API endpoints for test assertions
- **Architecture.md** - {{REALTIME_TECH}} hubs and real-time testing

---

## 🔄 Auto-Update Protocol

**This file is maintained by**:
- **cohesion-review** agent - Updates during system-wide reviews
- **sync** agent - Keeps consistent with actual configuration files

**Update Triggers**:
- New test patterns discovered
- Configuration changes in `{{TEST_FRAMEWORK}}.config.cjs`
- New test data added (beyond Session 212)
- New environment modes added
- Test execution strategy changes

**Verification**:
- Compare with `config/testing/{{TEST_FRAMEWORK}}.config.cjs`
- Validate Session 212 test data still valid
- Ensure test commands match actual npm scripts
- Cross-reference with `{{TEST_FRAMEWORK}}Config.MD` and `{{TEST_FRAMEWORK}}TestPaths.MD`

---

**Version History**:
- **1.0.0** (2025-10-12): Initial creation - Consolidated {{TEST_FRAMEWORK}} testing knowledge
