# Security

- Authentication/Authorization checks per endpoint
- Sensitive data handling: avoid logging payload secrets
- TLS and security headers (HSTS, X-Content-Type-Options, CSP upgrade)
- Input validation against contract (reject unknown fields where required)
