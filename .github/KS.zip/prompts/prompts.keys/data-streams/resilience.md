# Resilience

- Retries: transient HTTP/DB with exponential backoff + jitter
- Timeouts: end-to-end budgets and per-hop configs
- Idempotency: request keys for create/update with side-effects
- Circuit-breaking (optional): guard dependencies
- Poison handling: quarantine or DLQ for batch/queue flows
