# Performance

- Pagination and batching guidance
- Caching strategy (server-side for hot reads), invalidation rules
- SQL: index checklist and EXPLAIN template
- Throughput targets and resource ceilings (document SLOs)
