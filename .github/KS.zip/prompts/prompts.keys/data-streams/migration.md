# Migration

- Phased rollout (shadow, mirror, cutover)
- Dual-read/dual-write strategies
- Backfill jobs and checkpoints
- Rollback procedures
