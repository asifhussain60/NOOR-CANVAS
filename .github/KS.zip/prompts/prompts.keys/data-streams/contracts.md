# Contracts

## Purpose
Define wire-level and DTO-level schemas with versioning and validation rules for each stream.

## Template
- Name: <StreamName> Contract v<Version>
- Producers: <list>
- Consumers: <list>
- JSON schema (example payload)
- DTO mapping table (Domain DTO ↔ JSON fields)
- Validation rules (required, ranges, regex)
- Error codes and remediation
- Compatibility notes (added fields, deprecations)

## Example (skeleton)
Stream: Etymology Search
- JSON Request: { "query": "root", "page": 1, "pageSize": 20 }
- JSON Response: { "results": [ ... ], "total": 123 }
- DTOs: RootDerivativeDto, ToggleSummaryStatusDto
- Validation: query length 2..64; pageSize <= 100
