# Producers

Catalog producers for each stream, with trigger, inputs, and side-effects.

- SPA Controllers/Pages: Global.asax paths, MVC routes, API endpoints
- API Controllers: EtymologyController, FileController, etc.
- Jobs: App pool keep-alive, background importers (if any)

For each producer:
- Name, Location (file/class), Endpoint/Trigger
- Input validation
- CorrelationId creation
- Downstream called components
