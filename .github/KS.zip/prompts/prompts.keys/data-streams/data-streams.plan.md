# Implementation Plan: Key Data Streams

Status: READY FOR EXECUTION
Key: data-streams
Branch: development
Created: 2025-10-23
Agent: feature (planning)

---

## Executive summary
Unify KSESSIONS data flows with explicit contracts and operating guidelines so that SPA, API/business, data, and database layers interoperate predictably and are observable, resilient, and performant. This plan introduces a modular prompt/key structure to maintain stream definitions over time.

## Streams in scope (initial cut)
- Etymology Search: SPA → Web API → Data Repository → Stored Procedures → DTOs → SPA
- Ahadees Retrieval/Search: SPA → Web API → Sessions.Data (Dapper) → SQL → DTOs
- Audit & Telemetry: API/Jobs → Audit tables/logs → Reporting
- Email/Notifications: API → SMTP provider (or queue) → delivery statuses
- Preloader Assets: SPA → API → static/network storage → metadata DTOs

Note: These are templates; concrete routes are discovered during execution with repository scanning.

## Architecture model
- Producers: SPA controllers/actions, Web API controllers, scheduled jobs
- Transports: HTTP/JSON, direct DB calls via Dapper, optional queue for async flows
- Consumers: Business services, repositories, DB stored procedures, external providers
- Contracts: DTOs in Sessions.Domain; wire-level JSON with versioned schema

## Contracts
- Versioning: semantic field-level with compatible additions; breaking changes get new contract version
- Validation: required fields, enums, ranges; server-side validation with error codes
- Serialization: preserve camelCase JSON, culture-invariant numeric/date formats

## Resilience
- Retries: exponential backoff with jitter for transient errors (HTTP/DB)
- Timeouts: end-to-end budgets; service and DB timeouts configured explicitly
- Idempotency: keys on create/update where side-effects possible
- Poison handling: dead-letter or quarantine pattern for batch imports

## Observability
- Logs: structured logs with correlationId per request
- Metrics: latency, error rate, throughput per stream endpoint
- Tracing: minimal span model across SPA→API→DB for critical flows

## Performance
- Batching and pagination at repository and stored procedure boundaries
- Caching: server-side for hot reads (configurable TTL); careful invalidation
- Indexing: ensure query paths align with SQL indexes; capture EXPLAIN guidance

## Security
- AuthN/Z: ensure endpoints validate identity and appropriate roles
- Data protection: avoid logging sensitive fields; TLS enforced; security headers

## Migration
- Phased rollout, dual-read/dual-write where necessary
- Backfill jobs with progress tracking

## Phases
1) Discovery: scan codebase and DB for producers/consumers/SPs and map to streams
2) Contract alignment: compare DTOs vs. wire JSON vs. SP inputs/outputs; fix drift
3) Resilience + Observability: add logging/metrics/timeouts; minimal tracing
4) Performance: quick wins—indexes, pagination, caching toggles
5) Tests: add end-to-end smoke and edge-case tests; document runbook

## Acceptance criteria
- Stream catalog documented with producers/transports/consumers per stream
- Contract docs published and validated with examples
- Healthcheck metrics available for each stream
- Basic load test target met (documented SLOs per stream)

## Debug markers
- [DEBUG-WORKITEM:data-streams:phase:1:discovery]
- [DEBUG-WORKITEM:data-streams:phase:2:contracts]
- [DEBUG-WORKITEM:data-streams:phase:3:resilience-observability]
- [DEBUG-WORKITEM:data-streams:phase:4:performance]
- [DEBUG-WORKITEM:data-streams:phase:5:tests]
