# Consumers

Document consumers of streams and their lifecycle.

- Business services and repositories (Sessions.Business, Sessions.Data)
- Stored procedures in Database/ (SearchEtymology*, Simple_Etymology_*, Ahadees*, etc.)

For each consumer:
- Name, Location
- Inputs/Outputs (shape and types)
- Concurrency and transaction behavior
- Failure modes (DB errors, timeouts) and handling
