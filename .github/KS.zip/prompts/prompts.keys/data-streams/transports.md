# Transports

Select and configure the transport per stream.

- HTTP/JSON: API endpoints with JSON contracts
- Direct DB via Dapper: repository layer to stored procedures/t-sql
- Queue/File (optional): for asynchronous or batch workflows

For each transport:
- Timeouts, retry policy, backoff
- Serialization settings (camelCase, date handling)
- Paging/batching model
