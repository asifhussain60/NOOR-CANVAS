# Observability

- Structured logs with correlationId across SPA→API→DB
- Key metrics per stream: p50/p95 latency, error rate, RPS, timeout rate
- Minimal tracing: spans for API handler and repository calls
- Dashboards: quick SLO overview per stream (doc only here)
