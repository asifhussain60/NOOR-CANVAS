# Execution Flow (KSESSIONS)

Overview
- Plan → Handoff → Execute → Test → Healthcheck → Complete

Steps
1. Plan created by planning agent; comprehensive details saved to `{key}.plan.md`
2. Handoff shows Next options with Continue semantics
3. Execute phases sequentially:
   - Checkpoint commit → implement → test → retry up to 3x on failures
4. Generate and run tests per phase where applicable
5. Run final healthcheck to validate system-wide integrity
6. Produce completion summary with metrics

Controls
- Immediate continue: user says “continue” or “proceed”
- Auto-execute after 5 seconds unless "review" or "cancel"

Quality Gates
- Build: PASS required before advancing
- Tests: PASS required (no failures)
- Lint/analysis: address critical/high issues; log medium/low
