# User Dictionary (KSESSIONS)

Purpose: Normalize shorthand and domain terms used in planning and execution.

Conventions
- Keys: lowercase-with-dashes; preserve ALL-CAPS acronyms

Terms
- KSESSIONS: Project codename for Sessions/Issue Tracker ecosystem
- HCP: Hand-off / Control Protocol (context-specific acronym)
- Continue: Immediate execution control word (aliases: proceed, resume)
- Checkpoint: Commit recorded per phase with `ckpt({key})` format
- Healthcheck: System-wide validation sweep before completion

Custom Expansions (extend as needed)
- ui-refresh-hcp → UI refresh handoff control plan
- prompts-sync → Synchronize portable prompts to KSESSIONS structure
