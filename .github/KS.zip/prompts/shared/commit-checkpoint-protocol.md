# Commit Checkpoint Protocol (KSESSIONS)

Purpose: Guarantee safe, incremental progress with recoverability.

When to commit
- Create a checkpoint commit after EVERY phase
- Create a pre-task checkpoint before making repo-wide changes

Commit format
- Message: `ckpt({key}): Phase {N} - {summary}`
- Example: `ckpt(prompts-sync): Phase 1 - scaffold shared guidance`

Rollback artifacts
- Maintain `.github/prompts.keys/{key}/rollback-index.md`
- Optionally tag checkpoints: `checkpoint/{key}/{timestamp}`

On failure
- Record failure details in `{key}.plan.json` under `interruptedAt`
- Resume using recovery flow (see task.prompt.md Step 0.5.5)

Notes
- Never squash checkpoint commits during active execution
- Keep commit messages meaningful and traceable to phases
