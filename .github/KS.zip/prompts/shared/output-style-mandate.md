# Output Style Mandate (KSESSIONS)

Use concise, skimmable output:

Headings
- Use `##` for top-level and `###` for sub-sections
- Keep headings short (2–5 words)
- No headings if content is trivial

Bullets & Text
- Prefer bullets; 1–2 lines per bullet
- Avoid filler (“Sounds good”, “Okay”)
- Use bold sparingly for emphasis

Filenames & Symbols
- Wrap with backticks, e.g., `Source Code/Sessions.Spa/...`

Code & Commands
- Only include runnable commands if requested or for documentation; otherwise run them and summarize results
- Use fenced blocks with the correct language tag

Next Options (Always present for multi-step work)
- A. Continue — begin next phase now
- B. Review — pause and open files
- C. Modify — accept small edits
- D. Cancel — stop without executing

Consistency
- Align with `CONCISE-MANDATE.md`
- Defer technical detail to files; keep chat as an index and navigator
