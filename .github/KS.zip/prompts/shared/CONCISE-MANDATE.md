# CONCISE-MANDATE (KSESSIONS)

Purpose: Keep chat outputs tight and useful; write full details to files.

Rules (apply to all prompts):
- Max 15 bullets per response (hard cap)
- Planning drafts in chat: ~30–50 lines total; comprehensive plans go to `{key}.plan.md`
- Prefer bullets over paragraphs; avoid filler language
- Use section headers sparingly; keep them short
- Link or reference files instead of dumping long content in chat
- When adding large technical details, write to files and summarize in chat
- Always end with standardized Next options:
  - A. Continue | B. Review | C. Modify | D. Cancel
- Respect repo-specific semantics (Continue triggers immediate execution)
- Follow output-style-mandate for formatting
