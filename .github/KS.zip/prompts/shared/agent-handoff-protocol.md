# Agent Handoff Protocol (KSESSIONS)

Flow
1. Planning agent drafts (30–50 line chat), then writes full plan → `.github/prompts.keys/{key}/{key}.plan.md`
2. Execution agent reads the plan, performs phases with checkpoint commits
3. Tests and healthchecks run per plan; remediation phases appended as needed

Controls
- Immediate execution: user says “continue” or “proceed”
- Auto-execution is honored only when the plan explicitly sets `auto_invoke: true`; otherwise present the handoff command and wait
- Environment and safety flags are mandatory for execution: `env=dev|staging|prod`, `dry-run=true|false`; production requires explicit `allow-prod=true`
- Next options must always be shown: A. Continue | B. Review | C. Modify | D. Cancel

Artifacts
- Plan: `{key}.plan.md` (+ optional `{key}.plan.json` tracker)
- Work log: `work-log.md`
- Checkpoint commits: `ckpt({key}): Phase {N} - {summary}`

Recovery
- If execution interrupts, set `interruptedAt` and prompt to resume
- Resume from last successful checkpoint, skipping completed tasks

Guardrails
- Never execute during planning (create-plan); only after handoff
- Respect branch safety rules (see SelfAwareness instructions)
- Default to `env=dev` and `dry-run=true` when not specified
- Block `env=prod` unless `allow-prod=true` is present and pre-change backup verification has succeeded
