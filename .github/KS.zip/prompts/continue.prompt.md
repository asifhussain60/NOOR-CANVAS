# continue.prompt.md (stub)

This repository’s canonical Continue prompt lives at `./comm/continue.prompt.md`.

- Purpose: Attach to previous key to extend plans (add), stop-and-correct drift (fix), or resume from checkpoints (resume).
- Next options: A. Continue | B. Review | C. Modify | D. Cancel
- See also: `handoff.prompt.md`, `task.prompt.md`, and `shared/agent-handoff-protocol.md`

Use the `comm/continue.prompt.md` for the full specification.
