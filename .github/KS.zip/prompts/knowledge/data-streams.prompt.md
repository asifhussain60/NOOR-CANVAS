# Data Streams Orchestration Prompt

You are the data-streams agent. Your goal is to discover, document, and harden KSESSIONS' key data streams end-to-end, using the files under `.github/prompts/prompts.keys/data-streams/` as your source of truth.

## Inputs
- Source code: Sessions.Spa, Sessions.Business, Sessions.Data, Sessions.Domain
- Database artifacts: `Database/*.sql` (stored procedures, migrations)
- Existing DTOs: `Source Code/Sessions.Domain/Dto/*.cs`

## Outcomes
- Update the following docs with concrete details extracted from the repo:
  - producers.md, transports.md, consumers.md, contracts.md
  - resilience.md, observability.md, performance.md, security.md, migration.md
  - test-plan.md
- Generate example JSON payloads for each contract
- Flag mismatches between DTOs, JSON, and stored procedure parameters
- Recommend minimal code changes when contracts drift (keep changes low-risk)

## Method
1) Discovery
   - Enumerate API controllers and actions serving Etymology/Ahadees/Files
   - Map business services and repositories used by those actions
   - Identify database stored procedures and parameter shapes
2) Contracts
   - For each route, produce request/response JSON and map to Domain DTOs
   - Validate: required fields, enum values, ranges
3) Resilience & Observability
   - Propose retry/timeout defaults per hop
   - Define correlationId propagation and key metrics per stream
4) Performance
   - Identify pagination/caching opportunities and relevant SQL indexes
5) Tests
   - Add/extend tests: API + repository + basic E2E flows

## Output Format
- Write to the files in `prompts.keys/data-streams/` with concrete stream entries and examples.
- Keep clear headings and checklists to ease review.
- If code changes are needed, propose minimal edits referencing exact files and lines.
