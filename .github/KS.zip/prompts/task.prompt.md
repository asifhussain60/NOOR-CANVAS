# task.prompt.md (Execution Agent)

**CRITICAL:** MAX 15 bullets per response (see `.github/prompts/shared/CONCISE-MANDATE.md`)

## Output Format
See `.github/prompts/shared/output-style-mandate.md`

🧠 Analysis (≤5 bullets)
📌 Summary (≤10 bullets)  
📊 Final (always)

## Parameters
See `.github/prompts/shared/task-parameters-reference.md`

### key *(required)*
Task identifier

### debug-level *(default=`none`)*
`none` | `simple` | `trace` | `diagnostic` | `cleanup` | `doc`

### verbosity *(default=`concise`)*
`concise` | `detailed` (NO code in either)

### tasks *(optional)*
Sequential subtasks. `"mark complete"` triggers Step 9.

### github-branch *(default=`development`)*
Target branch per SelfAwareness.instructions.md

### commit-checkpoints *(default=`true`)*
Create git commit after each task completion (MANDATORY)
See: `.github/prompts/shared/commit-checkpoint-protocol.md`

Proceed with task without image analysis? (not recommended for complex visual changes)
```

**Previous behavior (now deprecated):**
Triggered AI-powered screenshot analysis. Comma-delimited image filenames (extensions optional).  
**Modes:** Plain screenshots → HTML documentation, Annotated mockups → Requirement extraction

---

## Purpose & Usage

### What
Canonical execution engine that breaks down requests, validates outcomes, maintains audit trails through progressive key data stream updates, ensures information freshness through git-linked traceability.

### When to Use
- Feature Implementation (UI components, API endpoints, services, database migrations)
- Bug Fixes (across any layer)
- Incremental Work (multi-step tasks with continuous documentation)
- Task Completion (`tasks: mark complete` for comprehensive cross-layer documentation)
- Work Resumption (continue previously completed tasks)
- **Continuous Work** (use "Adding to previous key data stream," to auto-detect and continue recent work)

### How to Invoke

**Via Plan Agent Handoff** (Recommended for complex work):
```
# Step 1: User initiates planning
@workspace /feature key=user-landing user_request="Route users to asset or transcript canvas based on host selection"

# Step 2: Plan agent creates comprehensive plan, user reviews
[Plan agent presents 30-50 line draft]

# Step 3: User approves
User: "proceed"

# Step 4: Plan agent automatically invokes task agent
Plan Agent: @workspace /task key=user-landing github-branch=development tasks="Phase 1: Database Schema\n---\nPhase 2: Backend Persistence\n---\nPhase 3: Frontend Routing\n---\nPhase 4: Testing"

# Task agent loads plan and executes phases
```

**Direct Invocation** (For simple tasks):
```
# Simple single-task execution
@workspace /task key=hcp tasks="Fix hadees token removal in SessionCanvas"

# Multi-phase execution (manual phases)
@workspace /task key=canvas tasks="Add share button\n---\nCreate Playwright test"

# Mark task complete (triggers comprehensive documentation)
@workspace /task key=hcp tasks="mark complete"

# Auto-detect previous key (Step 0.5 Protocol)
@workspace Adding to previous key data stream, fix the submit button styling
```

**Note:** When message starts with "Adding to previous key data stream,", the agent automatically detects the most recently modified key from git history and continues work on that key.

### Expected Outcomes
- ✅ User request recorded in key data stream (succinct summary before work begins)
- ✅ High-priority constraints detected (ALL CAPS emphasis from user request)
- ✅ Incremental documentation (key data stream updated after EVERY sub-task)
- ✅ Git-linked traceability (full SHA commit hashes recorded)
- ✅ Checkpoint tags (every task creates searchable git tag with 28-tag history per key)
- ✅ Automatic test creation (Playwright tests generated for UI changes)
- ✅ Mandatory lint validation (ALL modified files pass syntax checks before commit)
- ✅ High-priority constraint verification (ALL CAPS constraints verified before completion)
- ✅ Clean build (zero errors, zero warnings - mandatory)
- ✅ Comprehensive completion (cross-layer documentation when "mark complete")
- ✅ Concise user output (full details in work-log.md)
- ✅ Iterative approval refinement (up to 3 re-evaluations for evolving requirements)

---

## Core Mandates

### Global Operating Guardrails
**ALWAYS** follow `.github/instructions/SelfAwareness.instructions.md` for all operating guardrails, file organization, runtime rules, and Roslynator integration.

### 🗄️ Database Access Rules (MANDATORY)
**PRIMARY DATABASE:** KSESSIONS_DEV

- When user mentions "database", assume **KSESSIONS_DEV**
- Connection: Always use `_configuration.GetConnectionString("DefaultConnection")`
- **SCHEMA RULES:**
  - ✅ `canvas.*` - READ/WRITE allowed
  - ❌ All other schemas - **READ-ONLY**
- **VIOLATION = IMMEDIATE ROLLBACK**

**See:** `InfrastructureQuickRef.md` for complete database rules

### Architectural Reference Documentation

**Core References** (consult as needed based on task):
- **SystemIndex.md** - Central navigation hub
- **Architecture.md** - Full system design
- **InfrastructureQuickRef.md** ⭐ **MANDATORY for database operations**
- **PlaywrightQuickRef.md** ⭐ **MANDATORY for test creation**
- **ValidationFramework.md** - Standard 6-level validation pipeline

**See:** task.prompt.md attachment for complete list of architectural references

### Workflow Requirements
- Always begin with **checkpoint commit** for rollback safety
- **Always verify key data stream BEFORE planning** (prevent duplicate work)
- **Always update key data stream AFTER execution** (maintain continuity)
- Ensure analyzers, linters, tests remain clean after every operation
- Build must complete with **zero errors and zero warnings**

### Commit and Tagging Conventions (MANDATORY)
Follow `.github/prompts/shared/commit-message-format.md`, extended with standardized types and rollback metadata so recent history is meaningful and rollbacks are easy:

- Types: `ckpt`, `task`, `test`, `hc`, `doc`, `meta`
- Format: `{type}({key}): {summary} [sha={short}] [parent={short}]`
   - Example: `ckpt(user-landing): pre-task checkpoint [sha=abc1234]`
   - Example: `task(user-landing): Phase 2 - API wiring [sha=def5678] [parent=abc1234]`
- Git Tag (for checkpoints only): `key-{key}-ckpt-{yyyyMMdd-HHmm}-{short}`
- Rollback Index: Update `.github/prompts.keys/{key}/rollback-index.md` on every checkpoint and major commit (task/test/hc)

These conventions ensure `git log --oneline -10` is human-scannable and that every commit indicates its rollback lineage.

### UI/UX Execution Requirements (apply when redesign/layout/styling is in scope)
- Preserve existing visual identity (theme, colors, typography) unless explicitly authorized to change
- Apply modern UI principles inspired by Material Design, Fluent UI, or Tailwind spacing/scale best practices
- Ensure responsive behavior at mobile, tablet, and desktop breakpoints; avoid horizontal scroll on mobile for primary content
- Accessibility: implement keyboard navigation, visible focus states, ARIA landmarks/roles, and respect reduced motion preferences
- Usability: optimize button placement, spacing, and content flow; use semantic HTML and clear hierarchy
- Maintainability: align with existing CSS/utilities and component conventions; avoid duplication and regressions in shared styles

---

## Integration with Other Agents

### Called By
- **plan.prompt.md** (Planning Orchestrator) - Receives comprehensive execution plans
  - Plan includes: phased tasks, test specifications, branch strategy, technology stack, architecture layers
  - Handoff format: `key`, `tasks`, `github-branch`, `debug-level`, `verbosity`
  - Task agent executes phases sequentially per plan
  - **See**: [Agent Handoff Protocol](shared/agent-handoff-protocol.md) for complete handoff specification
- **Direct user invocation** - For simple tasks without planning

### Calls (Orchestrates)
- **test-generation.prompt.md** - Automatic test generation for UI changes (Step 6.1)
- **healthcheck.prompt.md** - Post-implementation validation (recommended but manual)

### When to Use
- **Use plan.prompt.md first** if:
  - Complex multi-phase implementation (3+ phases)
  - Need comprehensive test plan
  - Want interactive planning with user approval
  - Requirements unclear or need refinement
  - Significant architecture changes
- **Use task.prompt.md directly** if:
  - Simple, well-defined task (1-2 steps)
  - Already have clear plan
  - Quick fix or minor change
  - Continuing existing work
  - Bug fixes with known solution

---

## Plan Integration Protocol

**See**: [Agent Handoff Protocol](shared/agent-handoff-protocol.md) for complete handoff specification

**WHEN invoked with `key` parameter:**

1. **ALWAYS check for comprehensive plan first**: `.github/prompts.keys/{key}/{key}.plan.md`
2. **If plan exists:**
   - ✅ Load complete phase details from `{key}.plan.md`
   - ✅ Load JSON tracking data from `{key}.plan.json`
   - ✅ Use plan's technology stack analysis (skip redundant discovery)
   - ✅ Reference plan's architecture layers
   - ✅ Follow plan's test specifications
   - ✅ Update plan's JSON tracking after each phase
   - ✅ Apply plan's System Context Pack (APIs, DB, SignalR, test data)
   - ✅ Report phase completion with progress tracking
3. **If plan missing:**
   - ⚠️ Warn user: "No comprehensive plan found. Consider running @workspace /feature first for complex multi-phase work."
   - Use lightweight planning (current Step 3 behavior)
   - Generate simple work plan and proceed
   - Update markdown work-log only (no JSON tracking)

**Plan Context Files** (automatically loaded when plan exists):
- `{key}.plan.md` - Complete plan specification with phases, tests, architecture
- `{key}.plan.json` - JSON tracking for programmatic progress queries
- `work-log.md` - Execution history and key data stream

**Benefits of Plan Integration:**
- ✅ Eliminates redundant analysis (technology stack already discovered)
- ✅ Ensures implementation follows approved architecture
- ✅ Maintains consistency across phases
- ✅ JSON tracking enables programmatic progress queries
- ✅ Reuses pre-gathered context (APIs, DB schemas, test data)
- ✅ Clear phase boundaries with validation gates
- ✅ Better user experience with plan approval workflow

**Example: Plan Handoff Flow**
```
User: @workspace /feature key=user-landing user_request="Route users based on host selection"
[Plan agent creates plan, user approves]
Plan Agent: @workspace /task key=user-landing github-branch=development tasks="Phase 1: ...\n---\nPhase 2: ..."
Task Agent: ✅ Loaded comprehensive plan from .github/prompts.keys/user-landing/user-landing.plan.md
Task Agent: [Executes phases sequentially]
```

---

## Execution Steps

**See:** `shared/execution-flow.md` for complete visual flow diagram

### Step 0: Branch Verification (MANDATORY)

⚠️ **ALWAYS verify you're in the correct branch before starting any work.**

**Branch Strategy:**
- **`master`** - Production only (PROTECTED - deploy target)
- **`development`** - ALL development work (DEFAULT)

**Verification Process:**

1. **Check current git branch:**
   ```bash
   git branch --show-current
   # Expected: development (or github-branch parameter value)
   ```

2. **Validate against github-branch parameter:**
   - **If `github-branch` parameter provided:** Verify current branch matches parameter
   - **If `github-branch` NOT provided:** Default to `development`, verify current branch is `development`

3. **Branch Mismatch Handling:**
   - **Current branch = `master` AND github-branch = `development` (or not specified):**
     ```
     ⚠️ CRITICAL: Cannot execute on master branch
     
     Current branch: master
     Required branch: development (per github-branch parameter)
     
     Per SelfAwareness.instructions.md, ALL development work occurs in 'development' branch.
     
     ACTION REQUIRED: Switch to development branch
     Command: git checkout development
     
     ❌ ABORTING task execution
     ```
     **EXIT with error - do NOT proceed**
   
   - **Current branch ≠ github-branch parameter:**
     ```
     ⚠️ WARNING: Branch mismatch detected
     
     Current branch: {current-branch}
     Expected branch: {github-branch} (from parameter)
     
     Would you like to:
     1. Switch to {github-branch} branch (recommended)
     2. Proceed on {current-branch} anyway (override)
     
     Respond with "1" or "2"
     ```
     - If user chooses "1" → Switch branch: `git checkout {github-branch}`
     - If user chooses "2" → Warn and document override in work log

4. **Branch Validation Success:**
   ```
   ✓ Branch verified: {current-branch}
   (Matches github-branch parameter: {github-branch})
   ```

**Enforcement:**
- ⚠️ **ABORT** task execution if on `master` branch (unless github-branch explicitly set to `master`)
- ✅ **PROCEED** if current branch matches github-branch parameter
- ⚠️ **PROMPT** user if mismatch detected (allow override with warning)

**See:** `SelfAwareness.instructions.md` - Branch Strategy section

---

### Step 0.5: Previous Key Data Stream Continuation Protocol (CONDITIONAL)

**Trigger Phrase:** User message starts with `"Adding to previous key data stream,"`

**Purpose:** Seamlessly continue work on the most recently modified key without requiring explicit key parameter.

**Detection & Resolution:**
1. **Scan recent git commits** for key data stream modifications:
   ```bash
   git log --pretty=format:"%H %s" --name-only -10 | grep "prompts.keys"
   ```
2. **Identify most recent key:**
   - Parse file path: `.github/prompts.keys/**/{key}.md`
   - Extract `{key}` from path
   - Verify last modification timestamp
3. **Auto-populate key parameter:**
   - Set `key = {detected-key}`
   - Inform user: `"📌 Continuing work on key: {detected-key} (last modified: {timestamp})"`

**Validation:**
- If NO recent key modifications found → Request explicit key from user
- If MULTIPLE keys modified in last commit → Use most recent timestamp
- If ambiguous → Present options to user for selection

**Handover to Task Protocol:**
- Once key is resolved, proceed to **Step 1: Checkpoint Commit**
- Continue normal task workflow (Steps 1-9)
- Update the SAME key data stream that was auto-detected

**Example Flow:**
```
User: "Adding to previous key data stream, fix the button alignment issue"

Agent Actions:
1. Scan git log → Finds `.github/prompts.keys/canvas/canvas.md` modified 2 minutes ago
2. Extract key: "canvas"
3. Notify: "📌 Continuing work on key: canvas (last modified: 2025-10-15T00:02:00Z)"
4. Proceed to Step 1 with key="canvas"
```

**Guardrails:**
- **ALWAYS verify detected key with user before proceeding** (brief confirmation)
- **NEVER assume key if git history is ambiguous** (request clarification)
- **ALWAYS preserve previous work** (append to existing work log, never overwrite)

---

### Step 0.5.5: Recovery Detection (CONDITIONAL)

**Trigger:** ALWAYS when `key` parameter is resolved (Step 0.5 or Step 2.1)

**Purpose:** Detect interrupted workflows and offer seamless recovery from last checkpoint

**Detection:**
1. **Load plan.json**: `.github/prompts.keys/{key}/{key}.plan.json`
2. **Check for interruptedAt field**:
   ```json
   "interruptedAt": {
     "phase": 4,
     "step": "4.2",
     "timestamp": "2025-10-20T15:30:00Z",
     "reason": "build-failure",
     "errorMessage": "CS0103: The name 'foo' does not exist",
     "lastSuccessfulPhase": 3
   }
   ```
3. **If interruptedAt exists** → Present recovery option:
   ```
   🔄 INTERRUPTED WORKFLOW DETECTED
   
   Key: {key}
   Last Successful Phase: Phase {lastSuccessfulPhase}
   Interrupted At: Phase {phase}, Step {step}
   Reason: {reason}
   Timestamp: {timestamp}
   
   Error: {errorMessage}
   
   Would you like to resume from Phase {phase}? (yes/no)
   ```

4. **User Response:**
   - **"yes"** / **"resume"** / **"continue"** → Proceed to recovery workflow
   - **"no"** / **"start over"** → Clear interruptedAt, proceed normally
   - **No response** → Assume "yes" after 5 seconds

**Recovery Workflow:**
1. **Load checkpoint tag**: `checkpoint/{key}/{timestamp}`
   ```bash
   git tag -l "checkpoint/{key}/*" | tail -1
   ```
2. **Verify checkpoint exists** (last successful phase should have tag)
3. **Resume from interrupted phase**:
   - Set `current_phase = interruptedAt.phase`
   - Load phase tasks from plan.md
   - Skip completed tasks (check plan.json task.completed flags)
   - Execute remaining tasks
4. **Clear interruptedAt on phase completion**:
   ```json
   "interruptedAt": null
   ```

**User Commands (Alternative Triggers):**
- **"continue"** → Auto-detect most recent interrupted key, resume
- **"resume {key}"** → Resume specific key's interrupted workflow
- **"continue from phase {N}"** → Resume from specific phase (override interruptedAt.phase)

**Validation:**
- If NO plan.json found → Skip recovery (no workflow to resume)
- If NO interruptedAt field → Skip recovery (no interruption detected)
- If checkpoint tag missing → Warn user, offer fresh start from interrupted phase

**Output:**
```
✅ Resuming from Phase {phase}: {title}

Last Checkpoint: Phase {lastSuccessfulPhase} ({checkpoint-tag})
Skipping completed tasks: {completed-task-count}/{total-task-count}

Executing remaining tasks...
```

---

### Step 0.25: Key Folder Existence Validation (MANDATORY)

**Trigger:** ALWAYS when `key` parameter is provided or auto-detected

**Purpose:** Verify key data stream infrastructure exists before proceeding

**Validation:**

1. **Check if key folder exists**: `.github/prompts.keys/{key}/`
   - If NOT exists → HALT immediately
   - Error message to user:
     ```
     ❌ ERROR: Key folder does not exist
     
     Key: {key}
     Expected path: .github/prompts.keys/{key}/
     
     This key has not been initialized through the planning process.
     
     REQUIRED ACTION:
     Run the planning agent first to create the key infrastructure:
     
     @workspace /feature key={key} user_request="{your requirements}"
     
     The planning agent will:
     - Create the key folder structure
     - Generate comprehensive plan document
     - Set up test directory and registry
     - Prepare handoff for task execution
     
     After planning completes, you can run this task command.
     ```
   - **EXIT with status code 1** (prevents downstream failures)

2. **Check if plan exists**: `.github/prompts.keys/{key}/{key}.plan.md`
   - If exists → Use comprehensive plan (existing Step 3 Plan Integration Protocol)
   - If NOT exists → Warn user but continue with lightweight planning:
     ```
     ⚠️ WARNING: No comprehensive plan found
     
     Key folder exists but no {key}.plan.md detected.
     Using lightweight planning mode for simple tasks.
     
     For complex multi-phase work, consider running:
     @workspace /feature key={key} user_request="{requirements}"
     ```

**Output:**
- **Concise:** `"✓ Key folder validated: {key}"`
- **Detailed:** 
  ```
  ✓ Key Folder Validation
  
  Key: {key}
  Path: .github/prompts.keys/{key}/
  Status: EXISTS
  Plan: {FOUND | NOT FOUND}
  Mode: {Comprehensive | Lightweight}
  ```

---

### Step 1: Checkpoint Commit (MANDATORY)

Create checkpoint commit for rollback capability:
```bash
git add -A
git commit -m "ckpt({key}): pre-task checkpoint"
set "_SHA=" & for /f %i in ('git rev-parse --short HEAD') do set _SHA=%i

# Create/update rollback index for this key
if not exist .github\prompts.keys\{key} mkdir .github\prompts.keys\{key}
"" >nul 2>&1
echo | set /p="# Rollback Index for {key}\r\n" > .github\prompts.keys\{key}\rollback-index.md
if not exist .github\prompts.keys\{key}\rollback-index.md (
   echo # Rollback Index for {key}> .github\prompts.keys\{key}\rollback-index.md
   echo >> .github\prompts.keys\{key}\rollback-index.md
   echo | set /p="| Date | Type | Summary | SHA | Parent |\r\n" >> .github\prompts.keys\{key}\rollback-index.md
   echo | set /p="|------|------|---------|-----|--------|\r\n" >> .github\prompts.keys\{key}\rollback-index.md
)

# Append current checkpoint row
powershell -NoProfile -Command "$d=Get-Date -Format 'yyyy-MM-dd HH:mm:ss'; $sha=(git rev-parse --short HEAD); Add-Content '.github/prompts.keys/{key}/rollback-index.md' \"| $d | ckpt | pre-task checkpoint | $sha | - |\""

# Tag the checkpoint for easy discovery
powershell -NoProfile -Command "$sha=(git rev-parse --short HEAD); $t=Get-Date -Format 'yyyyMMdd-HHmm'; git tag \"key-{key}-ckpt-$t-$sha\""
```

This ensures rollback capability if the task introduces instability.

---

### Step 2: Context Gathering (MANDATORY - Multi-Phase)

**Purpose:** Build comprehensive context before planning through conditional, intelligent sub-phases.

**See:**
- `.github/prompts/shared/context-gathering-phases.md` for the complete decision tree, all 10 sub-phases, skip conditions, and performance optimizations
- `.github/prompts/shared/framework-validation-checklists.md` for Step 2.5 Framework Validation quick checks (ASP.NET, Blazor, SignalR, Playwright, SQL)
- `.github/prompts/shared/ui-debugging-protocol.md` for Step 2.7 UI Debugging evidence-gathering flow (selectors, logs, screenshots, Percy)

**CRITICAL GUARDRAILS:**
1. **Token Budget Protection:** If Step 2 context gathering exceeds 50,000 tokens → HALT and request user approval before proceeding (prevents context overflow)
2. **Circular Dependency Detection:** If Step 2.8 detects circular dependencies in architecture → HALT and request resolution strategy from user (prevents infinite recursion)
3. **Phase Timeout Protection:** If Step 2 total execution exceeds 5 minutes → Emit warning, proceed with gathered context (prevents infinite analysis loops)

**Key Sub-Phases Overview:**

**Always Execute:**
- **2.1:** Key Resolution (infer from history, use provided parameter, or auto-detected from Step 0.5)
  - **2.1.5:** High-Priority Constraint Detection (scan for ALL CAPS emphasis in user request)
- **2.2:** Key Data Stream Query (read existing work, prevent duplication)
  - **2.2.1:** Record User Request (succinct summary before work begins)
- **2.3:** Auto-Load File Mappings (load referenced files into context)

**Conditional Execution (based on task type):**
- **2.4:** Error Triage → Classify error type, route to appropriate investigation
   - **2.5:** Framework Validation (if framework error detected) — See `shared/framework-validation-checklists.md`
  - **2.6:** Known Pattern Matching (instant solution from error library)
   - **2.7:** UI Debugging Protocol (automated evidence gathering for UI bugs) — See `shared/ui-debugging-protocol.md`
- **2.8:** Architecture Analysis (prevent duplication, ensure compliance)
  - **2.8.7:** Data Lifecycle Validation (CRUD: verify UI → API → DB → Broadcast → UI)
- **2.9:** QuickRef Localization (cache InfrastructureQuickRef, PlaywrightQuickRef - first use only)
- **2.10:** View Documentation - **DEPRECATED** (image analysis moved to plan.prompt.md Step 0.6)
- **2.11:** Refactoring Opportunity Detection (conditional - runs when modifying existing code)
- **2.12:** Load System Context Pack (if {key}.plan.md exists - load pre-gathered context)

**Note on Step 2.10 Deprecation:**
Image analysis has been moved to plan.prompt.md Step 0.6 for proper requirement gathering during planning phase. If user provides `annotate` parameter or images during task execution, warn that image analysis should be done in planning phase and suggest running `@workspace /feature` first.

**Routing Logic:**
- Error reported → 2.4 triages → Routes to 2.5, 2.6, 2.7, or 2.8
- HIGH confidence pattern match (2.6) → Skip 2.8, proceed to planning
- CRUD operation → 2.8.7 validates complete data lifecycle
- Incomplete lifecycle → Early warning in Step 4 approval

**Output (controlled by verbosity):**
- **Concise:** Phase names, routing decisions, key findings only
- **Detailed:** Complete context dump, analysis results, confidence scores

---

#### Step 2.12: Load System Context Pack (from plan)

**Trigger:** When `.github/prompts.keys/{key}/{key}.plan.md` exists

**Purpose:** Load pre-gathered execution context to skip redundant analysis

**Actions:**
1. **Read plan document** at `.github/prompts.keys/{key}/{key}.plan.md`
2. **Extract System Context Pack section** (if present)
3. **Cache the following for immediate use:**
   - **API Endpoints**: Paths, methods, request/response contracts, authentication
   - **Database Schemas**: Tables, columns, relations, migration details
   - **SignalR Hubs**: Hub names, event names, payload structures
   - **Test Data**: Session 212 defaults, tokens (Host/User), canonical URLs
   - **Configuration**: Environment variables, ports, feature flags
   - **Canonical References**: Links to InfrastructureQuickRef, PlaywrightQuickRef

**Benefits:**
- ✅ Skip API endpoint discovery (already documented in plan)
- ✅ Skip database schema exploration (already validated in plan)
- ✅ Use pre-validated test data (consistency across phases)
- ✅ Faster execution (no redundant context gathering)
- ✅ Technology-aware implementation (framework/version compatibility validated by plan)

**Output:**
```
📦 Loaded System Context Pack from plan

- APIs: 3 endpoints cached
- Database: 2 tables (canvas.Sessions, canvas.Participants)
- SignalR: SessionHub (3 events)
- Test Data: Session 212 (Host: PQ9N5YWW, User: KJAHA99L)
- Technology: ASP.NET Core 8.0 (Blazor Server)

✅ Ready to execute with pre-validated context
```

---

### Step 3: Plan

**Execution Context Detection:**

**A. Phase-Driven Planning** (when `.github/prompts.keys/{key}/{key}.plan.md` exists):
1. Load comprehensive plan document
2. Load JSON tracking from `.github/prompts.keys/{key}/{key}.plan.json`
3. Parse `tasks` parameter for phase identifiers:
   - Pattern: `Phase 1: {title}\n---\nPhase 2: {title}\n---\nPhase 3: {title}`
   - Extract phase numbers and titles
4. For each phase, load from plan document:
   - **Objectives**: Phase goals (numbered list)
   - **Context**: Files to analyze, previous phase dependencies
   - **Implementation Tasks**: TODO items with expected outcomes
   - **Validation Checklist**: Build, lint, tests
   - **Playwright Test Specification**: Test scenarios, mode, Percy requirements
   - **Orchestration Script Specification**: PowerShell template
   - **Debug Markers**: Specific markers for this phase
   - **Commit Format**: Template with debug markers
   - **Approval Gate**: User must approve before next phase
5. Skip lightweight planning (plan already exists)
6. Proceed directly to Step 4 (Approval) with loaded phase details

**B. Lightweight Planning** (no plan exists):
1. Use verified/inferred key from Step 2
2. Incorporate architecture analysis from Step 2.8
3. **MANDATORY for CRUD:** Verify complete data lifecycle documented in Step 2.8.7
4. **HIGH-PRIORITY Constraints:** Include dedicated section for ALL CAPS constraints from Step 2.1.5
5. Parse `debug-level`, `verbosity`, `tasks`
6. **Detect completion keywords:** If `tasks` contains "mark complete", prepare Step 9
7. **Detect documentation mode:** If `debug-level: doc`, prepare documentation instead of code execution
8. Incorporate context from Step 2
9. Generate simple work plan

**Plan Structure (Lightweight Mode)**:
```markdown
## Implementation Plan

### Primary Objective
{main task description}

### HIGH-PRIORITY Constraints (from user ALL CAPS emphasis)
1. [CONSTRAINT] {constraint description}
   - **Category**: {Preservation|Exactness|Mandatory Inclusion|Behavioral}
   - **Verification Method**: {how to verify}
   - **Status**: PENDING → VERIFIED → FAILED

### Subtasks
1. {subtask 1}
2. {subtask 2}

### Verification Checklist
- [ ] Build passes (zero errors, zero warnings)
- [ ] Lint validation passes (all file types)
- [ ] High-priority constraints verified
- [ ] Tests pass (if applicable)
```

---

### Step 3.5: Commit Message Planning and Parent Linkage (MANDATORY)

Before implementation commits, prepare the commit subject to include rollback metadata and lineage:

- Determine `parent` = latest checkpoint short SHA (from `rollback-index.md` last ckpt row)
- Use format per conventions: `{type}({key}): {summary} [sha={short}] [parent={short}]`
- Types: `task` for implementation; `test` for generated tests; `hc` for healthcheck-driven doc updates

This guarantees that later “show last 10 commits” queries present a clean, meaningful list with easy rollback anchors.

**Output (based on verbosity):**
- **Concise:** 3-5 line summary, subtask list, constraint count, approach
- **Detailed:** Complete analysis, file-by-file breakdown, test strategy, constraint verification plan, risks

---

### Step 4: Approval (MANDATORY)

**Purpose:** Iterative approval gate with re-evaluation support for additional requirements.

**Workflow:**

1. **Present Generated Plan** to user for confirmation (controlled by `verbosity` parameter)

2. **Parse User Response:**
   - **Explicit Approval** (proceed to Step 5):
     - Patterns: `"yes"`, `"y"`, `"proceed"`, `"go ahead"`, `"continue"`, `"approved"`, `"ok"` (case-insensitive)
     - **CRITICAL:** Response must contain ONLY approval keywords, no additional requests
     - Example: `"Yes"`, `"proceed"`, `"Y"`, `"ok"`
   
   - **Additional Requirements** (loop back to Step 3):
     - Any response containing new instructions, modifications, or clarifications
     - Examples: `"Also add X"`, `"Change Y to Z"`, `"What about A?"`, `"Make the button blue"`
     - Agent appends requirements to context and re-plans
   
   - **Rejection** (halt execution):
     - Patterns: `"no"`, `"cancel"`, `"stop"`, `"halt"`
     - Mark task as **Pending Approval** and exit

3. **Re-Evaluation Loop** (if additional requirements detected):
   - **Iteration {N}/3:** Append user's additional requirements to Step 2 context
   - Return to **Step 3:** Re-plan with updated requirements
   - Present updated plan with change summary:
     ```
     📝 Updated Implementation Plan (Iteration {N}/3)
     
     Additional Requirements Added:
     - {requirement 1}
     - {requirement 2}
     
     Updated Plan:
     {new plan with changes highlighted}
     
     Proceed with updated plan? (yes/proceed to continue, or provide more requirements)
     ```
   - **Iteration Limit:** After 3 re-evaluations, require explicit `"proceed"` or `"cancel"`
   - **Loop Termination:** Only proceed to Step 5 on explicit approval without new requirements

4. **⚠️ Early Warning:** If Step 2.8.7 detected INCOMPLETE data lifecycle:
   ```
   ⚠️ WARNING: Incomplete Data Lifecycle Detected
   
   Current implementation missing:
   - [X] Database Persistence (mutations not saved)
   - [X] SignalR Broadcast (other clients won't see changes)
   
   This will result in:
   - ❌ Changes disappear after page refresh
   - ❌ Multi-user desync (only one browser updated)
   
   Recommendation:
   1. Add API endpoint: POST /api/questions/{id}/delete
   2. Add database mutation: DbContext.Questions.Remove()
   3. Add SignalR broadcast: Clients.All.SendAsync("QuestionDeleted")
   
   Proceed with incomplete implementation? (Not recommended)
   ```

5. **Halt Conditions:**
   - User provides rejection response
   - Maximum iterations (3) reached without approval
   - Explicit "Pending Approval" request

**Output (controlled by verbosity):**
- **Concise:** Plan summary, iteration count (if re-evaluation occurred), approval request
- **Detailed:** Full plan, change history across iterations, architectural impact analysis

---

**Examples:**

**Scenario 1: Immediate Approval**
```
Agent: {presents plan}
       
       Proceed with this plan?

User: "Yes, proceed"

Agent: ✅ Approved. Proceeding to Step 5 (Execute)
```

**Scenario 2: Additional Requirements (Single Iteration)**
```
Agent: {presents initial plan}
       
       Proceed with this plan?

User: "Also add a confirmation dialog before deletion"

Agent: 📝 Updated Implementation Plan (Iteration 1/3)
       
       Additional Requirements Added:
       - Add confirmation dialog before deletion
       
       Updated Plan:
       1. Add ConfirmDialog component to SessionCanvas.razor
       2. Wire up deletion flow with confirmation step
       3. Add confirmation state management
       ...
       
       Proceed with updated plan?

User: "Yes"

Agent: ✅ Approved after 1 iteration. Proceeding to Step 5 (Execute)
```

**Scenario 3: Multiple Iterations**
```
Agent: {presents initial plan}

User: "Change button color to blue"

Agent: 📝 Updated Implementation Plan (Iteration 1/3)
       {updated plan with blue button}
       Proceed with updated plan?

User: "Also add a tooltip on hover"

Agent: 📝 Updated Implementation Plan (Iteration 2/3)
       {updated plan with blue button + tooltip}
       Proceed with updated plan?

User: "proceed"

Agent: ✅ Approved after 2 iterations. Proceeding to Step 5 (Execute)
```

**Scenario 4: Max Iterations Reached**
```
Agent: {presents plan after 3rd iteration}
       
       ⚠️ Maximum re-evaluations reached (3/3).
       
       Please respond with:
       - "proceed" to implement current plan
       - "cancel" to halt execution
       - OR start a new /task invocation with refined requirements

User: "proceed"

Agent: ✅ Approved after 3 iterations. Proceeding to Step 5 (Execute)
```

---

### Step 5: Execute

**Determine execution mode based on `debug-level` parameter and plan existence.**

#### 5a. Documentation Mode (`debug-level: doc`)
**Actions:**
1. Skip code execution - no file modifications
2. Generate implementation documentation in key data stream
3. Document validation checklist for manual implementation
4. Output location: `.github/prompts.keys/{key}/implementation-plan.md`
5. Skip to Step 8 (bypass Steps 6-7)

#### 5b. Phase-Driven Execution (when {key}.plan.md exists)
**Actions:**
1. **For each phase in tasks parameter:**
   - Load full phase details from `.github/prompts.keys/{key}/{key}.plan.md`
   - Execute TODO items from "Implementation Tasks" section
   - Follow "Validation Checklist" from plan (build, lint, tests)
   - Use "Debug Markers" from plan
   - Apply "Commit Format" template from plan
   - Update JSON tracking after phase completion (see Step 8.1)
   - Wait for user approval before next phase (per "Approval Gate")
2. **Phase completion:** Present summary and request approval for next phase
3. **Phase failure:** Halt execution, rollback available via checkpoint tag

#### 5c. Lightweight Execution (no plan exists)
**Actions:**
1. Execute subtasks in sequence
2. Halt immediately on failure (unless override)
3. Insert debug logging based on `debug-level` parameter
4. Apply architecture analysis findings (reuse patterns, avoid duplication)

---

#### 5d. Production Migration Generation (Database Changes Detected)

**Trigger:** When phase involves database schema changes (detected in Step 2.8 or from {key}.plan.md "Production Migration Specification")

**Purpose:** Auto-generate forward migration + rollback scripts for safe production deployment

**Detection Signals:**
- ✅ ALTER TABLE, CREATE TABLE, DROP TABLE, CREATE INDEX, DROP INDEX
- ✅ ADD CONSTRAINT, DROP CONSTRAINT (foreign keys, defaults, checks)
- ✅ Schema modifications to canvas.* tables
- ✅ Data migrations (UPDATE, INSERT for schema initialization)
- ✅ Phase plan contains "Production Migration Specification" section

**MANDATORY: Skip if Development-Only Changes**
- ❌ Changes to KSESSIONS_DEV specific data (test sessions, participants)
- ❌ Temporary test data (will be cleared)
- ❌ Code-only changes with no database impact

---

**Generation Protocol:**

**Step 1: Extract Migration Details from Plan**

If {key}.plan.md contains "Production Migration Specification" for current phase:
```markdown
### Production Migration Specification

**Migration Required**: YES
**Database Changes**:
- ALTER TABLE [canvas].[Sessions] ADD [CanvasType] NVARCHAR(20) NULL DEFAULT 'asset'
- CREATE INDEX IX_Sessions_CanvasType ON [canvas].[Sessions] ([CanvasType])

**Migration Script**: Scripts/Migrations/Prod/pending/migration-{timestamp}-{key}-add-canvastype-column.sql
**Rollback**: Scripts/Migrations/Prod/rollback/rollback-{timestamp}-{key}-add-canvastype-column.sql
```

Extract:
- Database changes (SQL statements)
- Migration description (from filename guidance)
- Safety checks (if specified)
- Rollback strategy (reverse operations)

**Step 2: Generate Migration ID**

Format: `{YYYYMMDD-HHMMSS}` (e.g., `20251020-143000`)

```powershell
# PowerShell command to generate timestamp:
Get-Date -Format "yyyyMMdd-HHmmss"
```

**Step 3: Create Forward Migration Script**

Location: `Scripts/Migrations/Prod/pending/migration-{YYYYMMDD-HHMMSS}-{key}-{description}.sql`

Template:
```sql
-- ============================================================================
-- Production Migration Script
-- ============================================================================
-- Migration ID: {YYYYMMDD-HHMMSS}
-- Key: {key}
-- Description: {description}
-- Created: {ISO-8601-timestamp}
-- Author: GitHub Copilot (Agent: task)
-- Database: KSESSIONS (Production)
-- Schema: canvas
-- ============================================================================

-- SAFETY CHECKS
IF DB_NAME() != 'KSESSIONS'
BEGIN
    RAISERROR('ERROR: This migration must run against KSESSIONS database only!', 16, 1)
    RETURN
END
GO

-- Check if already applied
IF EXISTS (SELECT 1 FROM canvas.MigrationHistory WHERE MigrationId = '{YYYYMMDD-HHMMSS}')
BEGIN
    PRINT 'Migration {YYYYMMDD-HHMMSS} already applied - skipping'
    RETURN
END
GO

-- MIGRATION LOGIC
BEGIN TRANSACTION MigrationTrans;

BEGIN TRY
    PRINT 'Starting migration: {description}'
    
    -- {Database changes here - use IF NOT EXISTS checks for idempotency}
    -- Example:
    IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('canvas.Sessions') AND name = 'CanvasType')
    BEGIN
        ALTER TABLE [canvas].[Sessions] ADD [CanvasType] NVARCHAR(20) NULL DEFAULT 'asset';
        PRINT '  ✅ Added CanvasType column'
    END
    
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Sessions_CanvasType')
    BEGIN
        CREATE INDEX IX_Sessions_CanvasType ON [canvas].[Sessions] ([CanvasType]);
        PRINT '  ✅ Created index IX_Sessions_CanvasType'
    END
    
    -- Record in history
    INSERT INTO canvas.MigrationHistory (MigrationId, Description, AppliedAt, AppliedBy)
    VALUES ('{YYYYMMDD-HHMMSS}', '{description}', GETUTCDATE(), SYSTEM_USER);
    
    COMMIT TRANSACTION MigrationTrans;
    PRINT '✅ Migration {YYYYMMDD-HHMMSS} completed successfully'
    
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION MigrationTrans;
    DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
    PRINT '❌ Migration failed: ' + @ErrorMessage
    RAISERROR(@ErrorMessage, 16, 1);
END CATCH
GO
```

**Step 4: Create Rollback Script**

Location: `Scripts/Migrations/Prod/rollback/rollback-{YYYYMMDD-HHMMSS}-{key}-{description}.sql`

Template:
```sql
-- ============================================================================
-- Production Migration Rollback Script
-- ============================================================================
-- Migration ID: {YYYYMMDD-HHMMSS}
-- Key: {key}
-- Description: Rollback {description}
-- Created: {ISO-8601-timestamp}
-- Author: GitHub Copilot (Agent: task)
-- Database: KSESSIONS (Production)
-- Schema: canvas
-- ============================================================================

-- SAFETY CHECKS
IF DB_NAME() != 'KSESSIONS'
BEGIN
    RAISERROR('ERROR: This rollback must run against KSESSIONS database only!', 16, 1)
    RETURN
END
GO

-- ROLLBACK LOGIC
BEGIN TRANSACTION RollbackTrans;

BEGIN TRY
    PRINT 'Starting rollback: {description}'
    
    -- {Reverse database changes - use IF EXISTS checks for idempotency}
    -- Example (reverse order of forward migration):
    IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_Sessions_CanvasType')
    BEGIN
        DROP INDEX IX_Sessions_CanvasType ON [canvas].[Sessions];
        PRINT '  ✅ Dropped index IX_Sessions_CanvasType'
    END
    
    IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('canvas.Sessions') AND name = 'CanvasType')
    BEGIN
        ALTER TABLE [canvas].[Sessions] DROP COLUMN [CanvasType];
        PRINT '  ✅ Dropped CanvasType column'
    END
    
    -- Update history
    UPDATE canvas.MigrationHistory
    SET RolledBackAt = GETUTCDATE(), RolledBackBy = SYSTEM_USER
    WHERE MigrationId = '{YYYYMMDD-HHMMSS}';
    
    COMMIT TRANSACTION RollbackTrans;
    PRINT '✅ Rollback {YYYYMMDD-HHMMSS} completed successfully'
    
END TRY
BEGIN CATCH
    ROLLBACK TRANSACTION RollbackTrans;
    DECLARE @ErrorMessage NVARCHAR(4000) = ERROR_MESSAGE();
    PRINT '❌ Rollback failed: ' + @ErrorMessage
    RAISERROR(@ErrorMessage, 16, 1);
END CATCH
GO
```

**Step 5: Document Migration in Work Log**

Add to `.github/prompts.keys/{key}/work-log.md`:

```markdown
### Migration Generated

**Migration ID**: {YYYYMMDD-HHMMSS}
**Files Created**:
- `Scripts/Migrations/Prod/pending/migration-{YYYYMMDD-HHMMSS}-{key}-{description}.sql`
- `Scripts/Migrations/Prod/rollback/rollback-{YYYYMMDD-HHMMSS}-{key}-{description}.sql`

**Database Changes**:
- {list of SQL statements}

**Deployment**: Will be executed automatically by ncdeploy.ps1 Step 3
**Rollback**: Available at Scripts/Migrations/Prod/rollback/rollback-{timestamp}...sql

**Validation**: 
- ✅ Syntax validated (idempotent checks present)
- ✅ Safety checks included (DB_NAME validation)
- ✅ Transaction wrapped (auto-rollback on error)
- ✅ MigrationHistory tracking included
```

**Step 6: Commit Migration Scripts**

```bash
git add Scripts/Migrations/Prod/pending/migration-*.sql
git add Scripts/Migrations/Prod/rollback/rollback-*.sql
git commit -m "migration({key}): {description}

Migration ID: {YYYYMMDD-HHMMSS}
Database: KSESSIONS (Production)
Schema: canvas

Forward: Scripts/Migrations/Prod/pending/migration-{timestamp}-{key}-{description}.sql
Rollback: Scripts/Migrations/Prod/rollback/rollback-{timestamp}-{key}-{description}.sql

Changes:
- {list of database changes}

Deployment: Automatic via ncdeploy.ps1 Step 3
See: Scripts/Migrations/Prod/README.md for workflow"
```

---

**Output to User:**

**Concise Mode:**
```
✅ Generated production migration
   Migration ID: 20251020-143000
   Files: Scripts/Migrations/Prod/pending/migration-20251020-143000-user-landing-add-canvastype-column.sql
          Scripts/Migrations/Prod/rollback/rollback-20251020-143000-user-landing-add-canvastype-column.sql
```

**Detailed Mode:**
```
### Production Migration Generated

**Migration ID**: 20251020-143000

**Database Changes**:
- ALTER TABLE [canvas].[Sessions] ADD [CanvasType] NVARCHAR(20) NULL DEFAULT 'asset'
- CREATE INDEX IX_Sessions_CanvasType ON [canvas].[Sessions] ([CanvasType])

**Files Created**:
1. Forward Migration:
   `Scripts/Migrations/Prod/pending/migration-20251020-143000-user-landing-add-canvastype-column.sql`
   
   - ✅ Safety checks: DB_NAME() = KSESSIONS validation
   - ✅ Idempotent: IF NOT EXISTS checks for column/index
   - ✅ Transaction wrapped: Auto-rollback on error
   - ✅ MigrationHistory tracking

2. Rollback Script:
   `Scripts/Migrations/Prod/rollback/rollback-20251020-143000-user-landing-add-canvastype-column.sql`
   
   - ✅ Reverse operations: DROP INDEX → DROP COLUMN
   - ✅ Idempotent: IF EXISTS checks
   - ✅ MigrationHistory update (RolledBackAt timestamp)

**Deployment**:
- Executed automatically by ncdeploy.ps1 Step 3 (before code deployment)
- Validated in dry-run mode: `.\Scripts\ncdeploy.ps1 -DryRun`
- Archived to `archived/{YYYY-MM-DD}/` after successful deployment

**Rollback**:
- Auto-executed if migration fails during ncdeploy.ps1
- Manual execution: `sqlcmd -S localhost -d KSESSIONS -i rollback-{timestamp}...sql`

**See**: Scripts/Migrations/Prod/README.md for complete workflow
```

---

**Critical Rules:**

1. **ALWAYS generate both forward + rollback scripts** (no exceptions)
2. **ALWAYS use idempotent checks** (IF NOT EXISTS / IF EXISTS)
3. **ALWAYS validate database name** (DB_NAME() = 'KSESSIONS')
4. **ALWAYS wrap in transactions** (BEGIN TRANSACTION ... COMMIT/ROLLBACK)
5. **ALWAYS track in MigrationHistory** (INSERT on forward, UPDATE on rollback)
6. **NEVER skip rollback script** (even for simple changes like adding column)
7. **NEVER use hardcoded values** (use DEFAULT constraints for nullable columns)

**See Also:**
- `Scripts/Migrations/Prod/README.md` - Complete migration workflow
- `Scripts/Migrations/Prod/init-migration-history.sql` - MigrationHistory table schema
- `.github/prompts/plan.prompt.md` - Database Migration Protocol (detection rules)

---

**Validation Gate (MANDATORY after every code change):**
1. **Build Validation:** Run `dotnet build`, verify zero errors/warnings
2. **Evidence Re-Collection:** For UI bugs, re-run diagnostics to verify fix
3. **Incremental Progress Check:** User confirms issue improved/resolved
4. **Halt on Failure:** If same issue persists after 2 attempts, escalate
5. **Auto-Escalation:** Enable diagnostic mode after repeated failures

**Output (controlled by verbosity):**
- **Concise:** Progress markers only (`"✓ Subtask 1 complete"`)
- **Detailed:** Full execution details, file diffs, test results

---

### Step 6: Validate

- Execute Standard Validation Pipeline per `ValidationFramework.md`
- Apply validation shortcuts for task agent (Levels 1-5, Level 6 if structural)
- Follow failure protocols on detection
- Record all validation results in key data stream
- **Automatic Rollback:** If validation fails after 3 attempts, execute `.\Workspaces\Global\rollback.ps1 -Key {key} -Agent task`

#### 6.1. Automatic Playwright Test Creation (UI Tasks)

**For tasks involving UI changes, delegate to test-generation.prompt.md.**

**Delegation Protocol:**
1. Detect if task involves UI changes (components, pages, CSS, user interactions)
2. If yes, invoke `test-generation.prompt.md` with parameters:
   - `key`: Current task key (MANDATORY for directory structure)
   - `feature`: Task key or feature name
   - `scenario`: Specific test scenario from task description
   - `endpoints`: API endpoints involved (if any)
   - `tokens`: Session 212 defaults (unless task specifies otherwise)
   - `multiUser`: true if host/participant interaction
   - `testType`: "functional" | "visual" | "both" (based on change type)
3. Receive generated test files and orchestration script
4. Document in key-data-stream

**See:** `test-generation.prompt.md` and `shared/playwright-test-generation.md` for:
- Complete test type decision matrix
- Orchestration script requirement (MANDATORY)
- Test generation patterns
- Automatic test type detection & execution
- Test lifecycle management (creation, execution, promotion, cleanup)

**Key Requirements:**
- **Test Location**: `.github/prompts.keys/{key}/tests/` (within key data stream)
- **Test Registry**: `.github/prompts.keys/{key}/tests/test-registry.md` (prevents duplication)
- **Orchestration Scripts**: `.github/prompts.keys/{key}/scripts/`
- **Naming**: `{feature}-{test-type}.spec.ts`
- **Test Data**: Use Session 212 (tokens: KJAHA99L user / PQ9N5YWW host)
- **Execution**: Via orchestration scripts ONLY (never direct `npx playwright test`)
- **Cleanup**: Tests deleted from key directory after production promotion (Step 9)

**Skip test creation if:**
- Task is backend-only (no UI impact)
- Task is documentation/configuration only
- User explicitly requests `--no-tests` flag

---

#### 6.2. Mandatory Lint Validation (ALL Modified Files)

**CRITICAL: This step is MANDATORY before any commit. Lint failures BLOCK commit creation.**

**See:** `.github/prompts/shared/mandatory-lint-validation.md` for complete linting protocols

**Execution**:
1. **Detect all modified files**:
   ```powershell
   $modifiedFiles = git diff --name-only HEAD
   ```

2. **Run linters by file type**:
   - **C# Files** (*.cs, *.cshtml, *.razor): Roslynator + Roslyn Analyzers
   - **JavaScript/TypeScript** (*.js, *.ts, *.tsx): ESLint
   - **CSS/Razor Styles** (*.css, *.razor): Stylelint
   - **PowerShell Scripts** (*.ps1): PSScriptAnalyzer
   - **JSON Files** (*.json): JSON syntax validation + Prettier

3. **Auto-Fix Attempt**:
   - If lint failures detected, attempt auto-fix with `--fix` flags
   - Re-run validation after auto-fix
   - If still failing → Request manual intervention

4. **Linter Installation** (if tools missing):
   - ESLint: `npm install --save-dev eslint @typescript-eslint/parser`
   - Stylelint: `npm install --save-dev stylelint stylelint-config-standard`
   - PSScriptAnalyzer: `Install-Module -Name PSScriptAnalyzer -Scope CurrentUser -Force`

5. **Report Results**:
   ```
   [LINT VALIDATION]
   - C# Files: [PASS] 3 files validated (0 warnings)
   - JS/TS Files: [PASS] 2 files validated (0 errors)
   - CSS Files: [PASS] 1 file validated (0 errors)
   - PowerShell: [PASS] 1 file validated (0 warnings)
   - JSON: [PASS] 2 files validated (valid syntax)
   
   All files passed lint validation.
   ```

6. **Halt on Failure**:
   - If ANY linter returns non-zero exit code → HALT execution
   - Document lint errors in key data stream
   - **NEVER proceed to Step 8 (Commit) with lint failures**

**Output to User** (controlled by verbosity):
- **Concise:** Summary of files validated by type, pass/fail status
- **Detailed:** Full lint output, specific errors, auto-fix attempts

---

#### 6.3. High-Priority Constraint Verification

**CRITICAL: Verify ALL CAPS constraints from user request before marking work complete.**

**See:** `.github/prompts/shared/high-priority-task-detection.md` for complete protocol

**Execution**:
1. **Retrieve constraints from Step 2.1.5**:
   ```markdown
   HIGH-PRIORITY Constraints:
   1. do NOT remove existing save button (Preservation)
   2. EXACTLY match mockup colors (Exactness)
   ```

2. **Run verification checks**:
   - **Preservation**: DOM queries, visual inspection, regression tests
   - **Exactness**: Percy visual tests, CSS value inspection, pixel measurement
   - **Mandatory Inclusion**: Code inspection, E2E tests, feature presence
   - **Behavioral**: Functional tests, user acceptance testing

3. **Document verification results**:
   ```text
   ## High-Priority Constraint Verification
   
   - [PASS] Constraint 1: Save button preserved
     - Verification: DOM query `.session-save-button` successful
     - Test: `SaveButtonPresent` E2E test passed
   
    - [PASS] Constraint 2: Colors matched exactly
       - Verification: Percy visual regression passed
       - CSS values (hex): FF5733, 3357FF confirmed
   ```

4. **Constraint Violation Protocol**:
   - If ANY constraint violated → HALT execution immediately
   - Rollback to checkpoint commit
   - Notify user with violation details
   - Return to Step 3 (re-plan with constraint awareness)

**Output to User**:
```
HIGH-PRIORITY Constraints Verified:
- [PASS] Save button preserved (user requested: do NOT remove)
- [PASS] Mockup colors matched (user requested: EXACTLY match)
```

---

### Step 7: Confirm

**Provide summary based on `verbosity` parameter:**

**Concise:**
```
SUMMARY: {key-name}
- Status: {In Progress | Complete | Failed}
- Work Done: {1-2 sentence summary}
- Files Modified: {count} files
- Debug Logging: {inserted | removed | none}
- Tests: {passed/failed count}
- Build: {Clean | Warnings | Errors}
- Lint Validation: {PASS | FAIL} ({file-type breakdown})
- High-Priority Constraints: {N} verified
- Approval Iterations: {N} (if re-evaluation occurred)
- Checkpoint: checkpoint/{key}/{timestamp}
```

**Detailed:**
```
SUMMARY: {key-name}
- Status: {In Progress | Complete | Failed}
- Work Done: {detailed list of changes}
- Files Modified: {count} files
  - {file1}: {change description}
  - {file2}: {change description}
- Debug Logging: {details}
- Tests: {X passed, Y failed with details}
- Build: {Clean | Warnings | Errors with details}
- Lint Validation: {PASS | FAIL}
  - C# Files: {count} files, {warnings/errors}
  - JS/TS Files: {count} files, {warnings/errors}
  - CSS Files: {count} files, {warnings/errors}
  - PowerShell: {count} files, {warnings/errors}
  - JSON: {count} files, {syntax status}
- High-Priority Constraints Verified:
  - [PASS] {constraint 1 description}
  - [PASS] {constraint 2 description}
- Approval Iterations: {N} (if re-evaluation occurred)
  - Iteration 1: {additional requirement 1}
  - Iteration 2: {additional requirement 2}
- Checkpoint: checkpoint/{key}/{timestamp}
  - Browse: git tag --list "checkpoint/{key}/*" --sort=-creatordate
  - Rollback: git reset --hard checkpoint/{key}/{timestamp}
```

---

### Step 8: Update Key Data Stream (MANDATORY)

**CRITICAL: ALL task completions MUST update the key data stream. This is not optional.**

**GUARDRAIL - Lock Detection:** Before updating any key file, check for `.github/prompts.keys/**/{key}.lock` file. If lock exists → HALT and notify user (prevents concurrent modification conflicts).

#### 8.1. Update JSON Tracking (if plan exists)

**Trigger:** When `.github/prompts.keys/{key}/{key}.plan.json` exists

**Purpose:** Maintain machine-readable progress tracking synchronized with markdown work-log

**After each phase completion:**

1. **Load existing JSON** from `.github/prompts.keys/{key}/{key}.plan.json`
2. **Update phase status**: Find phase by ID, change status from `"in-progress"` to `"complete"`
3. **Record phase timing**:
   ```json
   "completedAt": "{ISO-8601-timestamp}",  // Set to current time
   "durationMinutes": {calculated}         // (completedAt - startedAt) / 60000 milliseconds
   ```
4. **Update validation results**:
   ```json
   "validation": {
     "buildPassed": true,
     "lintPassed": true,
     "testCreated": true,
     "testFile": "phase2-session-canvas-guard.spec.ts",
     "testsPassing": 3,
     "testsTotal": 3,
     "flakyTests": 0
   }
   ```
5. **Record commit info**:
   ```json
   "commit": {
     "sha": "{full-40-char-sha}",
     "message": "{commit-message}",
     "timestamp": "{ISO-8601-timestamp}"
   }
   ```
6. **Record checkpoint tag**:
   ```json
   "checkpoint": {
     "tag": "checkpoint/{key}/{timestamp}",
     "timestamp": "{ISO-8601-timestamp}"
   }
   ```
7. **Update metrics** (aggregate across all phases):
   ```json
   "metrics": {
     "completedPhases": 2,           // increment
     "totalTests": 6,                // aggregate from all phases
     "passingTests": 6,              // aggregate
     "flakyTests": 0,                // aggregate
     "filesModified": 5,             // count unique files
     "linesAdded": 150,              // sum from git diff
     "linesRemoved": 20,             // sum from git diff
     "totalDurationMinutes": 45,     // sum of all phase durations
     "averagePhaseDuration": 22.5    // totalDurationMinutes / completedPhases
   }
   ```
8. **Update global status** (when all phases complete):
   ```json
   "status": "complete",
   "updated": "{ISO-8601-timestamp}"
   ```
9. **Save JSON file** (pretty-printed for readability)

**Before Starting Next Phase (when triggered by plan agent):**

1. **Update next phase status**: Find next phase by ID, change status to `"in-progress"`
2. **Record phase start timing**:
   ```json
   "startedAt": "{ISO-8601-timestamp}"  // Set to current time when phase begins
   ```

**Synchronization Rule:** Both markdown work-log AND JSON tracking must be updated in same commit

**Output to User:**
- **Concise:** `"✓ JSON tracking updated (Phase 2 complete, duration: 23 minutes)"`
- **Detailed:** Show updated phase status, metrics, timing breakdown, and checkpoint reference

---

#### 8.2. Key Data Stream Bloat Detection (Pre-Update Cleanup)
1. Read current state: Check file size, entry count
2. Deduplication: Remove duplicate work log entries
3. Obsolescence cleanup: Remove superseded implementations, failed experiments
4. Size limits: If >100 entries or >50KB, trigger consolidation

#### 8.3. Key Data Stream Update Requirements
1. Locate key file: `.github/prompts.keys/**/{key}.md`
2. Retrieve git commit hash: `git rev-parse HEAD`
3. **Record user request** (Step 2.2.1 - if not already recorded):
   ```markdown
   ### User Request (2025-10-18T12:00:00Z)
   {succinct 1-2 sentence summary of user's original request}
   
   **High-Priority Constraints** (ALL CAPS from user):
   - do NOT remove existing save button
   - EXACTLY match mockup colors
   ```
4. Update or create entry (append to work log):
   ```markdown
   ### Work Completed (2025-10-18T12:30:00Z)
   - **Status**: {In Progress | Complete}
   - **Changes**: {list}
   - **Files Affected**: {list}
   - **Tests**: {results}
   - **Lint Validation**: {PASS | FAIL with details}
   - **High-Priority Constraints Verified**:
     - [PASS] Save button preserved (user ALL CAPS: do NOT remove)
     - [PASS] Mockup colors matched (user ALL CAPS: EXACTLY match)
   - **Approval Iterations**: {N} (if re-evaluation occurred)
   - **Additional Requirements**: {list of requirements added during iterations}
   - **Commit**: {SHA}
   ```
5. Output to user (brief acknowledgment only):
   - Concise: `"[OK] Key data stream updated (commit: {SHA})"`
   - Detailed: Show complete entry added
6. Maintain alphabetical sorting of keys

#### 8.4. Functionality Registry Validation (Regression Prevention)
1. Load Functionality Registry (if exists)
2. Detect breaking change risk
3. Execute validation
4. Update registry
5. Regression detection & history

**Failure to update the key data stream constitutes an incomplete task execution.**

---

### Step 8.5: Checkpoint Commit & Tag (MANDATORY)

**After all work is complete and key data stream is updated, create a final checkpoint commit with git tag.**

#### Checkpoint Commit Requirements
1. **Stage all changes:**
   ```bash
   git add -A
   ```

2. **Create checkpoint commit with standardized message:**
   ```bash
   git commit -m "checkpoint: {key} - {one-line summary of work}"
   ```
   - Example: `git commit -m "checkpoint: canvas - added share button with confirmation dialog"`

3. **Create lightweight git tag:**
   ```bash
   git tag "checkpoint/{key}/{ISO-8601-date-compact}"
   ```
   - Example: `git tag "checkpoint/canvas/2025-10-16_0230"`
   - Format: `checkpoint/{key}/{YYYY-MM-DD_HHMM}` (enables filtering by key)
   - Note: Git tags cannot contain colons, so use underscore for time separator

4. **Retrieve commit SHA:**
   ```bash
   git rev-parse HEAD
   ```

#### Automatic Tag Pruning (28-tag limit per key)
1. **List existing checkpoints for this key:**
   ```bash
   git tag --list "checkpoint/{key}/*" --sort=-creatordate
   ```

2. **If ≥28 tags exist, delete oldest:**
   ```bash
   git tag --list "checkpoint/{key}/*" --sort=creatordate | Select-Object -First {count-to-delete} | ForEach-Object { git tag -d $_ }
   ```

3. **Maintains most recent 28 checkpoints per key automatically**

#### Rollback & Browsing Capabilities

**Rollback to specific checkpoint:**
```bash
git reset --hard {tag-name}
# Example: git reset --hard checkpoint/canvas/2025-10-16T02:30:00Z
```

**Browse all checkpoints for a key:**
```bash
git tag --list "checkpoint/{key}/*" --sort=-creatordate
```

**View checkpoint details:**
```bash
git show {tag-name} --stat
```

**Browse all checkpoints across all keys:**
```bash
git tag --list "checkpoint/*/*" --sort=-creatordate
```

**Advantages over separate log files:**
- ✅ Single source of truth (git history)
- ✅ No file sync issues
- ✅ Native git browsing/search
- ✅ Works with all git tools (GUI clients, IDE integrations)
- ✅ Automatic cleanup via tag deletion
- ✅ Can view full diff: `git show checkpoint/canvas/2025-10-16T02:30:00Z`

**Output to User:**
- **Concise:** `"✓ Checkpoint created: {tag-name}"`
- **Detailed:** Show tag name, SHA, and rollback command

**Example Checkpoint Log (`.github/prompts.keys/.checkpoints/canvas.log`):**
```
2025-10-16T02:30:00Z | a3f5b9c1234 | added share button with confirmation dialog
2025-10-16T01:15:00Z | b2d4e8f5678 | fixed session title display bug
2025-10-15T23:45:00Z | c1a7b3d9012 | implemented question deletion with persistence
...
(up to 28 most recent checkpoints)
```

---

### Step 9: Completion Workflow *(Conditional: When tasks = "mark complete" or "completed")*

**Triggered when user specifies "mark complete" or "completed" as tasks parameter value.**

#### 9.1. Obsolete Information Removal & Debug Cleanup

**Key Data Stream Cleanup:**
- Remove superseded implementations, failed attempts, temporary workarounds
- Remove outdated architecture decisions
- Keep only current, working implementation details

**Debug Marker Cleanup (MANDATORY):**
Search all modified source files and remove debug logging markers:

1. **C# Files:** Remove lines containing `[DEBUG-WORKITEM:*] ;CLEANUP_OK` or `[DIAGNOSTIC:*] ;CLEANUP_OK`
2. **JavaScript/TypeScript:** Remove lines containing `[DEBUG-WORKITEM:*] ;CLEANUP_OK`
3. **Razor Files:** Remove lines containing `DEBUG-WORKITEM` or `DIAGNOSTIC`
4. **Verification:** Run `git grep "\[DEBUG-WORKITEM:\|DIAGNOSTIC:"` to ensure zero remaining markers
5. **Build:** Verify clean build after cleanup

**Output:**
```
[CLEANUP] Debug Cleanup Complete
- Removed {X} debug markers from {Y} files
- Verification: git grep found 0 remaining markers
- Build status: Clean
```

#### 9.2. Test Promotion & Cleanup (MANDATORY if tests exist)

**Promote Passing Tests to Production:**

1. **Check for active tests** in `.github/prompts.keys/{key}/tests/`:
   ```powershell
   $testFiles = Get-ChildItem ".github/prompts.keys/{key}/tests/*.spec.ts"
   ```

2. **For each passing test**:
   - Copy test file to production: `Tests/UI/{feature}-{test-type}.spec.ts`
   - Update orchestration script paths to point to production location
   - Copy orchestration script to: `Scripts/run-{feature}-test.ps1`
   - Document promotion in test registry (archive section)

3. **Update test registry** (`.github/prompts.keys/{key}/tests/test-registry.md`):
   ```markdown
   ## Archived Tests (Promoted to Production)
   
   ### {feature}-{test-type}.spec.ts
   - **Promoted**: {ISO-8601 timestamp}
   - **Destination**: Tests/UI/{feature}-{test-type}.spec.ts
   - **Orchestration**: Scripts/run-{feature}-test.ps1
   - **Commit**: {SHA}
   - **Status**: Promoted (deleted from key directory)
   ```

4. **Delete tests from key directory**:
   ```powershell
   Remove-Item ".github/prompts.keys/{key}/tests/*.spec.ts"
   Remove-Item ".github/prompts.keys/{key}/scripts/run-*-test.ps1"
   ```

5. **Preserve test registry** for historical reference

**Output:**
```
[TESTS] Test Promotion Complete
- Promoted {X} test(s) to Tests/UI/
- Copied {X} orchestration script(s) to Scripts/
- Deleted {X} test(s) from key directory
- Test registry archived
```

**Skip Conditions:**
- No tests exist in `.github/prompts.keys/{key}/tests/`
- All tests failed (do not promote failing tests)

#### 9.3. State Management & Completion
- Mark key as `complete` in metadata
- Verify key data stream is up-to-date with final state
- Archive work log (historical entries intact)
- Update key index

**Output to User:**
```
[COMPLETE] Key marked as COMPLETE
[OK] All information recorded in key data stream
[CLEANUP] Debug markers removed ({X} markers from {Y} files)
[TESTS] Tests promoted to production ({X} tests)
```

#### 9.4. Resumption Protocol
**If new tasks arrive for a `complete` key:**
- Auto-revert status from `complete` to `in-progress`
- Preserve all historical entries in key data stream
- Add new work log entry documenting resumption
- Continue normal workflow (Steps 1-8)

---

## Guardrails

- **ALWAYS check for comprehensive plan first** (if key provided, look for {key}.plan.md)
- **ALWAYS load System Context Pack** (if {key}.plan.md exists - Step 2.12)
- **ALWAYS update JSON tracking** (if {key}.plan.json exists - Step 8.1 after each phase)
- **ALWAYS query key data stream before planning** (Step 2 is mandatory)
- **ALWAYS record user request in key data stream** (Step 2.2.1 - succinct summary before work begins)
- **ALWAYS detect high-priority constraints** (Step 2.1.5 - scan for ALL CAPS emphasis)
- **ALWAYS execute Step 2.8.7 Data Lifecycle Validation for CRUD operations** (prevents UI-only mutations)
- **ALWAYS include persistence tests in Playwright specs** (page refresh after mutation is mandatory)
- **ALWAYS run mandatory lint validation before commit** (Step 6.2 - all modified files MUST pass)
- **ALWAYS verify high-priority constraints** (Step 6.3 - ALL CAPS constraints MUST be verified)
- **ALWAYS update key data stream after execution** (Step 8.3 is mandatory - includes user request and work completed)
- **ALWAYS update JSON tracking if plan exists** (Step 8.1 - synchronize with markdown work-log)
- **ALWAYS create checkpoint commit and git tag after task completion** (Step 8.5 is mandatory)
- **ALWAYS prune old checkpoint tags to maintain max 28 per key** (automatic cleanup)
- **ALWAYS execute completion workflow when tasks = "mark complete"** (Step 9 triggered by keyword - cleanup & state change only)
- **ALWAYS preserve all historical entries when resuming completed keys**
- **ALWAYS infer key from recent work** if not explicitly provided
- **ALWAYS enforce re-evaluation iteration limit** (max 3 iterations at Step 4 approval gate)
- **ALWAYS require explicit approval without additional requirements** before proceeding to Step 5
- **NEVER implement UI-only mutations** - all CRUD operations MUST have complete data lifecycle (UI → API → DB → Broadcast → UI)
- **NEVER skip persistence validation** - after mutation, refresh page and verify state persists
- **NEVER assume user symptoms identify root cause** - verify complete flow before implementing fixes
- **NEVER proceed past Step 4 if user response contains additional requirements** - loop back to Step 3 for re-planning
- **NEVER commit with lint failures** - Step 6.2 lint validation MUST pass before Step 8
- **NEVER violate high-priority constraints** - Step 6.3 constraint verification MUST pass or trigger rollback
- Never modify functionality unless explicitly required
- Always ensure architectural and structural integrity
- Always pause and request clarification if uncertain
- Maintain alignment across all agents
- Do not continue execution past failure points unless explicitly approved

---

## Clean Exit Guarantee

**See:** `.github/prompts/shared/clean-exit-guarantee.md` for complete exit criteria and failure protocols.

---

## Lifecycle

- Default state: `in-progress`
- Tasks transition to `complete` when user provides `tasks = "mark complete"` or `tasks = "completed"`
- **Completion triggers Step 9** - comprehensive cross-layer documentation and cleanup
- **Completed keys can be reopened** - new tasks automatically revert status to `in-progress`
- **Resumption preserves history** - completion documentation remains intact when key is reopened
- Keys and summaries in `prompts.keys` remain **single source of truth** for lifecycle tracking

---

## Lessons Learned Integration

**See:** `.github/learning/task-agent-lessons.md` for historical lessons learned from task agent failures, prevention patterns, and validation strategies.

**Key Lesson Applied:** Question Deletion Bug (Lesson 1)
- Step 2.8.7 validates complete CRUD data lifecycle (UI → API → Database → Broadcast → UI)
- Step 4 approval shows early warning for incomplete implementations
- Playwright tests require persistence validation with page refresh

---

## Diagnostic Mode Details

**See:** `.github/prompts/shared/debug-logging-mandate.md` for complete diagnostic mode patterns, marker formats, and use cases.

